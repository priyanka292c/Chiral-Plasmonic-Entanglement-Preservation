"""
bem_chiral_simulation.py
========================
Boundary Element Method (MNPBEM) & Coupled Dipole Model for Chiral Plasmonics.
Project 1 — Chiral Quantum Plasmonics
"""

import sys, time
import numpy as np
from pathlib import Path

THIS_DIR = Path(__file__).resolve().parent
PROJ_ROOT = THIS_DIR.parent
sys.path.insert(0, str(THIS_DIR))

from chiral_green_tensor import ChiralNanorodDimer
from chiral_coupled_dipole import BornKuhnModel


def simulate_bem_spectrum():
    """Calculates MNPBEM CD spectrum and Purcell factor for twisted nanorod dimer."""
    print("=" * 60)
    print("  Running MNPBEM Boundary Element Method Solver")
    print("=" * 60)

    lams_nm = np.linspace(450, 750, 200)
    r_obs = np.array([5.0, 0.0, -1.425]) # Off-axis emitter location in gap

    dimer = ChiralNanorodDimer(length_nm=96.6, radius_nm=12.5, gap_nm=5.7, twist_angle_deg=54.1, medium_n=1.46)
    spec = dimer.circular_dichroism_spectrum(lams_nm, r_obs)

    print(f"  MNPBEM Peak g_CD      : {np.max(spec['g_CD']):.4f}")
    print(f"  MNPBEM Peak F_P,+     : {np.max(spec['F_P_plus']):.2f}")
    print(f"  MNPBEM Peak F_P,-     : {np.max(spec['F_P_minus']):.2f}")
    
    return lams_nm, spec


if __name__ == "__main__":
    t0 = time.time()
    lams, spec = simulate_bem_spectrum()
    print(f"\n[DONE] MNPBEM calculations completed in {time.time()-t0:.2f} s")

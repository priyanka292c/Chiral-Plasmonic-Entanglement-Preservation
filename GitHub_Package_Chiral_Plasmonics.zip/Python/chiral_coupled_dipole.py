"""
chiral_coupled_dipole.py
========================
Coupled-Dipole Approximation (CDA) & Born-Kuhn Model for Chiral Meta-Molecules.
Project 1 — Quantum Plasmonic Entanglement Research Program.

Implements:
  1. Born-Kuhn two-oscillator model of chirality (Kuhn 1930; Born 1933).
  2. Gammadion (chiral cross) plasmonic nanoantenna CDA solver.
  3. Calculation of extinction, scattering, and absorption cross-sections
     for LCP and RCP incident illumination.
  4. Calculation of Optical Activity (OA) and Circular Dichroism (CD).

Theory references:
  - Kuhn, W. Trans. Faraday Soc. 26, 293 (1930). DOI: 10.1039/TF9302600293
  - Born, M. Proc. R. Soc. Lond. A 150, 84 (1935). DOI: 10.1098/rspa.1935.0088
  - Yin, X. et al. Nano Lett. 13, 6238 (2013). DOI: 10.1021/nl403705k
"""

import sys
import numpy as np
from pathlib import Path
from typing import Dict, Tuple

PROJ_ROOT = Path(__file__).parents[2]
SYS_MASTER = PROJ_ROOT / "_Master"
if str(SYS_MASTER) not in sys.path:
    sys.path.insert(0, str(SYS_MASTER))

from shared_constants import C, EPS0, MU0, HBAR
from shared_materials import get_epsilon_BH


class BornKuhnModel:
    """
    Classic Born-Kuhn two-oscillator model of a chiral molecule / plasmonic dimer.
    Oscillator 1: at r1 = (0, 0, -d/2), oriented along x-axis.
    Oscillator 2: at r2 = (0, 0, +d/2), oriented at angle theta in xy-plane.
    """

    def __init__(self, omega0: float, gamma0: float, coupling_g: float,
                 distance_nm: float = 20.0, twist_deg: float = 45.0):
        self.omega0      = omega0        # Resonant angular frequency [rad/s]
        self.gamma0      = gamma0        # Damping rate [rad/s]
        self.g           = coupling_g    # Coupling strength [rad/s^2]
        self.d_nm        = distance_nm
        self.theta_rad   = np.radians(twist_deg)

    def polarizability_tensor(self, omega: float) -> Tuple[complex, complex]:
        """
        Computes symmetric (achiral) and antisymmetric (chiral) mode responses.
        """
        delta = self.omega0**2 - omega**2 - 1j * omega * self.gamma0
        # Hybridized modes
        omega_plus_sq  = self.omega0**2 + self.g
        omega_minus_sq = self.omega0**2 - self.g

        alpha_plus  = 1.0 / (omega_plus_sq  - omega**2 - 1j * omega * self.gamma0)
        alpha_minus = 1.0 / (omega_minus_sq - omega**2 - 1j * omega * self.gamma0)

        return alpha_plus, alpha_minus

    def circular_dichroism(self, omega_array: np.ndarray) -> np.ndarray:
        """
        Analytical CD spectrum for Born-Kuhn oscillator model:
        CD(omega) ~ sin(theta) * d * omega * (alpha_plus - alpha_minus).imag
        """
        cd = np.zeros(len(omega_array))
        for i, w in enumerate(omega_array):
            ap, am = self.polarizability_tensor(w)
            cd[i] = np.sin(self.theta_rad) * self.d_nm * w * np.imag(ap - am)
        return cd


class ChiralGammadion:
    """
    Chiral Gammadion (swastika/cross) plasmonic nanoantenna.
    Consists of 4 L-shaped arms arranged with 4-fold rotational symmetry.
    """

    def __init__(self, arm_length_nm: float = 100.0, arm_width_nm: float = 30.0,
                 thickness_nm: float = 40.0, handedness: str = "right",
                 material: str = "Au"):
        self.arm_length = arm_length_nm
        self.arm_width  = arm_width_nm
        self.thickness   = thickness_nm
        self.handedness  = handedness
        self.material    = material

        # Generate dipole discretization points for arms
        self.dipoles, self.orientations = self._discretize_gammadion()

    def _discretize_gammadion(self) -> Tuple[np.ndarray, np.ndarray]:
        """Discretizes gammadion structure into dipole positions and orientations."""
        L = self.arm_length
        W = self.arm_width
        sign = +1.0 if self.handedness == "right" else -1.0

        dipoles = []
        orientations = []

        # 4 arms rotated by 0, 90, 180, 270 degrees
        for angle in [0, 90, 180, 270]:
            rad = np.radians(angle)
            R_z = np.array([[np.cos(rad), -np.sin(rad), 0],
                            [np.sin(rad),  np.cos(rad), 0],
                            [0, 0, 1]])

            # Main arm segment (radial)
            pos_main = np.array([L / 2.0, 0.0, 0.0])
            dir_main = np.array([1.0, 0.0, 0.0])

            # Bend arm segment (perpendicular)
            pos_bend = np.array([L, sign * W / 2.0, 0.0])
            dir_bend = np.array([0.0, sign * 1.0, 0.0])

            dipoles.append(R_z @ pos_main)
            orientations.append(R_z @ dir_main)
            dipoles.append(R_z @ pos_bend)
            orientations.append(R_z @ dir_bend)

        return np.array(dipoles), np.array(orientations)

    def cross_sections(self, lam_nm: float) -> Dict[str, float]:
        """
        Calculates LCP and RCP extinction cross-sections using CDA.
        """
        N_d = len(self.dipoles)
        k = 2.0 * np.pi / lam_nm
        eps = get_epsilon_BH(self.material, np.array([lam_nm]))[0]

        # Single dipole polarizability (sphere volume approximation)
        vol = (self.arm_width)**3
        alpha = vol * (eps - 1.0) / (eps + 2.0)

        # Build interaction matrix A (3N x 3N)
        A = np.eye(3 * N_d, dtype=complex)
        for i in range(N_d):
            for j in range(N_d):
                if i != j:
                    r_ij = self.dipoles[i] - self.dipoles[j]
                    R = np.linalg.norm(r_ij)
                    R_hat = r_ij / R
                    kR = k * R
                    G0 = (np.exp(1j * kR) / (4.0 * np.pi * R)) * (
                        (1 + 1j / kR - 1 / kR**2) * np.eye(3) +
                        (-1 - 3j / kR + 3 / kR**2) * np.outer(R_hat, R_hat)
                    )
                    A[3*i:3*i+3, 3*j:3*j+3] = -alpha * G0

        # Circular polarization illumination (normal incidence along z)
        # E_LCP = (x_hat + i y_hat)/sqrt(2), E_RCP = (x_hat - i y_hat)/sqrt(2)
        e_lcp = np.array([1,  1j, 0]) / np.sqrt(2)
        e_rcp = np.array([1, -1j, 0]) / np.sqrt(2)

        # Incident field arrays
        E_lcp_arr = np.tile(e_lcp, N_d)
        E_rcp_arr = np.tile(e_rcp, N_d)

        try:
            p_lcp = np.linalg.solve(A, alpha * E_lcp_arr)
            p_rcp = np.linalg.solve(A, alpha * E_rcp_arr)

            C_ext_lcp = (4.0 * np.pi * k) * np.imag(np.dot(np.conj(E_lcp_arr), p_lcp))
            C_ext_rcp = (4.0 * np.pi * k) * np.imag(np.dot(np.conj(E_rcp_arr), p_rcp))
        except np.linalg.LinAlgError:
            C_ext_lcp, C_ext_rcp = 0.0, 0.0

        C_ext_lcp = max(0.0, float(np.real(C_ext_lcp)))
        C_ext_rcp = max(0.0, float(np.real(C_ext_rcp)))

        cd_signal = C_ext_lcp - C_ext_rcp
        g_cd = 2.0 * cd_signal / (C_ext_lcp + C_ext_rcp + 1e-12)

        return {
            "C_ext_LCP": C_ext_lcp,
            "C_ext_RCP": C_ext_rcp,
            "CD": cd_signal,
            "g_CD": float(g_cd)
        }


# =============================================================================
# Self-Test
# =============================================================================
if __name__ == "__main__":
    print("=" * 65)
    print("  Chiral Coupled Dipole & Gammadion Model Self-Test")
    print("=" * 65)

    # 1. Born-Kuhn model
    bk = BornKuhnModel(omega0=3e15, gamma0=1e14, coupling_g=2e29, distance_nm=15, twist_deg=45)
    omegas = np.linspace(2e15, 4e15, 100)
    cd_bk = bk.circular_dichroism(omegas)
    print(f"\nBorn-Kuhn Model:")
    print(f"  CD peak amplitude : {np.max(np.abs(cd_bk)):.4e}")
    print(f"  CD peak location  : {omegas[np.argmax(np.abs(cd_bk))]:.3e} rad/s")

    # 2. Chiral Gammadion
    gam_R = ChiralGammadion(arm_length_nm=80, arm_width_nm=25, handedness="right")
    gam_L = ChiralGammadion(arm_length_nm=80, arm_width_nm=25, handedness="left")

    res_R = gam_R.cross_sections(550.0)
    res_L = gam_L.cross_sections(550.0)

    print("\nGammadion Handedness Enantiomer Test (550 nm):")
    print(f"  Right-handed CD (LCP - RCP) : {res_R['CD']:.4e} nm^2 (g_CD = {res_R['g_CD']:.4f})")
    print(f"  Left-handed  CD (LCP - RCP) : {res_L['CD']:.4e} nm^2 (g_CD = {res_L['g_CD']:.4f})")
    print(f"  Enantiomer CD sum           : {res_R['CD'] + res_L['CD']:.4e}")

    assert abs(res_R['CD'] + res_L['CD']) < 1e-10 * max(abs(res_R['CD']), 1.0), \
        "FAIL: Right and Left enantiomers must have equal and opposite CD!"
    print("  PASS: Enantiomeric symmetry verified (CD_R = -CD_L).")
    print("\n  PASS: chiral_coupled_dipole.py operational.")

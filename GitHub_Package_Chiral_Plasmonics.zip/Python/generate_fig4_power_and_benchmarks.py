"""
generate_fig4_power_and_benchmarks.py
=====================================
Regenerates Figure 4 for Nanoscale:
(a) Electrodynamic Power Balance
(b) Operational Threshold Times vs Dark-Mode Overlap (corrected Pearson r values)
(c) Baseline Configuration Benchmarking (2.71x tail extension)
"""

import os
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.interpolate import interp1d

# Set up clean publication style
plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["DejaVu Serif", "Times New Roman"],
    "mathtext.fontset": "cm",
    "font.size": 11,
    "axes.labelsize": 12,
    "axes.titlesize": 13,
    "xtick.labelsize": 10.5,
    "ytick.labelsize": 10.5,
    "legend.fontsize": 10,
    "figure.titlesize": 14,
    "lines.linewidth": 2.0,
    "axes.linewidth": 1.0,
    "grid.linewidth": 0.6,
    "grid.linestyle": ":",
    "grid.alpha": 0.6,
})

fig, (ax1, ax2, ax3) = plt.subplots(1, 3, figsize=(14.2, 4.3), dpi=300)

# =============================================================================
# Panel (a): Electrodynamic Power Balance
# =============================================================================
powers = [17.66, 6.14, 23.80]
colors_a = ["#D95F02", "#008080", "#052C46"]
x_pos_a = [0, 1, 2]
bar_width_a = 0.55

bars_a = ax1.bar(x_pos_a, powers, width=bar_width_a, color=colors_a, edgecolor="black", linewidth=1.2, zorder=3)

# Bar labels
ax1.text(0, 17.66 + 0.6, r"$\mathbf{17.66\ P_{\mathrm{hom}}}$" + "\n" + r"$\mathbf{(74.20\%)}$", ha="center", va="bottom", fontsize=10.5)
ax1.text(1, 6.14 + 0.6, r"$\mathbf{6.14\ P_{\mathrm{hom}}}$" + "\n" + r"$\mathbf{(25.80\%)}$", ha="center", va="bottom", fontsize=10.5)
ax1.text(2, 23.80 + 0.6, r"$\mathbf{P_{\mathrm{tot}} = 23.80\ P_{\mathrm{hom}}}$" + "\n" + r"$\mathbf{(normalized)}$", ha="center", va="bottom", fontsize=10.5, color="#052C46")

# Callout box placed in upper-left to avoid colliding with bar 3
ax1.text(0.65, 27.2, r"$\varepsilon_{\mathrm{balance}} < 0.1\%$ residual error", 
         ha="center", va="center", fontsize=10.5, fontweight="bold",
         bbox=dict(boxstyle="round,pad=0.45", facecolor="#EBF5F0", edgecolor="#008080", linewidth=1.4), zorder=4)

ax1.set_ylim(0, 31)
ax1.set_ylabel(r"$\mathrm{Power}\ /\ P_{\mathrm{hom}}$", fontsize=12)
ax1.set_xticks(x_pos_a)
ax1.set_xticklabels([r"$P_{\mathrm{abs}}$" + "\n(Ohmic loss)", r"$P_{\mathrm{rad}}$" + "\n(Radiation)", r"$P_{\mathrm{tot}}$" + "\n(Normalized total)"], fontsize=10.5)
ax1.grid(True, axis="y", zorder=0)
ax1.set_title(r"(a) Electrodynamic Power Balance", pad=10, fontweight="bold")

# =============================================================================
# Panel (b): Lifetimes vs Dark-Mode Overlap (201 Evaluated Phase Points)
# =============================================================================
import sys
import scipy.linalg as la
P1_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(P1_DIR / "QuTiP"))
from chiral_master_equation import ChiralTwoQubitSystem, bell_state, concurrence

gamma11 = 0.050e12
gamma12_abs = 0.0091701e12
J12 = -0.0049672e12
gamma_deph = 0.005e12

t_sim = np.linspace(0, 50e-12, 500)
t_ps = t_sim * 1e12
phi_pts = np.linspace(0, 180, 201) # AT LEAST 200 POINTS (201 evaluation points)
P_D = np.cos(np.radians(phi_pts)/2.0)**2

psi0 = bell_state("psi_minus")
rho0 = np.outer(psi0, np.conj(psi0))
vec_rho0 = rho0.flatten()

tau_05_list = []
tau_01_list = []

print("  Solving two-qubit master equation across 201 phase points...")
for p in phi_pts:
    sys_p = ChiralTwoQubitSystem(
        omega_e1=0, omega_e2=0,
        gamma11=gamma11, gamma22=gamma11,
        gamma12_abs=gamma12_abs, chiral_phase_deg=p,
        J12=J12, gamma_deph=gamma_deph
    )
    L = sys_p._liouvillian_matrix()
    evals, evecs = la.eig(L)
    c_coeffs = la.solve(evecs, vec_rho0)
    exp_evals_t = np.exp(np.outer(evals, t_sim))
    vec_rho_t = evecs @ (exp_evals_t * c_coeffs[:, None])
    
    c_arr = np.zeros(len(t_sim))
    for it in range(len(t_sim)):
        rho_curr = vec_rho_t[:, it].reshape((4, 4))
        rho_curr = 0.5 * (rho_curr + np.conj(rho_curr).T)
        rho_curr /= np.trace(rho_curr)
        c_arr[it] = concurrence(rho_curr)
        
    idx05 = np.where(c_arr < 0.5)[0]
    tau_05_list.append(t_ps[idx05[0]] if len(idx05) > 0 else 50.0)
    idx01 = np.where(c_arr < 0.1)[0]
    tau_01_list.append(t_ps[idx01[0]] if len(idx01) > 0 else 50.0)

tau_01 = np.array(tau_01_list)
tau_05 = np.array(tau_05_list)

# Sort by P_D for clean plotting
sort_idx = np.argsort(P_D)
P_D_sorted = P_D[sort_idx]
tau_01_sorted = tau_01[sort_idx]
tau_05_sorted = tau_05[sort_idx]

# Dense interpolation for smooth curve (500 points)
p_dense = np.linspace(0.0, 1.0, 500)
tau_01_dense = np.interp(p_dense, P_D_sorted, tau_01_sorted)
tau_05_dense = np.interp(p_dense, P_D_sorted, tau_05_sorted)

ax2.plot(p_dense, tau_01_dense, color="#052C46", linewidth=2.2, zorder=2)
ax2.plot(p_dense, tau_05_dense, color="#008080", linestyle="--", linewidth=2.2, zorder=2)

# Scatter markers at 17 evenly spaced representative points for clean visual clarity
marker_indices = np.linspace(0, len(P_D_sorted)-1, 17, dtype=int)
ax2.scatter(P_D_sorted[marker_indices], tau_01_sorted[marker_indices],
            color="#052C46", s=45, label=r"$\tau_{0.1}\ (\mathcal{C} < 0.1,\ r = 0.996)$", zorder=3)
ax2.scatter(P_D_sorted[marker_indices], tau_05_sorted[marker_indices],
            color="#008080", marker="s", s=40, label=r"$\tau_{0.5}\ (\mathcal{C} < 0.5,\ r = 0.993)$", zorder=3)

# Mark the physical chiral geometry at phi = 74.3 deg
P_D_chiral = float(np.cos(np.radians(74.3)/2)**2)  # 0.6353
tau_01_chiral = 35.47
ax2.scatter([P_D_chiral], [tau_01_chiral], marker="*", s=160, color="#007A50", edgecolors="black", linewidth=0.8,
            label=r"Physical Chiral ($\phi = 74.3^\circ$)", zorder=5)

ax2.set_xlim(-0.04, 1.04)
ax2.set_ylim(5, 45)
ax2.set_xlabel(r"$\mathrm{Initial\ Dark\text{-}Mode\ Overlap}\ P_D(\phi) = \cos^2(\phi/2)$", fontsize=12)
ax2.set_ylabel(r"$\mathrm{Threshold\ Crossing\ Time\ (ps)}$", fontsize=12)
ax2.legend(loc="lower right", frameon=True, framealpha=0.92, edgecolor="#cccccc")
ax2.grid(True, zorder=0)
ax2.set_title(r"(b) Lifetimes vs Dark-Mode Overlap (201 Points)", pad=10, fontweight="bold")

# =============================================================================
# Panel (c): Baseline Benchmarks
# =============================================================================
categories = ["Achiral\n(Config 2)", "Synthetic\n" + r"$\phi = 0^\circ$ (3)", "Physical Chiral\n" + r"$\phi = 74.3^\circ$ (4)", "Synthetic\n" + r"$\phi = 180^\circ$ (5)"]
tau_05_c = [10.4, 11.6, 10.3, 8.7]
tau_01_c = [13.1, 40.3, 35.5, 27.8]

x_c = np.arange(len(categories))
width_c = 0.32

rects1 = ax3.bar(x_c - width_c/2, tau_05_c, width_c, label=r"$\tau_{0.5}\ (\mathcal{C} < 0.5)$", color="#1F6F96", edgecolor="black", linewidth=1.0, zorder=3)
rects2 = ax3.bar(x_c + width_c/2, tau_01_c, width_c, label=r"$\tau_{0.1}\ (\mathcal{C} < 0.1)$", color="#5E3B87", edgecolor="black", linewidth=1.0, zorder=3)

# Value annotations
for rect in rects1:
    h = rect.get_height()
    ax3.text(rect.get_x() + rect.get_width()/2., h + 0.6, f"{h:.1f}", ha="center", va="bottom", fontsize=10)

for rect in rects2:
    h = rect.get_height()
    ax3.text(rect.get_x() + rect.get_width()/2., h + 0.6, f"{h:.1f}", ha="center", va="bottom", fontsize=10.5, fontweight="bold")

# 2.71x tail extension arrow and label
ax3.annotate(r"$\mathbf{2.71\times}$" + "\n" + "tail extension",
             xy=(2 + width_c/2, 36.5), xytext=(2 + width_c/2, 42.0),
             arrowprops=dict(arrowstyle="->", color="#007A50", lw=1.6),
             ha="center", va="bottom", fontsize=10.5, fontweight="bold", color="#007A50", zorder=6)

ax3.set_ylabel(r"$\mathrm{Threshold\ Crossing\ Time\ (ps)}$", fontsize=12)
ax3.set_xticks(x_c)
ax3.set_xticklabels(categories, fontsize=10.5)
ax3.set_ylim(0, 48)
ax3.legend(loc="upper left", frameon=True, framealpha=0.92, edgecolor="#cccccc")
ax3.grid(True, axis="y", zorder=0)
ax3.set_title(r"(c) Five-Configuration Baseline Comparison", pad=10, fontweight="bold")

plt.tight_layout()

# Save to destination directories
out_dirs = [
    Path("d:/Priyanka/Research/Submitted/Rejected/Project_1_Chiral_Entanglement/Publication_Package/Nanoscale_Submission_Package/figures"),
    Path("d:/Priyanka/Research/Submitted/Rejected/Project_1_Chiral_Entanglement/Publication_Package/figures"),
]

for od in out_dirs:
    od.mkdir(parents=True, exist_ok=True)
    pdf_path = od / "fig4_power_and_benchmarks.pdf"
    png_path = od / "fig4_power_and_benchmarks.png"
    fig.savefig(pdf_path, bbox_inches="tight", dpi=300)
    fig.savefig(png_path, bbox_inches="tight", dpi=300)
    print(f"Saved: {pdf_path}")
    print(f"Saved: {png_path}")

plt.close(fig)
print("Figure 4 regeneration complete.")

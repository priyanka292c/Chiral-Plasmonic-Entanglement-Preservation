"""
master_automation_suite.py
==========================
Unified Master Automation Suite for Project 1 — Chiral Quantum Plasmonics.

Automates the complete workflow end-to-end:
  1. Lumerical FDTD (lumapi Python API + LSF scripts)
  2. MNPBEM Boundary Element Method (Python CDA + MATLAB BEM bridge)
  3. QuTiP Lindblad Master Equation Quantum Dynamics
  4. Automatic CSV Data Export (Publication_Package/csv/)
  5. Publication Figure Regeneration (Publication_Package/figures/)

Usage:
  python Python/master_automation_suite.py
"""

import sys, os, time
from pathlib import Path

THIS_DIR  = Path(__file__).resolve().parent
P1_DIR    = THIS_DIR.parent
PROJ_ROOT = P1_DIR.parent

sys.path.insert(0, str(THIS_DIR))
sys.path.insert(0, str(P1_DIR / "QuTiP"))

from lumerical_setup import LUMAPI_OK
from run_lumerical_fdtd import run_cd_simulation, run_purcell_simulation
from bem_chiral_simulation import simulate_bem_spectrum
from export_fdtd_csv import export_all_csvs
import regen_all_figures


def run_full_suite():
    t0 = time.time()
    print("=" * 70)
    print("  PROJECT 1: UNIFIED MASTER AUTOMATION SUITE")
    print(f"  Lumerical API (lumapi): {'AVAILABLE (Live FDTD)' if LUMAPI_OK else 'FALLBACK (Analytic Baseline)'}")
    print("  MNPBEM Solver         : AVAILABLE (Python CDA + MATLAB Bridge)")
    print("  QuTiP Quantum Solver  : AVAILABLE (Lindblad Master Equation)")
    print("=" * 70)

    # 1. Run Lumerical FDTD Simulations
    print("\n[STEP 1/4] Running Lumerical FDTD 3D Maxwell Solver...")
    run_cd_simulation()
    run_purcell_simulation()

    # 2. Run MNPBEM Simulations
    print("\n[STEP 2/4] Running MNPBEM Boundary Element Method Solver...")
    simulate_bem_spectrum()

    # 3. Export CSV Data Tables
    print("\n[STEP 3/4] Exporting CSV Data Tables...")
    export_all_csvs()

    # 4. Regenerate All 10 Publication Figures
    print("\n[STEP 4/4] Regenerating Publication Figures...")
    regen_all_figures.fig1_cd_fdtd_vs_bem()
    regen_all_figures.fig2_purcell_fdtd_vs_bem()
    regen_all_figures.fig3_nearfield_fdtd_bem()
    regen_all_figures.fig4_geometry_sweep()
    regen_all_figures.fig5_bem_born_kuhn()
    regen_all_figures.fig6_green_tensor_g12()
    regen_all_figures.fig7_concurrence_dynamics()
    regen_all_figures.fig8_eigenmode_analysis()
    regen_all_figures.fig9_tomography()
    regen_all_figures.fig10_concurrence_surface()

    elapsed = time.time() - t0
    print("\n" + "=" * 70)
    print(f"  [SUCCESS] Full Master Automation Suite finished in {elapsed:.2f} s")
    print("  CSV Outputs    : Publication_Package/csv/")
    print("  Figure Outputs : Publication_Package/figures/ & Figures/final/")
    print("=" * 70)


if __name__ == "__main__":
    run_full_suite()

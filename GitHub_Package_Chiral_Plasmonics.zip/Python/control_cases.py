"""
control_cases.py
================
Separation of amplitude (Effect A) and phase (Effect B) contributions
to two-qubit entanglement in a chiral plasmonic environment.

Produces four QuTiP Lindblad simulations:
  Case 1: Achiral reference        (beta12=0, phi=0)
  Case 2: Effect A only            (beta12=0.891, phi=0)  -- amplitude control
  Case 3: Effect B only            (beta12=0.45, phi=74.3 deg) -- phase control
  Case 4: Full FDTD                (beta12=0.891, phi=74.3 deg)
  Case 5: Ideal (beta->1)          (beta12=0.99, phi=74.3 deg)

Metrics reported for each case:
  - Time-averaged concurrence C_avg (T=50 ps)
  - Entanglement lifetime tau_{C(0.5)} = min{t: C(t) < 0.5}
  - Liouvillian relaxation time tau_L = 1/|Re(lambda_slow)|

Implements PRA manuscript Table I (plan tasks L1.6, L1.9).
"""

import sys, os
import numpy as np

# ---- Try ChiralTwoQubitSystem ----------------------------------------------
qutip_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "QuTiP"))
if qutip_dir not in sys.path:
    sys.path.insert(0, qutip_dir)

try:
    from chiral_master_equation import ChiralTwoQubitSystem
    QUTIP_OK = True
    print("[OK] ChiralTwoQubitSystem loaded from chiral_master_equation.")
except ImportError as _e:
    QUTIP_OK = False
    print(f"[WARN] ChiralTwoQubitSystem import failed ({_e}); using analytic fallback.")

# ---- Units and constants ---------------------------------------------------
GAMMA_BAR_PS = 0.05   # [ps^{-1}] -- total single-emitter decay rate
GAMMA_PHI_PS = 0.15   # [ps^{-1}] -- pure dephasing at T=300K
GAMMA_BAR    = 1.0    # [dimensionless, normalised]
GAMMA_PHI    = GAMMA_PHI_PS / GAMMA_BAR_PS   # normalised dephasing rate
J12_NORM     = 0.15   # [dimensionless] J_12/gamma_bar
T_PS         = 50.0   # [ps] integration window for C_avg
N_TIMES      = 300    # time steps
T_MAX_NORM   = T_PS * GAMMA_BAR_PS  # [dimensionless] t_max in units of 1/gamma_bar

# ---- Control cases definition ---------------------------------------------
CONTROL_CASES = [
    {
        "id": "C0",
        "name": "C0: Uncoupled Reference",
        "description": "No collective cross-decay (beta12 = 0, eta = 0 deg)",
        "beta12": 0.000,
        "phi_deg": 0.0,
        "eta_deg": 0.0,
        "color": "#e74c3c",   # Red
        "linestyle": "--"
    },
    {
        "id": "CA",
        "name": "CA: In-Phase Cross-Decay",
        "description": "Full cross-decay amplitude with zero phase (beta12 = 0.1834, eta = 0 deg)",
        "beta12": 0.183402,
        "phi_deg": 0.0,
        "eta_deg": 0.0,
        "color": "#e67e22",   # Orange
        "linestyle": "-"
    },
    {
        "id": "CB",
        "name": "CB: Anti-Phase FDTD Optimum",
        "description": "Full cross-decay amplitude with anti-phase (beta12 = 0.1834, eta = -180 deg)",
        "beta12": 0.183402,
        "phi_deg": 0.0,
        "eta_deg": -180.0,
        "color": "#27ae60",   # Green
        "linestyle": "-"
    },
    {
        "id": "CAB",
        "name": "CAB: Quadrature Phase",
        "description": "Full cross-decay amplitude with quadrature phase (beta12 = 0.1834, eta = -90 deg)",
        "beta12": 0.183402,
        "phi_deg": 90.0,
        "eta_deg": -90.0,
        "color": "#2980b9",   # Blue
        "linestyle": "-"
    }
]


def compute_case_qutip(beta12, phi_deg):
    """Full 16x16 Lindblad master equation simulation via ChiralTwoQubitSystem."""
    gamma0 = 0.05e12   # 0.05 ps^-1 base rate (20 ps subradiant lifetime scale)
    gamma11 = gamma0
    gamma22 = gamma0
    J12 = J12_NORM * gamma0
    gamma_deph = 0.005e12  # low dephasing rate (0.005 ps^-1) to resolve collective dynamics

    sys = ChiralTwoQubitSystem(
        omega_e1=0.0,
        omega_e2=0.0,
        gamma11=gamma11,
        gamma22=gamma22,
        gamma12_rel=float(beta12),
        chiral_phase_deg=float(phi_deg),
        J12=J12,
        gamma_deph=gamma_deph
    )

    t_span = np.linspace(0, T_PS * 1e-12, N_TIMES)  # in seconds
    res = sys.simulate(t_span, "psi_minus")

    times_ps = res["times_ps"]
    C_t = res["concurrence"]
    return times_ps, C_t


def compute_case_analytic(beta12, phi_deg):
    """Analytic fallback concurrence decay."""
    phi = np.deg2rad(phi_deg)
    times = np.linspace(0, T_MAX_NORM, N_TIMES)
    C_t = lindblad_analytic(beta12, phi, times)
    return times, C_t


def time_averaged_concurrence(C_t, times):
    """Trapezoidal integration of C(t) over [0,T]."""
    _trapz = getattr(np, "trapezoid", None) or np.trapz
    return float(_trapz(C_t, times) / max(times[-1] - times[0], 1e-30))



def entanglement_lifetime(C_t, times, threshold=0.5):
    """Smallest t at which C(t) < threshold. Returns T_max if never crossed."""
    idx = np.where(C_t < threshold)[0]
    if len(idx) == 0:
        return float(times[-1])
    return float(times[idx[0]])


def liouvillian_tau(beta12, phi_deg):
    """
    Analytic Liouvillian slowest eigenvalue for X-state dynamics.
    tau_L = 1 / Re(lambda_slow) in normalised units.
    """
    # For symmetric dimer, the slowest eigenvalue has Re = gamma_bar - gamma12
    gamma12 = beta12 * GAMMA_BAR
    lambda_slow = -(GAMMA_BAR - gamma12 + GAMMA_PHI)
    if abs(lambda_slow) > 0:
        return 1.0 / abs(lambda_slow)
    return np.inf


# ---- Main ------------------------------------------------------------------
if __name__ == "__main__":
    print("=" * 72)
    print("  Control Cases: Separation of Effects A and B")
    print(f"  Solver : {'QuTiP Lindblad' if QUTIP_OK else 'Analytic fallback'}")
    print(f"  T      : {T_PS:.0f} ps   gamma_bar={GAMMA_BAR_PS:.3f} ps^-1")
    print(f"  gamma_phi = {GAMMA_PHI_PS:.3f} ps^-1   J12/gamma = {J12_NORM:.3f}")
    print("=" * 72)

    results = []
    header = f"{'Configuration':<36}  {'beta12':>6}  {'phi(deg)':>8}  "
    header += f"{'tau_L(ps)':>9}  {'tau_C0.5(ps)':>12}  {'C_avg':>6}"
    print(header)
    print("-" * 80)

    for case in CASES:
        beta12   = case["beta12"]
        phi_deg  = case["phi_deg"]
        name     = case["name"]

        if QUTIP_OK:
            times_norm, C_t = compute_case_qutip(beta12, phi_deg)
        else:
            times_norm, C_t = compute_case_analytic(beta12, phi_deg)

        # Convert normalised time to ps
        times_ps = times_norm / GAMMA_BAR_PS

        C_avg    = time_averaged_concurrence(C_t, times_ps)
        tau_C    = entanglement_lifetime(C_t, times_ps, threshold=0.5)
        tau_L_norm = liouvillian_tau(beta12, phi_deg)
        tau_L_ps = tau_L_norm / GAMMA_BAR_PS

        results.append({
            "name":    name,
            "beta12":  beta12,
            "phi_deg": phi_deg,
            "tau_L":   tau_L_ps,
            "tau_C":   tau_C,
            "C_avg":   C_avg,
            "times_ps": times_ps,
            "C_t":     C_t,
        })

        row = f"  {name:<34}  {beta12:>6.3f}  {phi_deg:>8.1f}  "
        row += f"{tau_L_ps:>9.1f}  {tau_C:>12.1f}  {C_avg:>6.3f}"
        print(row)

    print("=" * 72)

    # Additive separation check
    r_ach  = results[0]["C_avg"]
    r_A    = results[1]["C_avg"]
    r_B    = results[2]["C_avg"]
    r_full = results[3]["C_avg"]
    dA = r_A - r_ach
    dB = r_B - r_ach
    d_full = r_full - r_ach
    print(f"\n  Delta(C_avg) -- additive separation check:")
    print(f"    Effect A alone:       {dA:+.3f}")
    print(f"    Effect B alone:       {dB:+.3f}")
    print(f"    Sum A + B:            {dA+dB:+.3f}")
    print(f"    Full FDTD:            {d_full:+.3f}")
    print(f"    Non-linearity:        {d_full - (dA+dB):+.3f}")

    # Generate figure
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        fig, axes = plt.subplots(1, 2, figsize=(12, 4.5))
        colors  = ["#e74c3c", "#3498db", "#2ecc71", "#9b59b6", "#f39c12"]
        lstyles = ["-",       "-",       "--",      "-",       ":"]

        ax = axes[0]
        for r, col, ls in zip(results, colors, lstyles):
            ax.plot(r["times_ps"], r["C_t"], color=col, ls=ls, lw=2.2,
                    label=r["name"].split("(")[0].strip())
        ax.axhline(0.5, color="k", ls=":", lw=1, label="C=0.5 threshold")
        ax.set_xlabel("Time (ps)"); ax.set_ylabel("Concurrence C(t)")
        ax.set_title("Effect A vs Effect B: Concurrence Dynamics")
        ax.legend(fontsize=8, frameon=True, loc="upper right")
        ax.set_xlim(0, T_PS)
        ax.set_ylim(0, 1.05)

        ax = axes[1]
        names  = [r["name"].split("(")[0].strip()[:18] for r in results]
        cavgs  = [r["C_avg"] for r in results]
        tau_Cs = [min(r["tau_C"], T_PS) for r in results]
        x = np.arange(len(results))
        w = 0.35
        bars1 = ax.bar(x - w/2, cavgs, w, color=colors, alpha=0.85,
                       label=r"$\bar{\mathcal{C}}_{50\,\mathrm{ps}}$")
        ax2 = ax.twinx()
        bars2 = ax2.bar(x + w/2, tau_Cs, w, color=colors, alpha=0.45,
                        hatch="///", label=r"$\tau_{\mathcal{C}(0.5)}$ [ps]")
        ax.set_xticks(x); ax.set_xticklabels(names, rotation=15, ha="right", fontsize=7)
        ax.set_ylabel(r"$\bar{\mathcal{C}}_{50\,\mathrm{ps}}$", color="navy")
        ax2.set_ylabel(r"$\tau_{\mathcal{C}(0.5)}$ (ps)", color="gray")
        ax.set_title("Control Case Summary")
        ax.set_ylim(0, 1.0); ax2.set_ylim(0, 250)

        fig.suptitle("Fig. 7 (extended): Effect A vs Effect B Separation",
                     fontweight="bold", fontsize=11)
        fig.tight_layout()

        out_path = os.path.join(
            "d:/Priyanka/Submitted/Project_1_Chiral_Entanglement/Publication_Package/figures",
            "fig7_control_cases.png")
        fig.savefig(out_path, dpi=200, bbox_inches="tight")
        plt.close(fig)
        print(f"\n  [saved] fig7_control_cases -> {out_path}")
    except Exception as e:
        print(f"\n  [WARN] Figure save failed: {e}")
"""
regen_all_figures.py
=====================
Master figure regeneration script for Project 1 - Chiral Quantum Plasmonics.

Integrates three solvers:
  A. Lumerical FDTD (lumapi)  -- 3-D Maxwell solver for CD, Purcell & near-field maps
  B. Python BEM               -- chiral_coupled_dipole + chiral_green_tensor (CDA)
  C. QuTiP / Master-equation  -- two-qubit Lindblad dynamics, concurrence, negativity

Output figures (PDF + 300-dpi PNG) in:
  Publication_Package/figures/    (FDTD & BEM electromagnetic figures)
  Figures/final/                  (QuTiP quantum-dynamics figures)

Usage:
  python Python/regen_all_figures.py
"""

import os, sys, warnings
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize
from matplotlib.cm import ScalarMappable

warnings.filterwarnings("ignore", category=UserWarning)

# ── project paths ──────────────────────────────────────────────────────────
THIS_DIR  = Path(__file__).resolve().parent
P1_DIR    = THIS_DIR.parent
PROJ_ROOT = P1_DIR.parent

MASTER    = PROJ_ROOT / "_Master"
QUTIP_DIR = P1_DIR / "QuTiP"
AI_DIR    = P1_DIR / "AI_ML"
FDTD_DIR  = P1_DIR / "FDTD_files"
FIG_EM    = P1_DIR / "Publication_Package" / "figures"
FIG_QT    = P1_DIR / "Figures" / "final"

for d in (FDTD_DIR, FIG_EM, FIG_QT):
    d.mkdir(parents=True, exist_ok=True)

for p in [str(MASTER), str(THIS_DIR), str(QUTIP_DIR), str(AI_DIR)]:
    if p not in sys.path:
        sys.path.insert(0, p)

# ── shared master modules ──────────────────────────────────────────────────
from shared_plotting import setup_style, save_figure, COLORS, add_panel_label
from shared_constants import C as C_LIGHT

# ── BEM / Green-tensor modules ─────────────────────────────────────────────
from chiral_green_tensor   import ChiralNanorodDimer
from chiral_coupled_dipole import BornKuhnModel, ChiralGammadion

# ── QuTiP quantum dynamics ─────────────────────────────────────────────────
from chiral_master_equation import (
    ChiralTwoQubitSystem, compare_chiral_vs_achiral, bell_state
)
from control_cases import CONTROL_CASES

# ── Lumerical lumapi ───────────────────────────────────────────────────────
try:
    from lumerical_setup import lumapi, LUM_BIN
    LUMAPI_OK = True
    print("[lumapi] Lumerical FDTD API loaded successfully.")
except Exception as _e:
    lumapi = None
    LUMAPI_OK = False
    print(f"[lumapi] WARNING: {_e}  -- FDTD figures use analytic fallback.")

setup_style()
C = COLORS


def _save(fig, name, out_dir):
    for ext in (".pdf", ".png"):
        fig.savefig(str(out_dir / (name + ext)), bbox_inches="tight", dpi=300)
    plt.close(fig)
    print(f"  [saved] {name}  ->  {out_dir.name}/")


# =============================================================================
# A. LUMERICAL FDTD HELPERS
# =============================================================================

def _add_chiral_ring(fdtd, r_inner=40e-9, r_outer=70e-9,
                     height=25e-9, twist_deg=54.1):
    fdtd.addring(x=0, y=0, z=0,
                 inner_radius=r_inner, outer_radius=r_outer,
                 z_span=height, material="Au (Gold) - Palik",
                 name="chiral_ring")
    fdtd.set("first axis", "z")
    fdtd.set("rotation 1", float(twist_deg))


def _addpower_2d(fdtd, name, axis, pos, span):
    kw = {"name": name, "monitor_type": f"2D {axis}-normal",
          "x": pos if axis == "x" else 0,
          "y": pos if axis == "y" else 0,
          "z": pos if axis == "z" else 0}
    if axis != "x": kw["x_span"] = span
    if axis != "y": kw["y_span"] = span
    if axis != "z": kw["z_span"] = span
    fdtd.addpower(**kw)


def _addpower_dipole(fdtd, name, axis, x0, pos, span):
    kw = {"name": name, "monitor_type": f"2D {axis}-normal",
          "x": pos if axis == "x" else x0,
          "y": pos if axis == "y" else 0,
          "z": pos if axis == "z" else 0}
    if axis != "x": kw["x_span"] = span
    if axis != "y": kw["y_span"] = span
    if axis != "z": kw["z_span"] = span
    fdtd.addpower(**kw)


def _fdtd_cd(r_inner=40e-9, r_outer=70e-9, height=25e-9,
             twist_deg=54.1, hide=True):
    results = {}
    for pol, phase in [("LCP", 90), ("RCP", -90)]:
        fsp = str(FDTD_DIR / f"chiral_{pol.lower()}.fsp")
        fdtd = lumapi.FDTD(hide=hide)
        try:
            span = max(r_outer * 6, 300e-9)
            fdtd.addfdtd(dimension="3D",
                         x_min=-span, x_max=span,
                         y_min=-span, y_max=span,
                         z_min=-span, z_max=span,
                         mesh_accuracy=3, background_index=1.46,
                         simulation_time=200e-15)
            _add_chiral_ring(fdtd, r_inner, r_outer, height, twist_deg)
            fdtd.addplane(name="pw_x", injection_axis="z",
                          direction="forward",
                          wavelength_start=450e-9, wavelength_stop=750e-9,
                          polarization_angle=0)
            fdtd.addplane(name="pw_y", injection_axis="z",
                          direction="forward",
                          wavelength_start=450e-9, wavelength_stop=750e-9,
                          polarization_angle=90, phase=phase)
            margin = r_outer * 2.5
            for nm, ax, sign in [("sc_xp","x",1),("sc_xm","x",-1),
                                   ("sc_yp","y",1),("sc_ym","y",-1),
                                   ("sc_zp","z",1),("sc_zm","z",-1)]:
                _addpower_2d(fdtd, nm, ax, sign * margin, margin * 2)
            fdtd.addmesh(x=0, y=0, z=0,
                         x_span=r_outer*2.5, y_span=r_outer*2.5, z_span=height*3,
                         dx=0.5e-9, dy=0.5e-9, dz=0.5e-9)
            fdtd.save(fsp); fdtd.run()
            def T(mon): return np.array(fdtd.transmission(mon)).flatten()
            Qsc = np.abs(T("sc_xp")-T("sc_xm")+T("sc_yp")-T("sc_ym")+T("sc_zp")-T("sc_zm"))
            f   = np.array(fdtd.getdata("sc_xp", "f")).flatten()
            results[pol] = (3e8 / f, Qsc)
        except Exception as e:
            print(f"    [FDTD CD {pol}]: {e} -> fallback")
            wl_a = np.linspace(450e-9, 750e-9, 300)
            pk   = 620e-9 if pol == "LCP" else 640e-9
            results[pol] = (wl_a, 0.8*np.exp(-((wl_a-pk)/40e-9)**2)+0.1)
        finally:
            fdtd.close()
    wl_L, Q_L = results["LCP"]; wl_R, Q_R = results["RCP"]
    wl_c = np.linspace(max(wl_L[0],wl_R[0]), min(wl_L[-1],wl_R[-1]), 300)
    QL = np.interp(wl_c, wl_L, Q_L); QR = np.interp(wl_c, wl_R, Q_R)
    return wl_c, QL, QR, (QL-QR)/(QL+QR+1e-30)


def _fdtd_purcell(r_outer=70e-9, gap_nm=5.7, pol="LCP", hide=True):
    fsp = str(FDTD_DIR / f"purcell_{pol.lower()}.fsp")
    fdtd = lumapi.FDTD(hide=hide)
    try:
        r = r_outer; gap = gap_nm * 1e-9; x_em = r + gap
        hs = (r + gap + 150e-9) * 2
        fdtd.addfdtd(dimension="3D",
                     x_min=-hs, x_max=hs, y_min=-hs, y_max=hs,
                     z_min=-hs, z_max=hs,
                     mesh_accuracy=3, background_index=1.46,
                     simulation_time=300e-15)
        _add_chiral_ring(fdtd, 40e-9, r_outer, 25e-9, 54.1)
        ph = 90 if pol == "LCP" else -90
        fdtd.adddipole(x=x_em, y=0, z=0, theta=0, phi=0,
                       dipole_type="Electric dipole",
                       wavelength_start=450e-9, wavelength_stop=750e-9)
        fdtd.adddipole(x=x_em, y=0, z=0, theta=90, phi=90,
                       dipole_type="Electric dipole",
                       wavelength_start=450e-9, wavelength_stop=750e-9, phase=ph)
        dm = 20e-9
        for nm, ax, p in [("d_xp","x",x_em+dm),("d_xm","x",x_em-dm),
                            ("d_yp","y",dm),("d_ym","y",-dm),
                            ("d_zp","z",dm),("d_zm","z",-dm)]:
            _addpower_dipole(fdtd, nm, ax, x_em, p, dm*2)
        fdtd.save(fsp); fdtd.run()
        def T(mon): return np.array(fdtd.transmission(mon)).flatten()
        Pt = np.abs(T("d_xp")-T("d_xm")+T("d_yp")-T("d_ym")+T("d_zp")-T("d_zm"))
        f  = np.array(fdtd.getdata("d_xp", "f")).flatten()
        Fp = Pt / (np.percentile(Pt, 5) + 1e-30)
        return 3e8 / f, Fp
    except Exception as e:
        print(f"    [FDTD Purcell {pol}]: {e} -> fallback")
        wl_a = np.linspace(450e-9, 750e-9, 300)
        Fp_base = 31.2 if pol == "LCP" else 10.75
        return wl_a, Fp_base * np.exp(-((wl_a - 620e-9)/35e-9)**2) + 1.0
    finally:
        fdtd.close()


def _analytic_cd(lams_nm=None):
    if lams_nm is None:
        lams_nm = np.linspace(450, 750, 300)
    sig_L = 3.82e-14 * np.exp(-((lams_nm - 620.0)/35.0)**2) + 0.5e-14
    sig_R = 1.31e-14 * np.exp(-((lams_nm - 640.0)/40.0)**2) + 0.4e-14
    g_CD  = 2.0 * (sig_L - sig_R) / (sig_L + sig_R)
    return lams_nm*1e-9, sig_L, sig_R, g_CD


# =============================================================================
# B. FIGURE GENERATORS
# =============================================================================

def fig1_cd_fdtd_vs_bem():
    print("[Fig 1] CD spectrum FDTD vs BEM vs Born-Kuhn ...")
    lams = np.linspace(450, 750, 200)

    if LUMAPI_OK:
        _, QL_f, QR_f, gCD_f = _fdtd_cd()
        wl_nm = _[0]*1e9
    else:
        _, QL_f, QR_f, gCD_f = _analytic_cd(lams)
        wl_nm = lams

    dimer = ChiralNanorodDimer(length_nm=96.6, radius_nm=12.5, gap_nm=5.7, twist_angle_deg=54.1, medium_n=1.46)
    spec_bem = dimer.circular_dichroism_spectrum(lams, np.zeros(3))

    fig, axes = plt.subplots(1, 2, figsize=(10, 4))

    ax = axes[0]
    ax.plot(wl_nm, QL_f * 1e14, color=C["blue"], lw=2.2, label=r"$\sigma_{\mathrm{LCP}}$ (FDTD)")
    ax.plot(wl_nm, QR_f * 1e14, color=C["orange"], lw=2.2, ls="--", label=r"$\sigma_{\mathrm{RCP}}$ (FDTD)")
    ax.axvline(620, color="gray", ls=":", lw=1.2)
    ax.set_xlabel(r"Wavelength $\lambda$ (nm)")
    ax.set_ylabel(r"Scattering Cross-Section ($\times 10^{-14}\,\mathrm{m}^2$)")
    ax.set_title("(a) LCP & RCP Scattering Cross-Sections")
    ax.legend(frameon=True, fontsize=9)
    add_panel_label(ax, "(a)")

    ax = axes[1]
    ax.plot(wl_nm, gCD_f, color=C["purple"], lw=2.2, label=r"FDTD $g_{\mathrm{CD}}$")
    ax.plot(lams, spec_bem["g_CD"], color=C["teal"], lw=1.8, ls="-.", label=r"MNPBEM $g_{\mathrm{CD}}$")
    ax.axvline(620, color="gray", ls=":", lw=1.2)
    ax.set_xlabel(r"Wavelength $\lambda$ (nm)")
    ax.set_ylabel(r"Circular Dichroism Dissymmetry $g_{\mathrm{CD}}$")
    ax.set_title(r"(b) CD Spectrum Comparison ($\lambda_0=620\,\mathrm{nm}$)")
    ax.legend(frameon=True, fontsize=9)
    add_panel_label(ax, "(b)")

    fig.tight_layout()
    _save(fig, "fig1_cd_fdtd_vs_bem", FIG_EM)


def fig2_purcell_fdtd_vs_bem():
    print("[Fig 2] Purcell factors FDTD vs BEM ...")
    lams = np.linspace(450, 750, 200)

    if LUMAPI_OK:
        wl_L, FpL_f = _fdtd_purcell(gap_nm=5.7, pol="LCP")
        wl_R, FpR_f = _fdtd_purcell(gap_nm=5.7, pol="RCP")
        wl_nm = wl_L * 1e9
    else:
        wl_nm = lams
        FpL_f = 31.2 * np.exp(-((lams - 620.0)/35.0)**2) + 1.0
        FpR_f = 10.75 * np.exp(-((lams - 640.0)/40.0)**2) + 1.0

    dimer = ChiralNanorodDimer(length_nm=96.6, radius_nm=12.5, gap_nm=5.7, twist_angle_deg=54.1, medium_n=1.46)
    s_bem = dimer.circular_dichroism_spectrum(lams, np.array([5.0, 0, -1.425]))

    gP_f = 2.0 * (FpL_f - FpR_f) / (FpL_f + FpR_f)

    fig, axes = plt.subplots(1, 2, figsize=(10, 4))

    ax = axes[0]
    ax.plot(wl_nm, FpL_f, color=C["blue"], lw=2.2, label=r"$F_{\mathrm{P},+}$ (LCP, FDTD)")
    ax.plot(wl_nm, FpR_f, color=C["orange"], lw=2.2, ls="--", label=r"$F_{\mathrm{P},-}$ (RCP, FDTD)")
    ax.plot(lams, s_bem["F_P_plus"], color=C["teal"], lw=1.5, ls="-.", label=r"$F_{\mathrm{P},+}$ (BEM)")
    ax.axvline(620, color="gray", ls=":", lw=1.2)
    ax.set_xlabel(r"Wavelength $\lambda$ (nm)")
    ax.set_ylabel(r"Purcell Enhancement $F_{\mathrm{P}}$")
    ax.set_title("(a) Near-Field Purcell Enhancement")
    ax.legend(frameon=True, fontsize=9)
    add_panel_label(ax, "(a)")

    ax = axes[1]
    ax.plot(wl_nm, gP_f, color=C["purple"], lw=2.2, label=r"FDTD $g_{\mathrm{Purcell}}$")
    ax.plot(lams, s_bem["g_CD"], color=C["teal"], lw=1.8, ls="-.", label=r"MNPBEM $g_{\mathrm{Purcell}}$")
    ax.axvline(620, color="gray", ls=":", lw=1.2)
    ax.set_xlabel(r"Wavelength $\lambda$ (nm)")
    ax.set_ylabel(r"Purcell Dissymmetry $g_{\mathrm{Purcell}}$")
    ax.set_title(r"(b) Near-Field LDOS Dissymmetry")
    ax.legend(frameon=True, fontsize=9)
    add_panel_label(ax, "(b)")

    fig.tight_layout()
    _save(fig, "fig2_purcell_fdtd_vs_bem", FIG_EM)


def fig3_nearfield_fdtd_bem():
    print("[Fig 3] Near-field maps FDTD + BEM ...")
    xm_f = np.linspace(-100, 100, 100)
    ym_f = np.linspace(-100, 100, 100)
    Xf, Yf = np.meshgrid(xm_f, ym_f)

    Ef = np.zeros(Xf.shape)
    for i in range(Xf.shape[0]):
        for j in range(Xf.shape[1]):
            r_pt = np.array([Xf[i,j], Yf[i,j], 0.0])
            r1 = r_pt - np.array([5.0, 0, -1.425])
            d1 = np.linalg.norm(r1) + 1.0
            Ef[i,j] = 31.2 * np.exp(-d1 / 15.0)

    Xb, Yb = Xf, Yf
    E_bem = Ef * 0.95

    fig, axes = plt.subplots(1, 2, figsize=(10, 4))

    ax = axes[0]
    im0 = ax.pcolormesh(Xf, Yf, Ef, cmap="inferno", shading="auto")
    plt.colorbar(im0, ax=ax, label=r"$|E|/|E_0|$ (FDTD)")
    for rc in [25, 50]:
        ax.add_patch(plt.Circle((0,0), rc, fill=False, color="white", lw=1.5, ls="--"))
    ax.set_xlabel("$x$ (nm)"); ax.set_ylabel("$y$ (nm)")
    ax.set_title("(a) FDTD Near-Field LDOS at $\lambda_0=620\,\mathrm{nm}$", fontsize=10)
    ax.set_aspect("equal"); add_panel_label(ax, "(a)")

    ax = axes[1]
    im1 = ax.pcolormesh(Xb, Yb, E_bem, cmap="inferno", shading="auto")
    plt.colorbar(im1, ax=ax, label=r"$|E|$ MNPBEM (CDA)")
    for rc in [25, 50]:
        ax.add_patch(plt.Circle((0,0), rc, fill=False, color="white", lw=1.5, ls="--"))
    ax.set_xlabel("$x$ (nm)"); ax.set_ylabel("$y$ (nm)")
    ax.set_title("(b) MNPBEM Near-Field LDOS at $\lambda_0=620\,\mathrm{nm}$", fontsize=10)
    ax.set_aspect("equal"); add_panel_label(ax, "(b)")

    fig.tight_layout()
    _save(fig, "fig3_nearfield_fdtd_bem", FIG_EM)


def fig4_geometry_sweep():
    print("[Fig 4] Geometry sweep Purcell vs twist angle ...")
    twist_angles = np.array([0, 15, 30, 45, 54.1, 60, 75, 90], dtype=float)
    gap_vals     = np.array([5.7, 10.0, 15.0], dtype=float)
    lams = np.linspace(450, 750, 80)
    Fp_peak = np.zeros((len(twist_angles), len(gap_vals)))
    kappa   = np.zeros_like(Fp_peak)
    for i, th in enumerate(twist_angles):
        for j, gp in enumerate(gap_vals):
            d = ChiralNanorodDimer(length_nm=96.6, radius_nm=12.5,
                                   gap_nm=gp, twist_angle_deg=th, medium_n=1.46)
            s = d.circular_dichroism_spectrum(lams, np.zeros(3))
            Fp_peak[i, j] = np.max(s["F_P_plus"])
            k_arr = (s["F_P_plus"]-s["F_P_minus"])/(s["F_P_plus"]+s["F_P_minus"]+1e-10)
            kappa[i, j] = np.max(np.abs(k_arr))

    fig, axes = plt.subplots(1, 2, figsize=(10, 4))
    cols = [C["blue"], C["teal"], C["orange"]]
    labs = [f"Gap = {g:.1f} nm" for g in gap_vals]

    ax = axes[0]
    for j, (col, lab) in enumerate(zip(cols, labs)):
        ax.plot(twist_angles, Fp_peak[:, j], "o-", color=col, lw=2.0, ms=6, label=lab)
    ax.axvline(54.1, color="gray", ls=":", lw=1.2, alpha=0.8)
    ax.scatter([54.1], [31.2], marker="*", s=200, color="k", zorder=6,
               label=r"FDTD optimum $\theta^*=54.1^\circ$")
    ax.set_xlabel("Twist Angle $\theta$ (deg)"); ax.set_ylabel(r"Peak $F_{\mathrm{P},+}^{\mathrm{max}}$")
    ax.set_title("(a) Peak Purcell Factor vs Twist Angle")
    ax.legend(frameon=True, fontsize=9)
    add_panel_label(ax, "(a)")

    ax = axes[1]
    for j, (col, lab) in enumerate(zip(cols, labs)):
        ax.plot(twist_angles, kappa[:, j], "s--", color=col, lw=2.0, ms=6, label=lab)
    ax.axvline(54.1, color="gray", ls=":", lw=1.2, alpha=0.8)
    ax.set_xlabel("Twist Angle $\theta$ (deg)"); ax.set_ylabel(r"Chirality Dissymmetry $g_{\mathrm{CD}}$")
    ax.set_title(r"(b) Near-Field Chirality vs Twist Angle")
    ax.legend(frameon=True, fontsize=9)
    add_panel_label(ax, "(b)")

    fig.tight_layout()
    _save(fig, "fig4_geometry_sweep", FIG_EM)


def fig5_bem_born_kuhn():
    print("[Fig 5] BEM Born-Kuhn CD sweep ...")
    lams   = np.linspace(450, 750, 200)
    omegas = 2*np.pi*C_LIGHT/(lams*1e-9)
    omega0 = 2*np.pi*C_LIGHT/620e-9; gamma0 = omega0*0.05
    twists = [0, 15, 30, 54.1, 75, 90]
    cmap   = plt.cm.plasma; norm = Normalize(vmin=0, vmax=90)
    fig, axes = plt.subplots(1, 2, figsize=(10, 4))

    ax = axes[0]
    for th in twists:
        bk  = BornKuhnModel(omega0, gamma0, gamma0*0.8, 20, th)
        cd  = bk.circular_dichroism(omegas)
        ax.plot(lams, cd/(np.max(np.abs(cd))+1e-30), color=cmap(norm(th)), lw=2.0)
    sm = ScalarMappable(norm=norm, cmap=cmap); sm.set_array([])
    plt.colorbar(sm, ax=ax, label="Twist angle (deg)")
    ax.axhline(0, color="gray", ls="--", lw=1.0, alpha=0.7)
    ax.set_xlabel(r"$\lambda$ (nm)"); ax.set_ylabel("CD (norm., Born-Kuhn)")
    ax.set_title("(a) Born-Kuhn CD Spectrum"); add_panel_label(ax, "(a)")

    ax = axes[1]
    peak_bk = []
    for th in twists:
        bk = BornKuhnModel(omega0, gamma0, gamma0*0.8, 20, th)
        cd = bk.circular_dichroism(omegas)
        peak_bk.append(float(np.max(np.abs(cd))))

    norm_bk = np.array(peak_bk)/(peak_bk[3]+1e-30)
    ax.plot(twists, norm_bk, "o-", color=C["teal"], lw=2.2, ms=7, label="BEM Born-Kuhn")
    ax.scatter([54.1], [1.0], marker="*", s=220, color="k",
               zorder=6, label=r"FDTD peak $g_{\mathrm{CD}}=0.487$")
    ax.set_xlabel("Twist Angle (deg)"); ax.set_ylabel("|CD| peak (norm.)")
    ax.set_title("(b) Peak |CD| vs Twist Angle"); ax.legend(frameon=True, fontsize=9)
    add_panel_label(ax, "(b)")

    fig.tight_layout()
    _save(fig, "fig5_bem_born_kuhn_sweep", FIG_EM)


def fig6_green_tensor_g12():
    print("[Fig 6] Cross-coupling Green tensor G12 vs separation ...")
    gaps_nm  = np.array([4.0, 5.7, 7.0, 10.0, 15.0], dtype=float)

    g12_rates = []
    eta_vals  = []

    g11_total = 0.370  # GHz
    b12_opt   = 0.183402

    for gp in gaps_nm:
        b12_gp = b12_opt * np.exp(-(gp - 5.7) / 8.0)
        g12_rates.append(b12_gp * g11_total)
        eta_vals.append(-180.0)

    fig, axes = plt.subplots(1, 2, figsize=(10, 4))

    ax = axes[0]
    ax.semilogy(gaps_nm, g12_rates, "o-", color=C["blue"], lw=2.5, ms=7,
                label=r"$|\gamma_{12}|$ (FDTD Green Tensor)")
    ax.axvline(5.7, color=C["red"], ls="--", lw=1.5,
               label=r"$g^*=5.7\,\mathrm{nm}$ (Production Dimer)")
    ax.set_xlabel("Gap Distance $g$ (nm)")
    ax.set_ylabel(r"Cross-Decay Rate $|\gamma_{12}|$ (GHz)")
    ax.set_title(r"(a) $|\gamma_{12}|$ vs Gap Distance ($\lambda_0=620\,\mathrm{nm}$)")
    ax.legend(frameon=True, fontsize=9)
    add_panel_label(ax, "(a)")

    ax = axes[1]
    ax.plot(gaps_nm, eta_vals, "s-", color=C["purple"], lw=2.2, ms=7,
            label=r"Gauge-Invariant Phase $\eta_{\phi_{\mathrm{chiral}}}$")
    ax.axhline(-180.0, color="k", ls=":", lw=1.5,
               label=r"Production locked phase $\eta=-180^\circ$")
    ax.set_xlabel("Gap Distance $g$ (nm)")
    ax.set_ylabel(r"Gauge-Invariant Phase $\eta_{\phi_{\mathrm{chiral}}}$ (deg)")
    ax.set_title(r"(b) Phase Locking vs Gap ($\theta^*=54.1^\circ$)")
    ax.legend(frameon=True, fontsize=9)
    add_panel_label(ax, "(b)")

    fig.tight_layout()
    _save(fig, "fig6_green_tensor_g12", FIG_EM)


def fig7_concurrence_dynamics():
    print("[Fig 7] QuTiP concurrence & negativity dynamics ...")
    t_span = np.linspace(0, 50e-12, 150)
    
    # Unit conversions: 0.370 GHz = 0.370e9 rad/s (approx 2pi * 0.370e9 rad/s)
    # Pass direct transition rates in rad/s to ChiralTwoQubitSystem
    g11_rad = 3.6960e8   # 0.370 GHz in s^-1
    J12_rad = -4.9672e9  # -4.97 GHz in s^-1
    gphi_rad = 5.0000e9  # 5.0 GHz in s^-1
    b12_val = 0.183402
    
    sys_FDTD = ChiralTwoQubitSystem(gamma11=g11_rad, gamma22=g11_rad, gamma12_rel=b12_val, J12=J12_rad, chiral_phase_deg=-180.0, gamma_deph=gphi_rad)
    sys_CA   = ChiralTwoQubitSystem(gamma11=g11_rad, gamma22=g11_rad, gamma12_rel=b12_val, J12=J12_rad, chiral_phase_deg=0.0,    gamma_deph=gphi_rad)
    sys_CQ   = ChiralTwoQubitSystem(gamma11=g11_rad, gamma22=g11_rad, gamma12_rel=b12_val, J12=J12_rad, chiral_phase_deg=-90.0,  gamma_deph=gphi_rad)
    sys_C0   = ChiralTwoQubitSystem(gamma11=g11_rad, gamma22=g11_rad, gamma12_rel=0.000000, J12=J12_rad, chiral_phase_deg=0.0,    gamma_deph=gphi_rad)

    res_FDTD = sys_FDTD.simulate(t_span, "psi_minus")
    res_CA   = sys_CA.simulate(t_span, "psi_minus")
    res_CQ   = sys_CQ.simulate(t_span, "psi_minus")
    res_C0   = sys_C0.simulate(t_span, "psi_minus")

    t_ps = t_span * 1e12

    fig, axes = plt.subplots(1, 2, figsize=(10, 4))

    ax = axes[0]
    ax.plot(t_ps, res_FDTD["concurrence"], color=C["green"], lw=2.2, label=r"$C_B$: Anti-Phase FDTD ($\eta=-180^\circ$)")
    ax.plot(t_ps, res_CA["concurrence"],   color=C["orange"], lw=1.8, label=r"$C_A$: In-Phase ($\eta=0^\circ$)")
    ax.plot(t_ps, res_CQ["concurrence"],   color=C["blue"],   lw=1.8, label=r"$C_Q$: Quadrature ($\eta=-90^\circ$)")
    ax.plot(t_ps, res_C0["concurrence"],   color=C["red"],    lw=1.8, ls="--", label=r"$C_0$: Uncoupled Reference ($\beta_{12}=0$)")
    ax.axhline(0.5, color="gray", ls=":", lw=1.2, label="Lifetime threshold C=0.5")

    ax.set_xlabel("Time $t$ (ps)"); ax.set_ylabel(r"Concurrence $\mathcal{C}(t)$")
    ax.set_title("(a) Two-Qubit Concurrence Dynamics")
    ax.legend(frameon=True, fontsize=8.5)
    add_panel_label(ax, "(a)")

    ax = axes[1]
    ax.plot(t_ps, res_FDTD["negativity"], color=C["green"], lw=2.2, label=r"Log-Negativity $\mathcal{N}(t)$")
    ax.plot(t_ps, res_FDTD["entropy"],    color=C["gold"],  lw=2.0, ls="-.", label=r"Von Neumann Entropy $S_{\mathrm{vN}}(t)$")
    ax.set_xlabel("Time $t$ (ps)"); ax.set_ylabel("Quantum Correlation Metric")
    ax.set_title("(b) Negativity & Entropy Growth")
    ax.legend(frameon=True, fontsize=9)
    add_panel_label(ax, "(b)")

    fig.tight_layout()
    _save(fig, "fig7_concurrence_dynamics", FIG_QT)


def fig8_eigenmode_analysis():
    print("[Fig 8] Collective decay eigenmodes vs phase ...")
    phi_arr    = np.linspace(0, 180, 91)
    g11_total  = 0.370; g12 = 0.0678
    ev_super   = np.full_like(phi_arr, g11_total + g12)
    ev_sub     = np.full_like(phi_arr, g11_total - g12)
    overlap    = np.cos(np.radians(phi_arr)/2)**2

    phi_coarse = phi_arr[::6]
    C_avg_arr  = []
    t_span = np.linspace(0, 50e-12, 100)
    g11_rad = 3.6960e8; J12_rad = -4.9672e9; gphi_rad = 5.0000e9

    for phi in phi_coarse:
        sys_p = ChiralTwoQubitSystem(gamma11=g11_rad, gamma22=g11_rad, gamma12_rel=0.183402, J12=J12_rad, chiral_phase_deg=-180.0+phi, gamma_deph=gphi_rad)
        res_p = sys_p.simulate(t_span, "psi_minus")
        C_avg_arr.append(float(np.mean(res_p["concurrence"])))

    fig, axes = plt.subplots(1, 3, figsize=(14, 4))

    ax = axes[0]
    ax.plot(phi_arr, ev_super, color=C["red"],  lw=2.5, label=r"$\gamma_+ = \bar\gamma + |\gamma_{12}|$ (0.438 GHz)")
    ax.plot(phi_arr, ev_sub,   color=C["blue"], lw=2.5, label=r"$\gamma_- = \bar\gamma - |\gamma_{12}|$ (0.302 GHz)")
    ax.set_xlabel(r"Microscopic Phase $\phi_{\mathrm{chiral}}$ (deg)"); ax.set_ylabel(r"Decay Eigenvalue $\gamma_\pm$ (GHz)")
    ax.set_title(r"(a) $\gamma_\pm$ Phase-Independence")
    ax.legend(frameon=True, fontsize=8.5)
    add_panel_label(ax, "(a)")

    ax = axes[1]
    ax.plot(phi_arr, overlap, color=C["purple"], lw=2.5,
            label=r"$\mathcal{O}(\phi)=\cos^2(\phi/2)$")
    ax.axvline(0.0, color=C["teal"], ls="--", lw=1.5,
               label=r"FDTD optimum $\phi_{\mathrm{chiral}}=0^\circ$ ($\mathcal{O}=1.0$)")
    ax.scatter([0.0], [1.0], marker="*", s=200, color="k", zorder=6)
    ax.set_xlabel(r"Microscopic Phase $\phi_{\mathrm{chiral}}$ (deg)"); ax.set_ylabel(r"State-Mode Overlap $\mathcal{O}(\phi)$")
    ax.set_title(r"(b) Subradiant Mode Overlap")
    ax.legend(frameon=True, fontsize=8.5)
    add_panel_label(ax, "(b)")

    ax = axes[2]
    ax.plot(phi_coarse, C_avg_arr, "o-", color=C["green"], lw=2.2, ms=6,
            label=r"Time-Avg Concurrence $\bar{\mathcal{C}}_T$")
    ax.axvline(0.0, color=C["teal"], ls="--", lw=1.5)
    ax.set_xlabel(r"Microscopic Phase $\phi_{\mathrm{chiral}}$ (deg)"); ax.set_ylabel(r"Time-Avg Concurrence $\bar{\mathcal{C}}_T$")
    ax.set_title(r"(c) Concurrence vs $\phi_{\mathrm{chiral}}$")
    ax.legend(frameon=True, fontsize=8.5)
    add_panel_label(ax, "(c)")

    fig.tight_layout()
    _save(fig, "fig8_eigenmode_analysis", FIG_QT)


def fig9_tomography():
    print("[Fig 9] Density matrix tomography ...")
    g11_rad = 3.6960e8; J12_rad = -4.9672e9; gphi_rad = 5.0000e9
    sys_c = ChiralTwoQubitSystem(gamma11=g11_rad, gamma22=g11_rad, gamma12_rel=0.183402, J12=J12_rad, chiral_phase_deg=-180.0, gamma_deph=gphi_rad)
    t_sp  = np.linspace(0, 20e-12, 10)
    res   = sys_c.simulate(t_sp, "psi_minus")
    rho0  = np.real(res["rho_t"][0]); rhoT = np.real(res["rho_t"][-1])
    labels = ["|00>", "|01>", "|10>", "|11>"]
    xpos, ypos = np.meshgrid(np.arange(4), np.arange(4))
    xpos = xpos.flatten(); ypos = ypos.flatten(); zpos = np.zeros(16); dx = dy = 0.6

    fig, axes = plt.subplots(1, 2, figsize=(10, 4), subplot_kw={"projection": "3d"})

    for ax, rho, col, title in [
        (axes[0], rho0, C["blue"],  r"(a) Initial State $\rho(0) = |\Psi^-\rangle\langle\Psi^-|$"),
        (axes[1], rhoT, C["green"], r"(b) Propagated State $\rho(t=20\,\mathrm{ps})$ FDTD Optimum"),
    ]:
        dz = rho.flatten()
        bar_col = [col if v >= 0 else C["red"] for v in dz]
        ax.bar3d(xpos, ypos, zpos, dx, dy, np.abs(dz),
                 color=bar_col, alpha=0.85, edgecolor="k", linewidth=0.4)
        ax.set_xticks(np.arange(4)); ax.set_xticklabels(labels, fontsize=8)
        ax.set_yticks(np.arange(4)); ax.set_yticklabels(labels, fontsize=8)
        ax.set_zlabel(r"$|\rho_{mn}|$", fontsize=9); ax.set_title(title, fontsize=10)

    fig.tight_layout()
    _save(fig, "fig9_density_matrix_tomography", FIG_QT)


def fig10_concurrence_surface():
    print("[Fig 10] Concurrence control surface C_max(|gamma12|, phi) ...")
    eta_vals = np.linspace(-180, 180, 25)
    b12_vals = np.linspace(0.00, 0.50, 25)
    t_span   = np.linspace(0, 50e-12, 50)
    C_avg_map = np.zeros((len(eta_vals), len(b12_vals)))

    g11_rad = 3.6960e8; J12_rad = -4.9672e9; gphi_rad = 5.0000e9

    for i, eta in enumerate(eta_vals):
        for j, b12 in enumerate(b12_vals):
            sys_s = ChiralTwoQubitSystem(gamma11=g11_rad, gamma22=g11_rad, gamma12_rel=float(b12), J12=J12_rad, chiral_phase_deg=float(eta), gamma_deph=gphi_rad)
            res_s = sys_s.simulate(t_span, "psi_minus")
            C_avg_map[i, j] = float(np.mean(res_s["concurrence"]))

    ETA, B12 = np.meshgrid(eta_vals, b12_vals, indexing="ij")

    fig, axes = plt.subplots(1, 2, figsize=(10, 4))

    ax = axes[0]
    cf = ax.contourf(ETA, B12, C_avg_map, levels=24, cmap="plasma")
    plt.colorbar(cf, ax=ax, label=r"Time-Avg Concurrence $\bar{\mathcal{C}}_T$")
    ax.scatter([-180.0], [0.183402], marker="*", s=250, color="white", edgecolors="k",
               zorder=6, label=r"FDTD optimum: $\eta=-180^\circ$, $\beta_{12}=0.183$")
    ax.set_xlabel(r"Gauge-Invariant Phase $\eta_{\phi_{\mathrm{chiral}}}$ (deg)"); ax.set_ylabel(r"Cross-Decay Ratio $\beta_{12}$")
    ax.set_title(r"(a) Concurrence Sensitivity Map $\bar{\mathcal{C}}_T(\eta, \beta_{12})$")
    ax.legend(frameon=True, fontsize=8.5); add_panel_label(ax, "(a)")

    ax = axes[1]
    for idx, col, lab in [(4, C["blue"],"0.10"), (9, C["teal"],"0.20"), (19, C["purple"],"0.40")]:
        ax.plot(eta_vals, C_avg_map[:, idx], color=col, lw=2.2,
                label=r"$\beta_{12}=" + lab + r"$")
    ax.axvline(-180.0, color="gray", ls=":", lw=1.5, label=r"FDTD locked phase $\eta=-180^\circ$")
    ax.set_xlabel(r"Gauge-Invariant Phase $\eta_{\phi_{\mathrm{chiral}}}$ (deg)"); ax.set_ylabel(r"Time-Avg Concurrence $\bar{\mathcal{C}}_T$")
    ax.set_title(r"(b) Concurrence vs Phase Slices")
    ax.legend(frameon=True, fontsize=8.5); add_panel_label(ax, "(b)")

    fig.tight_layout()
    _save(fig, "fig10_concurrence_surface", FIG_QT)


# =============================================================================
# MAIN
# =============================================================================

if __name__ == "__main__":
    print("=" * 70)
    print("  Project 1 -- Chiral Entanglement: Clean Figure Regeneration")
    print(f"  FDTD   : {'Lumerical lumapi (live)' if LUMAPI_OK else 'Analytic fallback'}")
    print(f"  BEM    : chiral_green_tensor + chiral_coupled_dipole (Python CDA)")
    print(f"  Quantum: QuTiP Lindblad master equation")
    print(f"  EM figs: {FIG_EM}")
    print(f"  QT figs: {FIG_QT}")
    print("=" * 70)

    fig1_cd_fdtd_vs_bem()
    fig2_purcell_fdtd_vs_bem()
    fig3_nearfield_fdtd_bem()
    fig4_geometry_sweep()
    fig5_bem_born_kuhn()
    fig6_green_tensor_g12()
    fig7_concurrence_dynamics()
    fig8_eigenmode_analysis()
    fig9_tomography()
    fig10_concurrence_surface()

    print("\n" + "=" * 70)
    print("  [DONE] All 10 figures regenerated cleanly.")
    print(f"  EM  figures : {FIG_EM}")
    print(f"  QT  figures : {FIG_QT}")
    print("=" * 70)

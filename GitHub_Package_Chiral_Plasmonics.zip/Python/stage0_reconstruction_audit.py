﻿"""
stage0_reconstruction_audit.py
================================
STAGE 0 RECONSTRUCTION AUDIT

Recovers all parameters from CDA Green tensors and produces a
definitive parameter verdict — 8-stage forensic protocol.

DO NOT hard-code any manuscript numbers. ALL values computed from
Green tensors and reported.

Outputs:
  stage0_audit_results.json   (machine-readable, for manuscript use)
  stage0_audit_report.txt     (human-readable full report)
"""

import sys, os, json
import numpy as np
import scipy.linalg as la
from pathlib import Path

HERE       = Path(__file__).parent
PROJ_ROOT  = HERE.parent
PYTHON_DIR = PROJ_ROOT / "Python"
QUTIP_DIR  = PROJ_ROOT / "QuTiP"

for p in [str(PYTHON_DIR), str(QUTIP_DIR), str(HERE)]:
    if p not in sys.path:
        sys.path.insert(0, p)

from chiral_green_tensor import ChiralNanorodDimer, circular_polarization_vectors
from chiral_master_equation import ChiralTwoQubitSystem, concurrence, bell_state
from shared_constants import C as C_LIGHT, MU0, HBAR, NM_TO_M

GEOM = dict(
    length_nm=96.6, radius_nm=12.5, gap_nm=5.7,
    twist_angle_deg=54.1, material="Au", medium_n=1.46,
)
LAM0_NM   = 620.0
D0_Cm     = 3.0 * 3.336e-30
T_PS_OBS  = 50.0
N_TIMES   = 500
GAMMA_PHI = 0.005e12
SEP = "=" * 72
lines = []
results = {}

def log(msg=""):
    print(msg)
    lines.append(str(msg))

def section(title):
    log(); log(SEP); log(f"  {title}"); log(SEP)


# ── STAGE 0: Raw Green tensors ────────────────────────────────────────────────
section("STAGE 0: Raw Complex Green Tensor Recovery")

dimer  = ChiralNanorodDimer(**GEOM)
omega0 = 2.0 * np.pi * C_LIGHT / (LAM0_NM * NM_TO_M)
k_nm   = 2.0 * np.pi * dimer.medium_n / LAM0_NM

r1_nm = np.array([0.0, 0.0,  2.85])
r2_nm = np.array([0.0, 0.0, -2.85])

ImG0_nm = (k_nm / (6.0 * np.pi)) * np.eye(3, dtype=complex)
G11 = (ImG0_nm + dimer.green_tensor(r1_nm, LAM0_NM)) * 1e9
G22 = (ImG0_nm + dimer.green_tensor(r2_nm, LAM0_NM)) * 1e9
G12 = dimer.green_tensor_cross(r1_nm, r2_nm, LAM0_NM) * 1e9
G21 = dimer.green_tensor_cross(r2_nm, r1_nm, LAM0_NM) * 1e9

recip_err = float(np.max(np.abs(G12 - G21.T)))
log(f"  omega_0 = {omega0:.6e} rad/s")
log(f"  G11[0,0] = {G11[0,0]:.6e}")
log(f"  G12[0,0] = {G12[0,0]:.6e}")
log(f"  G21[0,0] = {G21[0,0]:.6e}")
log(f"  Reciprocity ||G12 - G21^T||_max = {recip_err:.3e}")
results["stage0"] = {"G11_00_re": G11[0,0].real, "G12_00_re": G12[0,0].real, "reciprocity_err": recip_err}


# ── STAGE 1: Build Gamma and J ────────────────────────────────────────────────
section("STAGE 1: Build Gamma and J from Hermitian-Kernel ImG")

e_plus, e_minus = circular_polarization_vectors()
d1 = D0_Cm * e_plus
d2 = D0_Cm * e_minus
pf_g = 2.0 * MU0 * omega0**2 / HBAR
pf_J = -MU0 * omega0**2 / HBAR

def ImG_mQED(Gij, Gji):   return (Gij - np.conj(Gji).T) / (2j)
def ReG_sym(Gij, Gji):    return (Gij + np.conj(Gji).T) / 2.0
def gij(Gij, Gji, di, dj): return complex(pf_g * (np.conj(di) @ ImG_mQED(Gij, Gji) @ dj))
def Jij(Gij, Gji, di, dj): return complex(pf_J * (np.conj(di) @ ReG_sym(Gij, Gji) @ dj))

gamma11 = gij(G11, G11, d1, d1)
gamma22 = gij(G22, G22, d2, d2)
gamma12 = gij(G12, G21, d1, d2)
gamma21 = gij(G21, G12, d2, d1)
Gamma   = np.array([[gamma11, gamma12], [gamma21, gamma22]], dtype=complex)

J11 = Jij(G11, G11, d1, d1); J22 = Jij(G22, G22, d2, d2)
J12 = Jij(G12, G21, d1, d2); J21 = Jij(G21, G12, d2, d1)
J_mat = np.array([[J11, J12], [J21, J22]], dtype=complex)

phi_g12 = float(np.degrees(np.angle(gamma12)))
phi_J12 = float(np.degrees(np.angle(J12)))
beta12  = float(abs(gamma12) / gamma11.real)

if abs(J12) > 1e-30:
    eta = phi_g12 - phi_J12
    eta = float(((eta + 180.0) % 360.0) - 180.0)
else:
    eta = phi_g12

log(f"  gamma11 = {gamma11.real:.6e} rad/s")
log(f"  gamma22 = {gamma22.real:.6e} rad/s")
log(f"  gamma12 = {gamma12:.6e}")
log(f"  |gamma12| = {abs(gamma12):.6e},  phi = {phi_g12:.4f} deg")
log(f"  J12     = {J12:.6e},  phi_J = {phi_J12:.4f} deg")
log(f"  beta12  = {beta12:.6f}")
log(f"  eta (gauge-invariant) = {eta:.4f} deg")
results["stage1"] = {
    "gamma11": gamma11.real, "gamma22": gamma22.real,
    "gamma12_abs": abs(gamma12), "phi_gamma12_deg": phi_g12,
    "beta12": beta12, "J12_re": J12.real, "J12_im": J12.imag,
    "phi_J12_deg": phi_J12, "eta_deg": eta,
}


# ── STAGE 2: Verify Gamma ─────────────────────────────────────────────────────
section("STAGE 2: Gamma Structural Verification")

herm_err = float(np.max(np.abs(Gamma - np.conj(Gamma).T)))
herm_ok  = herm_err < 1e-6 * float(np.max(np.abs(Gamma)))
evals_G  = np.linalg.eigvalsh(Gamma)
lam_min  = float(np.min(evals_G)); lam_max = float(np.max(evals_G))
psd_ok   = lam_min >= -1e-8 * lam_max
det_G    = float((gamma11 * gamma22 - abs(gamma12)**2).real)
cs_ok    = abs(gamma12)**2 <= gamma11.real * gamma22.real + 1e-10

log(f"  ||Gamma - Gamma†||_max = {herm_err:.3e}  {'PASS' if herm_ok else 'FAIL'}")
log(f"  lambda_min = {lam_min:.6e}  {'PASS PSD' if psd_ok else 'FAIL NOT PSD'}")
log(f"  det(Gamma) = {det_G:.6e}  {'PASS > 0' if det_G > 0 else 'FAIL'}")
log(f"  Cauchy-Schwarz: {'PASS' if cs_ok else 'FAIL'}")
log(f"  J Hermiticity err = {float(np.max(np.abs(J_mat - np.conj(J_mat).T))):.3e}")
results["stage2"] = {"herm_ok": herm_ok, "psd_ok": psd_ok, "det_Gamma": det_G,
                     "lambda_min": lam_min, "lambda_max": lam_max, "cauchy_schwarz_ok": cs_ok}


# ── STAGE 3: [J, Gamma] commutator ───────────────────────────────────────────
section("STAGE 3: [J, Gamma] Commutator — Actual Computed Value")

J_1exc     = np.array([[J11.real, J12], [np.conj(J12), J22.real]], dtype=complex)
G_1exc     = np.array([[gamma11, gamma12], [np.conj(gamma12), gamma22]], dtype=complex)
comm       = J_1exc @ G_1exc - G_1exc @ J_1exc
nJ   = float(np.linalg.norm(J_1exc, "fro"))
nG   = float(np.linalg.norm(G_1exc, "fro"))
nc   = float(np.linalg.norm(comm, "fro"))
eta_JG = nc / (nJ * nG) if (nJ * nG) > 0 else float("nan")

log(f"  ||[J, Gamma]||_F = {nc:.6e}")
log(f"  eta_[J,Gamma]    = {eta_JG:.6f}")
if eta_JG < 0.01:
    verdict3 = "J and Gamma SHARE eigenvectors — hybridization NOT demonstrated"
elif eta_JG > 0.5:
    verdict3 = "Strong coherent-dissipative hybridization CONFIRMED"
else:
    verdict3 = f"Moderate hybridization (eta={eta_JG:.4f})"
log(f"  VERDICT: {verdict3}")
results["stage3"] = {"eta_JGamma": eta_JG, "norm_comm": nc, "verdict": verdict3}


# ── STAGE 4: Canonical Lindblad from Gamma = U Lambda U† ─────────────────────
section("STAGE 4: Canonical Lindblad Operator Construction")

evals4, evecs4 = np.linalg.eigh(G_1exc)
log(f"  lambda_- = {evals4[0]:.6e},  lambda_+ = {evals4[1]:.6e}")

# Verify reconstruction: sum_mu lambda_mu * |u_mu><u_mu| = Gamma
Gamma_recon = sum(evals4[mu] * np.outer(evecs4[:,mu], np.conj(evecs4[:,mu])) for mu in range(2))
recon_err   = float(np.max(np.abs(Gamma_recon - G_1exc)))
recon_ok    = recon_err < 1e-8 * float(np.max(np.abs(G_1exc)))

log(f"  U[:,0] = {evecs4[:,0]}")
log(f"  U[:,1] = {evecs4[:,1]}")
log(f"  Reconstruction ||Gamma_recon - Gamma||_max = {recon_err:.3e}  {'PASS' if recon_ok else 'FAIL'}")
results["stage4"] = {"lambda_minus": float(evals4[0]), "lambda_plus": float(evals4[1]),
                     "reconstruction_err": recon_err, "reconstruction_ok": recon_ok}


# ── STAGE 5: Solve GKSL with correct params ───────────────────────────────────
section("STAGE 5: Full GKSL Master Equation — Correct Parameters")

phi_c = float(np.degrees(np.angle(gamma12)))
J12v  = float(J12.real)

sys5 = ChiralTwoQubitSystem(
    omega_e1=0., omega_e2=0.,
    gamma11=gamma11.real, gamma22=gamma22.real,
    gamma12_abs=abs(gamma12), chiral_phase_deg=phi_c,
    J12=J12v, gamma_deph=GAMMA_PHI
)
t_arr = np.linspace(0, T_PS_OBS * 1e-12, N_TIMES)
r5    = sys5.simulate(t_arr, initial_state="psi_minus")

C_avg5 = float(np.mean(r5["concurrence"]))
idx20  = np.argmin(np.abs(r5["times_ps"] - 20.0))
C_20   = float(r5["concurrence"][idx20])
bh5    = np.where(r5["concurrence"] < 0.5)[0]
tau5   = float(r5["times_ps"][bh5[0]]) if len(bh5) > 0 else T_PS_OBS

log(f"  C_avg(T=50ps) = {C_avg5:.6f}")
log(f"  C(t=20ps)     = {C_20:.6f}")
log(f"  tau_C(0.5)    = {tau5:.2f} ps")
results["stage5"] = {"C_avg": C_avg5, "C_at_20ps": C_20, "tau_C05_ps": tau5,
                     "phi_c_used": phi_c, "J12_used": J12v}


# ── STAGE 6: Achiral baseline ─────────────────────────────────────────────────
section("STAGE 6: Achiral Reference Baseline")

sys6 = ChiralTwoQubitSystem(
    omega_e1=0., omega_e2=0.,
    gamma11=gamma11.real, gamma22=gamma22.real,
    gamma12_abs=0., chiral_phase_deg=0., J12=J12v, gamma_deph=GAMMA_PHI
)
r6     = sys6.simulate(t_arr, initial_state="psi_minus")
C_ach  = float(np.mean(r6["concurrence"]))
bh6    = np.where(r6["concurrence"] < 0.5)[0]
tau_ach= float(r6["times_ps"][bh6[0]]) if len(bh6) > 0 else T_PS_OBS
delta_C = C_avg5 - C_ach

log(f"  C_avg achiral = {C_ach:.6f},  tau_C(0.5) = {tau_ach:.2f} ps")
log(f"  Delta_C (chiral - achiral) = {delta_C:+.6f}")
results["stage6"] = {"C_avg_achiral": C_ach, "tau_achiral_ps": tau_ach, "delta_C": delta_C}


# ── STAGE 7: Factorial control ────────────────────────────────────────────────
section("STAGE 7: Factorial Control Experiment")

b12 = abs(gamma12) / gamma11.real
g11 = gamma11.real

def run_case(label, beta, phi_deg):
    s = ChiralTwoQubitSystem(
        omega_e1=0., omega_e2=0.,
        gamma11=g11, gamma22=g11,
        gamma12_abs=beta * g11, chiral_phase_deg=phi_deg,
        J12=J12v, gamma_deph=GAMMA_PHI
    )
    r    = s.simulate(t_arr, initial_state="psi_minus")
    Cavg = float(np.mean(r["concurrence"]))
    bh   = np.where(r["concurrence"] < 0.5)[0]
    tau  = float(r["times_ps"][bh[0]]) if len(bh) > 0 else T_PS_OBS
    log(f"  {label:<30}: beta={beta:.4f} phi={phi_deg:8.2f}deg  C_avg={Cavg:.4f}  tau={tau:.1f}ps")
    return Cavg, tau

log(f"  gamma_11={g11:.4e} J12={J12v:.4e} beta12={b12:.6f} phi={phi_c:.4f}deg")
log("")
C0,  t0  = run_case("C0: Achiral (beta=0)",      0.0,     0.0)
CA,  tA  = run_case("CA: Amplitude only",         b12,     0.0)
CB,  tB  = run_case("CB: Phase only (b12/2)",     b12/2,   phi_c)
CAB, tAB = run_case("CAB: Full FDTD",             b12,     phi_c)

Dint = CAB - CA - CB + C0
log(f"  Delta_int = {Dint:+.6f}")
if abs(Dint) < 1e-4:
    log("  VERDICT: Strictly additive (Delta_int ~ 0)")
elif Dint > 0.01:
    log("  VERDICT: Non-additive SYNERGISTIC enhancement")
else:
    log("  VERDICT: Non-additive cancellation")
log(f"  Phase effect (CAB - C0) = {CAB - C0:+.6f}")
results["stage7"] = {
    "C0": C0, "CA": CA, "CB": CB, "CAB": CAB,
    "tau_C0": t0, "tau_CA": tA, "tau_CB": tB, "tau_CAB": tAB,
    "Delta_int": Dint, "phase_effect": CAB - C0,
    "beta12_used": b12, "phi_c_used": phi_c,
}


# ── STAGE 8: Definitive verdict ───────────────────────────────────────────────
section("STAGE 8: Definitive Parameter Verdict")

log(f"  === DEFINITIVE PARAMETERS (from CDA Green tensor) ===")
log(f"  gamma_11   = {gamma11.real:.6e} rad/s")
log(f"  gamma_22   = {gamma22.real:.6e} rad/s")
log(f"  |gamma_12| = {abs(gamma12):.6e} rad/s")
log(f"  beta_12    = {b12:.6f}")
log(f"  phi_chiral = {phi_c:.4f} deg  [arg(gamma_12), basis-dep]")
log(f"  eta (gauge-inv) = {eta:.4f} deg")
log(f"  J_12       = {J12v:.6e} rad/s")
log(f"  eta_[J,Gamma] = {eta_JG:.6f}")
log(f"  C_avg (FDTD) = {C_avg5:.6f}")
log(f"  C_avg (achiral) = {C_ach:.6f}")
log(f"  Delta_C = {delta_C:+.6f}")
log(f"  Delta_int = {Dint:+.6f}")
log("")

scenario = "A" if b12 > 0.5 else "B"
log(f"  SCENARIO {scenario}: {'High-beta chiral coupling dominant' if scenario == 'A' else 'Low-beta, coherent coupling dominant'}")

log(f"")
log(f"  CONSISTENCY CHECK vs pra_physics_test_results.json:")
log(f"    test5: beta_fdtd=0.890932, phi=74.3 deg, eta_JG=0.9057")
log(f"    This run: beta={b12:.6f}, phi={phi_c:.4f} deg, eta_JG={eta_JG:.6f}")
diff_b = abs(b12 - 0.890932)
diff_p = abs(phi_c - 74.3)
consistent = diff_b < 0.05 and diff_p < 5.0
log(f"    diff_beta={diff_b:.4f}, diff_phi={diff_p:.4f}deg  -> {'CONSISTENT' if consistent else 'INCONSISTENT'}")

if consistent:
    log(f"  -> The FDTD/Supplement values are CORRECT.")
    log(f"  -> The main manuscript values (beta=0.1761, eta=-180 deg) were WRONG.")
else:
    log(f"  -> INVESTIGATION REQUIRED. Likely dipole convention or emitter position mismatch.")

results["stage8"] = {
    "scenario": scenario,
    "beta12_computed": b12, "phi_chiral": phi_c, "eta_deg": eta,
    "eta_JGamma": eta_JG,
    "consistent_with_test5": consistent,
    "diff_beta": diff_b, "diff_phi": diff_p,
    "manuscript_beta_was": 0.1761,
    "manuscript_eta_was": -180.0,
}

# ── Write outputs ─────────────────────────────────────────────────────────────
json_path   = HERE / "stage0_audit_results.json"
report_path = HERE / "stage0_audit_report.txt"

with open(json_path, "w") as f:
    json.dump(results, f, indent=2, default=str)
with open(report_path, "w", encoding="utf-8") as f:
    f.write("\n".join(lines))

log(f"")
log(f"  Written: {json_path}")
log(f"  Written: {report_path}")
log(SEP)
log("  STAGE 0 AUDIT COMPLETE")
log(SEP)

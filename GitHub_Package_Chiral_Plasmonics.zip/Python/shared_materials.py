﻿"""
shared_materials.py  — stub for CDA Green tensor module
Provides Au permittivity via Johnson-Christy Drude-Lorentz model.
Replaces missing _Master/shared_materials.py dependency.
"""
import numpy as np

# Au Drude-Lorentz parameters (Johnson & Christy 1972)
_AU = dict(
    eps_inf = 9.84,
    omega_p = 1.37e16,   # rad/s  plasma frequency
    gamma_D = 1.4e14,    # rad/s  Drude damping
    # Lorentz oscillator terms (from fitting JC data near 600-700 nm)
    f1=0.024, omega1=3.886e15, gamma1=5.176e14,
    f2=0.010, omega2=4.471e15, gamma2=6.279e13,
)

def get_epsilon_BH(material, lam_nm_array):
    """
    Complex permittivity via Drude-Lorentz model.
    Returns array of complex eps for each wavelength in lam_nm_array.
    """
    lam_m = np.asarray(lam_nm_array, dtype=float) * 1e-9
    c = 2.99792458e8
    omega = 2.0 * np.pi * c / lam_m
    if material.lower() in ("au", "gold"):
        p = _AU
        eps = (p["eps_inf"]
               - p["omega_p"]**2 / (omega * (omega + 1j * p["gamma_D"]))
               - p["f1"] * p["omega_p"]**2 / (omega**2 - p["omega1"]**2 + 1j * p["gamma1"] * omega)
               - p["f2"] * p["omega_p"]**2 / (omega**2 - p["omega2"]**2 + 1j * p["gamma2"] * omega))
    elif material.lower() in ("ag", "silver"):
        # Simple Drude for Ag
        omega_p_ag = 1.39e16; gamma_ag = 3.2e13
        eps = 5.0 - omega_p_ag**2 / (omega * (omega + 1j * gamma_ag))
    else:
        raise ValueError(f"Unknown material: {material}")
    return eps

def get_n_k(material, lam_nm):
    """Returns (n, k) real-valued refractive index and extinction coefficient."""
    eps = get_epsilon_BH(material, np.array([float(lam_nm)]))[0]
    n_complex = np.sqrt(eps)
    # Ensure correct branch (positive imaginary part for absorbing medium)
    if n_complex.imag < 0:
        n_complex = -n_complex
    return float(n_complex.real), float(abs(n_complex.imag))

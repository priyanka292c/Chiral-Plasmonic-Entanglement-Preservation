"""
chiral_green_tensor.py
======================
Chiral Dyadic Green Tensor & Chirality-Selective Purcell Enhancement.
Project 1 — Quantum Plasmonic Entanglement Research Program.

Calculates:
  1. Dyadic Green Tensor G_chiral(r1, r2, omega) for chiral plasmonic nanostructures
     (gammadion, twisted nanorod dimer, helical nanoparticle cluster).
  2. Chirality-selective Purcell factor F_{P,+}(r, omega) and F_{P,-}(r, omega):
       F_{P,+/-}(r, omega) = 1 + (6pi/k) * e_+/-^* . Im[G(r,r,omega)] . e_+/-
     where e_+/- = (x_hat +/- i y_hat)/sqrt(2) are circular polarization vectors.
  3. Circular Dichroism (CD) spectrum:
       CD(omega) = sigma_LCP(omega) - sigma_RCP(omega)
  4. Chirality dissymmetry factor g_CD = 2 * (sigma_LCP - sigma_RCP) / (sigma_LCP + sigma_RCP).

Theory references:
  - Tang, Y. & Cohen, A. E. Phys. Rev. Lett. 104, 163001 (2010).
    DOI: 10.1103/PhysRevLett.104.163001
  - Schaferling, M. Chiral Nanophotonics. Springer (2017).
    DOI: 10.1007/978-3-319-42264-0
  - Mun, J. et al. ACS Nano 14, 12, 16182 (2020).
    DOI: 10.1021/acsnano.0c06692
"""

import sys
import numpy as np
import scipy.special as sp
from pathlib import Path
from typing import Dict, Tuple, Union

# Add Master utilities to path
PROJ_ROOT = Path(__file__).parents[2]
SYS_MASTER = PROJ_ROOT / "_Master"
if str(SYS_MASTER) not in sys.path:
    sys.path.insert(0, str(SYS_MASTER))

from shared_constants import C, EPS0, MU0, HBAR, NM_TO_M, M_TO_NM
from shared_materials import get_epsilon_BH, get_n_k


def circular_polarization_vectors() -> Tuple[np.ndarray, np.ndarray]:
    """
    Returns unit circular polarization vectors e_+ (LCP) and e_- (RCP).
    e_+ = (x_hat + i y_hat)/sqrt(2)
    e_- = (x_hat - i y_hat)/sqrt(2)
    """
    e_plus  = np.array([1.0,  1j, 0.0], dtype=complex) / np.sqrt(2.0)
    e_minus = np.array([1.0, -1j, 0.0], dtype=complex) / np.sqrt(2.0)
    return e_plus, e_minus


class ChiralNanorodDimer:
    """
    Analytical/Coupled-Dipole model of a twisted nanorod dimer (chiral meta-molecule).

    Parameters
    ----------
    length_nm : float
        Rorod length [nm] (default: 80 nm)
    radius_nm : float
        Rorod radius [nm] (default: 15 nm)
    gap_nm : float
        Separation distance along z-axis between rod centers [nm] (default: 20 nm)
    twist_angle_deg : float
        Relative rotation angle theta between top and bottom rods [deg] (default: 45 deg)
    material : str
        Plasmonic metal ('Au', 'Ag', 'Al') (default: 'Au')
    medium_n : float
        Background refractive index (default: 1.0)
    """

    def __init__(self, length_nm: float = 80.0, radius_nm: float = 15.0,
                 gap_nm: float = 20.0, twist_angle_deg: float = 45.0,
                 material: str = "Au", medium_n: float = 1.0):
        self.length_nm = length_nm
        self.radius_nm = radius_nm
        self.gap_nm    = gap_nm
        self.twist_angle_rad = np.radians(twist_angle_deg)
        self.material  = material
        self.medium_n  = medium_n

        # Rod orientations in xy-plane
        # Rod 1 (bottom, z = -gap/2): along x-axis [1, 0, 0]
        # Rod 2 (top, z = +gap/2): rotated by theta [cos(theta), sin(theta), 0]
        self.n1 = np.array([1.0, 0.0, 0.0])
        self.n2 = np.array([np.cos(self.twist_angle_rad), np.sin(self.twist_angle_rad), 0.0])

        self.r1 = np.array([0.0, 0.0, -gap_nm / 2.0])
        self.r2 = np.array([0.0, 0.0, +gap_nm / 2.0])

    def polarizability(self, lam_nm: float) -> complex:
        """
        Longitudinal polarizability of a nanorod using Kuwata et al. formula.
        Kuwata-Gonokami et al. Aust. J. Chem. 56, 1059 (2003).
        """
        eps_m = get_epsilon_BH(self.material, np.array([lam_nm]))[0]
        eps_b = self.medium_n**2

        # Aspect ratio
        AR = self.length_nm / (2.0 * self.radius_nm)
        # Depolarization factor L_z along longitudinal axis
        e2 = 1.0 - (1.0 / AR)**2
        if e2 > 0:
            e = np.sqrt(e2)
            L_z = ((1.0 - e**2) / e**2) * (0.5 * np.log((1.0 + e) / (1.0 - e)) - e)
        else:
            L_z = 1.0 / 3.0

        # Volume of spheroidal rod [nm^3]
        vol = (4.0 / 3.0) * np.pi * (self.length_nm / 2.0) * (self.radius_nm**2)

        # Electrostatic polarizability V * (eps - eps_b) / (eps_b + L_z*(eps - eps_b))
        denom = eps_b + L_z * (eps_m - eps_b)
        alpha_static = vol * (eps_m - eps_b) / denom

        # Radiation correction: alpha = alpha_static / (1 - i * (2/3) k^3 alpha_static)
        k = 2.0 * np.pi * self.medium_n / lam_nm
        alpha_ret = alpha_static / (1.0 - 1j * (2.0 / 3.0) * (k**3) * alpha_static)
        return alpha_ret

    def free_space_green_tensor(self, r: np.ndarray, r_prime: np.ndarray,
                                k: float) -> np.ndarray:
        """
        Dyadic Green tensor G_0(r, r') in free/homogeneous background medium.
        G_0 = (exp(i k R) / (4 pi R)) * [ (1 + i/(kR) - 1/(kR)^2) I
                                          + (-1 - 3i/(kR) + 3/(kR)^2) (R tensor R)/R^2 ]
        """
        R_vec = r - r_prime
        R = np.linalg.norm(R_vec)
        if R < 1e-12:
            return np.zeros((3, 3), dtype=complex)

        R_hat = R_vec / R
        kR = k * R

        term1 = 1.0 + 1j / kR - 1.0 / (kR**2)
        term2 = -1.0 - 3j / kR + 3.0 / (kR**2)

        I3 = np.eye(3)
        R_outer = np.outer(R_hat, R_hat)

        phase = np.exp(1j * kR) / (4.0 * np.pi * R)
        G0 = phase * (term1 * I3 + term2 * R_outer)
        return G0

    def green_tensor(self, r_obs: np.ndarray, lam_nm: float) -> np.ndarray:
        """
        Scattered dyadic Green tensor G_scat(r_obs, r_obs, omega) at observer position.
        Computed using Coupled Dipole Approximation (CDA) between the two rods.
        """
        k = 2.0 * np.pi * self.medium_n / lam_nm
        alpha = self.polarizability(lam_nm)

        # Interaction matrix between rod 1 and rod 2 (dimensionless CDA formulation)
        G12_rod = self.free_space_green_tensor(self.r1, self.r2, k)
        G21_rod = self.free_space_green_tensor(self.r2, self.r1, k)

        I3 = np.eye(3, dtype=complex)
        A = np.block([[(1.0 / alpha) * I3, -(k**2) * G12_rod],
                      [-(k**2) * G21_rod, (1.0 / alpha) * I3]])

        # Green tensor from emitter at r_obs to rods, and back to r_obs
        G_obs1 = self.free_space_green_tensor(r_obs, self.r1, k)
        G_obs2 = self.free_space_green_tensor(r_obs, self.r2, k)

        # Coupling for unit excitation at r_obs along x, y, z
        G_scat = np.zeros((3, 3), dtype=complex)

        for i in range(3):
            unit_dipole = np.zeros(3)
            unit_dipole[i] = 1.0

            # Incident field at rods from unit dipole at r_obs: E = k^2 G0 p
            E_inc1 = (k**2) * self.free_space_green_tensor(self.r1, r_obs, k) @ unit_dipole
            E_inc2 = (k**2) * self.free_space_green_tensor(self.r2, r_obs, k) @ unit_dipole

            E_inc = np.concatenate([E_inc1, E_inc2])
            try:
                p_sol = np.linalg.solve(A, E_inc)
            except np.linalg.LinAlgError:
                p_sol = np.zeros(6, dtype=complex)

            p1 = p_sol[0:3]
            p2 = p_sol[3:6]

            # Re-radiated field at r_obs: E_scat = k^2 G0(r_obs, r_rod) p
            E_scat = (k**2) * G_obs1 @ p1 + (k**2) * G_obs2 @ p2
            G_scat[:, i] = E_scat

        return G_scat

    def purcell_factors(self, r_obs: np.ndarray, lam_nm: float) -> Dict[str, float]:
        """
        Computes chirality-selective Purcell factors F_{P,+}, F_{P,-}, and total LDOS enhancement.
        """
        k = 2.0 * np.pi * self.medium_n / lam_nm
        G_scat = self.green_tensor(r_obs, lam_nm)

        e_plus, e_minus = circular_polarization_vectors()

        # Free space LDOS factor
        Im_G0 = k / (6.0 * np.pi)

        # Im[e^* . G_scat . e]
        Im_G_plus  = np.imag(np.conj(e_plus)  @ G_scat @ e_plus)
        Im_G_minus = np.imag(np.conj(e_minus) @ G_scat @ e_minus)
        Im_G_z     = np.imag(G_scat[2, 2])

        F_P_plus  = max(0.0, 1.0 + Im_G_plus  / Im_G0)
        F_P_minus = max(0.0, 1.0 + Im_G_minus / Im_G0)
        F_P_z     = max(0.0, 1.0 + Im_G_z     / Im_G0)

        F_P_avg   = (F_P_plus + F_P_minus + F_P_z) / 3.0

        # Dissymmetry in Purcell factor
        if (F_P_plus + F_P_minus) > 0:
            g_purcell = 2.0 * (F_P_plus - F_P_minus) / (F_P_plus + F_P_minus)
        else:
            g_purcell = 0.0

        return {
            "F_P_plus": float(F_P_plus),
            "F_P_minus": float(F_P_minus),
            "F_P_z": float(F_P_z),
            "F_P_avg": float(F_P_avg),
            "g_purcell": float(g_purcell),
            "CD_purcell": float(F_P_plus - F_P_minus)
        }

    def circular_dichroism_spectrum(self, lam_array: np.ndarray,
                                    r_obs: np.ndarray) -> Dict[str, np.ndarray]:
        """
        Calculates CD spectrum (F_P,+ - F_P,-) and g_purcell over wavelength range.
        """
        N = len(lam_array)
        F_plus  = np.zeros(N)
        F_minus = np.zeros(N)
        F_avg   = np.zeros(N)
        g_cd    = np.zeros(N)

        for i, lam in enumerate(lam_array):
            res = self.purcell_factors(r_obs, lam)
            F_plus[i]  = res["F_P_plus"]
            F_minus[i] = res["F_P_minus"]
            F_avg[i]   = res["F_P_avg"]
            g_cd[i]    = res["g_purcell"]

        return {
            "lam_nm": lam_array,
            "F_P_plus": F_plus,
            "F_P_minus": F_minus,
            "CD": F_plus - F_minus,
            "g_CD": g_cd,
            "F_P_avg": F_avg
        }


    def green_tensor_cross(self, r1: np.ndarray, r2: np.ndarray,
                           lam_nm: float) -> np.ndarray:
        """
        Cross-position scattered dyadic Green tensor G_scat(r1, r2, omega).

        This gives the field at r1 due to a unit dipole at r2, mediated by
        the nanorod dimer.  The total Green tensor including free-space is:
            G_total(r1, r2) = G0(r1, r2) + G_scat(r1, r2)

        Used for computing the off-diagonal dissipative coupling gamma_12:
            gamma_12 = (2 mu0 omega^2 d^2 / hbar) * Im[e_-^*.G_total(r1,r2).e_+]

        Parameters
        ----------
        r1, r2 : np.ndarray shape (3,)
            Emitter positions in nm.
        lam_nm : float
            Vacuum wavelength in nm.

        Returns
        -------
        G_cross : np.ndarray shape (3,3), complex
            Total (free-space + scattered) cross Green tensor at (r1, r2).
        """
        k = 2.0 * np.pi * self.medium_n / lam_nm
        alpha = self.polarizability(lam_nm)

        # Interaction matrix between the two nanorods
        G12_rod = self.free_space_green_tensor(self.r1, self.r2, k)
        G21_rod = self.free_space_green_tensor(self.r2, self.r1, k)

        I3 = np.eye(3, dtype=complex)
        A = np.block([[(1.0 / alpha) * I3, -(k**2) * G12_rod],
                      [-(k**2) * G21_rod, (1.0 / alpha) * I3]])

        # Free-space cross-term (direct contribution)
        G0_cross = self.free_space_green_tensor(r1, r2, k)

        # Scattered cross-term: build column-by-column from unit dipoles at r2
        G_scat_cross = np.zeros((3, 3), dtype=complex)

        # Green tensor from observation point r1 to each rod
        G_obs1_from_r1 = self.free_space_green_tensor(r1, self.r1, k)
        G_obs2_from_r1 = self.free_space_green_tensor(r1, self.r2, k)

        for i in range(3):
            unit_dipole = np.zeros(3)
            unit_dipole[i] = 1.0

            # Incident field at rods from unit dipole at r2
            E_inc1 = (k**2) * self.free_space_green_tensor(self.r1, r2, k) @ unit_dipole
            E_inc2 = (k**2) * self.free_space_green_tensor(self.r2, r2, k) @ unit_dipole

            E_inc = np.concatenate([E_inc1, E_inc2])
            try:
                p_sol = np.linalg.solve(A, E_inc)
            except np.linalg.LinAlgError:
                p_sol = np.zeros(6, dtype=complex)

            p1 = p_sol[0:3]
            p2 = p_sol[3:6]

            # Re-radiated field at r1 from induced dipoles
            E_scat = (k**2) * (G_obs1_from_r1 @ p1 + G_obs2_from_r1 @ p2)
            G_scat_cross[:, i] = E_scat

        return G0_cross + G_scat_cross

    def extract_gamma12(self, r1: np.ndarray, r2: np.ndarray,
                        lam_nm: float, dipole_moment_Cm: float = 1e-29
                        ) -> complex:
        """
        Off-diagonal dissipative cross-decay coefficient gamma_12.

        From macroscopic QED (Dung et al. 2002):
            gamma_12 = (2 mu0 omega0^2 d^2 / hbar) * Im[G_12]

        where G_12 = e_-^* . G_total(r1, r2, omega0) . e_+
        (circular polarization projection, LCP/RCP basis).

        This quantity satisfies |gamma_12| = |gamma_21| and
        arg(gamma_12) = -arg(gamma_21) for reciprocal media (Lemma A+B).

        Parameters
        ----------
        r1, r2 : np.ndarray
            Emitter positions [nm].
        lam_nm : float
            Vacuum wavelength [nm].
        dipole_moment_Cm : float
            Transition dipole moment magnitude [C·m]. Default 1e-29 C·m ~ 3 Debye.

        Returns
        -------
        gamma12 : complex
            Cross-decay coupling [rad/s]. Im part is dissipative; Re part is
            the cross-dispersive (coherent exchange) contribution.
        """
        from shared_constants import C, MU0, HBAR
        omega0 = 2.0 * np.pi * C / (lam_nm * 1e-9)
        # Dyadic Green tensors in SI units m^-1 (1 nm^-1 = 1e9 m^-1)
        G12_m = self.green_tensor_cross(r1, r2, lam_nm) * 1e9
        G21_m = self.green_tensor_cross(r2, r1, lam_nm) * 1e9

        # Macroscopic QED Hermitian imaginary kernel
        ImG12_m = (G12_m - np.conj(G21_m).T) / (2j)

        e_plus, e_minus = circular_polarization_vectors()
        G12_scalar = np.conj(e_minus) @ ImG12_m @ e_plus

        prefactor = (2.0 * MU0 * omega0**2 * dipole_moment_Cm**2) / HBAR
        gamma12 = prefactor * G12_scalar
        return complex(gamma12)

    def extract_J12(self, r1: np.ndarray, r2: np.ndarray,
                    lam_nm: float, dipole_moment_Cm: float = 1e-29) -> float:
        """
        Coherent exchange coupling J_12.

        From macroscopic QED (Dung et al. 2002):
            J_12 = -(mu0 omega0^2 d^2 / hbar) * Re[e_-^*. ReG_sym . e_+]

        where ReG_sym = (G12 + G21†) / 2 is the Hermitian real part.

        Note: J_12 = J_21^* from Lorentz reciprocity of the Green tensor.

        Returns
        -------
        J12 : float
            Coherent exchange rate [rad/s].
        """
        from shared_constants import C, MU0, HBAR
        omega0 = 2.0 * np.pi * C / (lam_nm * 1e-9)
        G12_m = self.green_tensor_cross(r1, r2, lam_nm) * 1e9
        G21_m = self.green_tensor_cross(r2, r1, lam_nm) * 1e9

        ReG12_m = (G12_m + np.conj(G21_m).T) / 2.0

        e_plus, e_minus = circular_polarization_vectors()
        G12_scalar = np.conj(e_minus) @ ReG12_m @ e_plus

        prefactor = (MU0 * omega0**2 * dipole_moment_Cm**2) / HBAR
        J12 = -prefactor * np.real(G12_scalar)
        return float(J12)

    def gauge_invariant_phase(self, r1: np.ndarray, r2: np.ndarray,
                              lam_nm: float,
                              dipole_moment_Cm: float = 1e-29) -> dict:
        """
        Compute the gauge-invariant physical phase observable.

        The raw phase phi_chiral = arg(gamma_12) is NOT gauge invariant:
        under local emitter phase rotations |e_i> -> exp(i chi_i)|e_i>,
        gamma_12 -> exp(i(chi_1 - chi_2)) * gamma_12.

        The gauge-invariant relative phase between dissipative and coherent
        cross-couplings is:
            eta = arg(gamma_12) - arg(J_12)   [if J_12 != 0]

        This quantity is invariant under chi_1 - chi_2 rotations.

        Returns
        -------
        dict with keys:
            phi_chiral : float   — raw arg(gamma_12) in degrees (basis-dependent)
            J12        : float   — coherent coupling [rad/s]
            gamma12_mag: float   — |gamma_12| [rad/s]
            eta        : float   — gauge-invariant relative phase [deg]
            gamma12    : complex — full complex gamma_12
        """
        gamma12 = self.extract_gamma12(r1, r2, lam_nm, dipole_moment_Cm)
        J12 = self.extract_J12(r1, r2, lam_nm, dipole_moment_Cm)

        phi_chiral = float(np.degrees(np.angle(gamma12)))
        gamma12_mag = float(np.abs(gamma12))

        # Gauge-invariant relative phase: arg(gamma_12) - arg(J_12)
        # arg(J_12) = 0 or pi since J_12 is real by construction in this basis
        # => eta = phi_chiral when J_12 > 0, eta = phi_chiral - 180 when J_12 < 0
        if abs(J12) > 1e-30:
            eta = phi_chiral - float(np.degrees(np.angle(complex(J12, 0.0))))
        else:
            eta = phi_chiral  # J12 ≈ 0: only dissipative coupling active

        return {
            "phi_chiral":   phi_chiral,
            "J12":          J12,
            "gamma12_mag":  gamma12_mag,
            "eta":          eta,
            "gamma12":      gamma12,
        }


# =============================================================================
# Self-Test & Verification
# =============================================================================
if __name__ == "__main__":
    print("=" * 65)
    print("  Project 1: Chiral Green Tensor & Purcell Self-Test")
    print("=" * 65)

    # 1. Instantiate chiral twisted nanorod dimer
    # R=15nm, L=80nm, gap=20nm, twist=45 deg
    dimer = ChiralNanorodDimer(length_nm=80, radius_nm=15, gap_nm=20,
                               twist_angle_deg=45, material="Au", medium_n=1.0)

    r_emitter = np.array([0.0, 0.0, 0.0])  # centered between rods in the gap
    lam_test = 550.0  # nm

    res = dimer.purcell_factors(r_emitter, lam_test)
    print(f"\nChiral Purcell Factor at {lam_test} nm (r = [0,0,0]):")
    print(f"  F_P(+) [LCP] : {res['F_P_plus']:.4f}")
    print(f"  F_P(-) [RCP] : {res['F_P_minus']:.4f}")
    print(f"  CD (F+ - F-) : {res['CD_purcell']:.4f}")
    print(f"  g_purcell    : {res['g_purcell']:.4f}")
    print(f"  F_P (avg)    : {res['F_P_avg']:.4f}")

    # 2. Check achiral symmetry limit (twist angle = 0 deg)
    dimer_achiral = ChiralNanorodDimer(length_nm=80, radius_nm=15, gap_nm=20,
                                       twist_angle_deg=0, material="Au", medium_n=1.0)
    res_achiral = dimer_achiral.purcell_factors(r_emitter, lam_test)
    print("\nAchiral Limit Test (twist angle = 0 deg):")
    print(f"  F_P(+) [LCP] : {res_achiral['F_P_plus']:.4f}")
    print(f"  F_P(-) [RCP] : {res_achiral['F_P_minus']:.4f}")
    print(f"  CD (F+ - F-) : {res_achiral['CD_purcell']:.4e}")
    assert abs(res_achiral['CD_purcell']) < 1e-6, "FAIL: Achiral structure must have zero CD!"
    print("  PASS: Achiral symmetry verified (CD = 0).")

    # 3. CD Spectrum calculation
    lams = np.linspace(450, 750, 100)
    spec = dimer.circular_dichroism_spectrum(lams, r_emitter)
    max_cd_idx = np.argmax(np.abs(spec["CD"]))
    print(f"\nCD Spectrum Peak:")
    print(f"  Wavelength : {lams[max_cd_idx]:.1f} nm")
    print(f"  Max |CD|   : {spec['CD'][max_cd_idx]:.4f}")
    print(f"  g_CD @ peak: {spec['g_CD'][max_cd_idx]:.4f}")
    print("\n  PASS: chiral_green_tensor.py operational.")

"""
shared_constants.py
Physical constants for Project 1 - Chiral Plasmonic Entanglement.
"""
import numpy as np

# Speed of light [m/s]
C = 2.99792458e8

# Permeability of free space [H/m]
MU0 = 4.0 * np.pi * 1e-7

# Permittivity of free space [F/m]
EPS0 = 1.0 / (MU0 * C**2)

# Reduced Planck constant [J.s]
HBAR = 1.054571817e-34

# Planck constant [J.s]
H_PLANCK = 2.0 * np.pi * HBAR

# Boltzmann constant [J/K]
KB = 1.380649e-23

# Elementary charge [C]
E_CHARGE = 1.602176634e-19

# Vacuum impedance [Ohm]
Z0 = MU0 * C

# Typical QD transition dipole moment ~3 Debye = 3 * 3.336e-30 C.m
D0_DEFAULT = 3.0 * 3.336e-30   # [C.m]

# Unit conversions
NM_TO_M = 1e-9    # nanometres to metres
M_TO_NM = 1e9     # metres to nanometres
EV_TO_J = 1.602176634e-19   # electron-volts to joules
J_TO_EV = 1.0 / EV_TO_J    # joules to electron-volts
"""
physics_validation.py
=====================
PHASE 0: Physics Validation & Parameter Provenance — Run before any manuscript generation.

Executes 15 mandatory validation tests before writing the PRA manuscript.

Architecture:
  G(r_i, r_j, omega0)
    -> Gamma (2x2), J (2x2)         [Tests 1-5]
    -> Canonical Lindblad L_mu      [Test 4]
    -> gauge invariance of eta       [Tests 6-7]
    -> [J, Gamma] commutator         [Test 8]
    -> H_NH eigenspectrum            [Test 9]
    -> 16x16 Liouvillian stability   [Test 10]
    -> G -> Gamma,J -> L -> rho(t)   [Test 11]
    -> Concurrence verification      [Test 12]
    -> Factorial control design      [Test 13]
    -> FDTD/BEM convergence          [Test 14]
    -> Dephasing sensitivity         [Test 15]

All printed values replace legacy manuscript numbers.
DO NOT use the old manuscript values. Let calculations determine the claims.

References:
  - Dung, H. T. et al. PRA 66, 063810 (2002). DOI: 10.1103/PhysRevA.66.063810
  - Gorini, V. et al. JMP 17, 821 (1976). DOI: 10.1063/1.522979
  - Wootters, W. K. PRL 80, 2245 (1998). DOI: 10.1103/PhysRevLett.80.2245
"""

import sys, os
import numpy as np
import scipy.linalg as la

# Path setup
PROJ_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
QUTIP_DIR = os.path.join(PROJ_ROOT, "QuTiP")
for p in [os.path.dirname(__file__), QUTIP_DIR]:
    if p not in sys.path:
        sys.path.insert(0, p)

from chiral_green_tensor import ChiralNanorodDimer, circular_polarization_vectors
from chiral_master_equation import ChiralTwoQubitSystem, concurrence, bell_state
from shared_constants import C as C_LIGHT, MU0, HBAR, NM_TO_M

# ─────────────────────────────────────────────────────────────────────────────
# Global geometry: Bayesian-optimum, TO BE VALIDATED, not assumed
# ─────────────────────────────────────────────────────────────────────────────
GEOM = dict(length_nm=96.6, radius_nm=12.5, gap_nm=5.7,
            twist_angle_deg=54.1, material="Au", medium_n=1.46)
LAM0_NM   = 620.0   # vacuum wavelength — must be consistent throughout
D0_Cm     = 3.0 * 3.336e-30   # 3 Debye transition dipole moment
T_PS_OBS  = 50.0    # observation window [ps]
N_TIMES   = 400     # time steps for dynamics

PASS = "  [PASS]"
FAIL = "  [FAIL]"
WARN = "  [WARN]"

results = {}   # dictionary: test_name -> {"pass": bool, "data": dict}


def header(n, title):
    print(f"\n{'='*72}")
    print(f"  Test {n:02d}: {title}")
    print(f"{'='*72}")


# ─────────────────────────────────────────────────────────────────────────────
# UTILITY: Macroscopic-QED Green Tensor Hermitian Kernel
# ─────────────────────────────────────────────────────────────────────────────

def ImG_mQED(G_ij, G_ji):
    """
    Hermitian imaginary part of the dyadic Green tensor in macroscopic QED.

    For passive environments, the electromagnetic correlation kernel is:
        ImG(r, r', omega) = (G(r,r',omega) - G†(r',r,omega)) / (2i)

    This is NOT the same as taking the element-wise imaginary part of G,
    which would only be valid if G were a real matrix times i.

    Parameters
    ----------
    G_ij : (3,3) complex ndarray — G(r_i, r_j, omega)
    G_ji : (3,3) complex ndarray — G(r_j, r_i, omega)

    Returns
    -------
    ImG : (3,3) complex ndarray — Hermitian imaginary part
    """
    return (G_ij - np.conj(G_ji).T) / (2j)


def compute_gamma_ij(G_ij, G_ji, d_i, d_j, omega0):
    """
    Compute one element gamma_ij of the Kossakowski matrix.

    gamma_ij = (2 mu0 omega0^2 / hbar) * d_i^* . ImG(r_i, r_j, omega0) . d_j

    Uses the Hermitian-kernel ImG (not element-wise imaginary part).
    """
    ImG = ImG_mQED(G_ij, G_ji)
    prefactor = 2.0 * MU0 * omega0**2 / HBAR
    return complex(prefactor * (np.conj(d_i) @ ImG @ d_j))


def compute_J_ij(G_ij, G_ji, d_i, d_j, omega0):
    """
    Compute one element J_ij of the coherent exchange coupling matrix.

    J_ij = -(mu0 omega0^2 / hbar) * d_i^* . ReG_sym(r_i, r_j, omega0) . d_j

    where ReG_sym = (G_ij + G_ji†) / 2 is the real (Hermitian) part.
    """
    ReG = (G_ij + np.conj(G_ji).T) / 2.0
    prefactor = -MU0 * omega0**2 / HBAR
    return complex(prefactor * (np.conj(d_i) @ ReG @ d_j))


# ─────────────────────────────────────────────────────────────────────────────
# Build full 2x2 Gamma and J matrices from Green tensors
# ─────────────────────────────────────────────────────────────────────────────

def extract_full_matrices(dimer, r1_nm, r2_nm, lam_nm, d0_Cm):
    """
    Extract full 2x2 Kossakowski (Gamma) and coherent exchange (J) matrices.

    Uses the macroscopic-QED Hermitian-kernel ImG convention throughout.
    All four matrix elements are computed independently in SI units [rad/s].

    Returns a dict with all raw values and derived quantities.
    """
    e_plus, e_minus = circular_polarization_vectors()
    d1 = d0_Cm * e_minus   # emitter 1: RCP (e_-)
    d2 = d0_Cm * e_plus    # emitter 2: LCP (e_+)

    omega0 = 2.0 * np.pi * C_LIGHT / (lam_nm * NM_TO_M)
    k_nm   = 2.0 * np.pi * dimer.medium_n / lam_nm

    # Free-space imaginary tensor [nm^-1]
    ImG0_nm = (k_nm / (6.0 * np.pi)) * np.eye(3, dtype=complex)

    # Green tensors in SI units m^-1 (1 nm^-1 = 1e9 m^-1)
    # Self Green tensors include free-space term ImG0 + G_scat
    G11 = (ImG0_nm + dimer.green_tensor(r1_nm, lam_nm)) * 1e9
    G22 = (ImG0_nm + dimer.green_tensor(r2_nm, lam_nm)) * 1e9
    G12 = dimer.green_tensor_cross(r1_nm, r2_nm, lam_nm) * 1e9
    G21 = dimer.green_tensor_cross(r2_nm, r1_nm, lam_nm) * 1e9

    # ── Gamma matrix elements ────────────────────────────────────────────────
    gamma11 = compute_gamma_ij(G11, G11, d1, d1, omega0)
    gamma22 = compute_gamma_ij(G22, G22, d2, d2, omega0)
    gamma12 = compute_gamma_ij(G12, G21, d1, d2, omega0)
    gamma21 = compute_gamma_ij(G21, G12, d2, d1, omega0)

    Gamma = np.array([[gamma11, gamma12],
                      [gamma21, gamma22]], dtype=complex)

    # ── J matrix elements ────────────────────────────────────────────────────
    J11 = compute_J_ij(G11, G11, d1, d1, omega0)
    J22 = compute_J_ij(G22, G22, d2, d2, omega0)
    J12 = compute_J_ij(G12, G21, d1, d2, omega0)
    J21 = compute_J_ij(G21, G12, d2, d1, omega0)

    J_mat = np.array([[J11, J12],
                      [J21, J22]], dtype=complex)

    return dict(
        omega0=omega0, d1=d1, d2=d2,
        G11=G11, G22=G22, G12=G12, G21=G21,
        Gamma=Gamma, J_mat=J_mat,
        gamma11=gamma11, gamma22=gamma22, gamma12=gamma12, gamma21=gamma21,
        J11=J11, J22=J22, J12=J12, J21=J21,
    )


# ─────────────────────────────────────────────────────────────────────────────
# TEST 1: Correct Green-tensor ImG convention
# ─────────────────────────────────────────────────────────────────────────────

def test_01_ImG_convention(md):
    header(1, "Correct Green-tensor ImG convention (macroscopic QED Hermitian kernel)")

    G12 = md["G12"]
    G21 = md["G21"]

    # Hermitian-kernel ImG must be Hermitian: ImG = ImG†
    ImG = ImG_mQED(G12, G21)
    herm_err = np.max(np.abs(ImG - np.conj(ImG).T))
    herm_ok  = herm_err < 1e-10 * max(np.max(np.abs(ImG)), 1e-30)

    # Compare with element-wise Im: should differ for general complex G
    ImG_elem = np.imag(G12)
    diff = np.max(np.abs(ImG - ImG_elem))

    print(f"  Hermitian-kernel ImG = (G12 - G21†)/(2i)")
    print(f"  ||ImG - ImG†||_max   = {herm_err:.2e}  {'✓ Hermitian' if herm_ok else '✗ NOT Hermitian'}")
    print(f"  ||ImG_Herm - ImG_elem||_max = {diff:.2e}  (should be nonzero for complex G)")
    print(f"  G12[0,0] = {G12[0,0]:.4e}")
    print(f"  G21[0,0] = {G21[0,0]:.4e}")

    passed = herm_ok
    print(PASS if passed else FAIL)
    return passed, {"herm_err": herm_err, "diff_from_elem": diff}


# ─────────────────────────────────────────────────────────────────────────────
# TEST 2: Gamma = Gamma† (Kossakowski Hermiticity)
# ─────────────────────────────────────────────────────────────────────────────

def test_02_gamma_hermitian(md):
    header(2, "Gamma = Gamma† (Kossakowski matrix Hermiticity)")

    Gamma = md["Gamma"]
    diff = Gamma - np.conj(Gamma).T
    err  = np.max(np.abs(diff))
    ok   = err < 1e-6 * max(np.max(np.abs(Gamma)), 1e-30)

    # Also verify gamma_21 = conj(gamma_12) explicitly
    conj_err = abs(md["gamma21"] - np.conj(md["gamma12"]))
    conj_ok  = conj_err < 1e-6 * max(abs(md["gamma12"]), 1e-30)

    print(f"  Gamma =")
    print(f"    [{md['gamma11'].real:.4e}  {md['gamma12'].real:.4e}{md['gamma12'].imag:+.4e}j]")
    print(f"    [{md['gamma21'].real:.4e}{md['gamma21'].imag:+.4e}j  {md['gamma22'].real:.4e}]")
    print(f"  ||Gamma - Gamma†||_max = {err:.2e}   {'✓' if ok else '✗'}")
    print(f"  |gamma_21 - conj(gamma_12)| = {conj_err:.2e}   {'✓' if conj_ok else '✗'}")
    print(f"  arg(gamma_12) = {np.degrees(np.angle(md['gamma12'])):.4f} deg")
    print(f"  arg(gamma_21) = {np.degrees(np.angle(md['gamma21'])):.4f} deg")

    passed = ok and conj_ok
    print(PASS if passed else FAIL)
    return passed, {"herm_err": err, "conj_err": conj_err}


# ─────────────────────────────────────────────────────────────────────────────
# TEST 3: Gamma ⪰ 0 (positive semidefinite)
# ─────────────────────────────────────────────────────────────────────────────

def test_03_gamma_positive(md):
    header(3, "Gamma ⪰ 0 (positive semidefinite) & Cauchy-Schwarz bound on |gamma_12|")

    Gamma = md["Gamma"]
    evals = np.linalg.eigvalsh(Gamma)
    lam_min = float(np.min(evals))
    lam_max = float(np.max(evals))

    # PSD with numerical tolerance: negative evals only from machine precision
    tol = 1e-8 * lam_max
    ok  = lam_min >= -tol

    # Cauchy-Schwarz bound: |gamma_12|^2 <= gamma_11 * gamma_22
    cs_lhs = abs(md["gamma12"])**2
    cs_rhs = md["gamma11"].real * md["gamma22"].real
    beta12 = np.sqrt(cs_lhs / cs_rhs) if cs_rhs > 0 else float("nan")
    cs_ok  = cs_lhs <= cs_rhs * (1 + 1e-6)

    det_Gamma = float(np.linalg.det(Gamma).real)

    print(f"  Eigenvalues of Gamma: {evals}")
    print(f"  lambda_min = {lam_min:.4e}  (numerical tol = {tol:.2e})")
    print(f"  det(Gamma) = {det_Gamma:.4e}  (must be >= 0)")
    print(f"  Cauchy-Schwarz: |gamma12|^2 = {cs_lhs:.4e} vs gamma11*gamma22 = {cs_rhs:.4e}")
    print(f"  beta_12 = |gamma12| / sqrt(gamma11*gamma22) = {beta12:.6f}  (must be <= 1)")
    print(f"  Gamma PSD:  {'✓' if ok else '✗ VIOLATION — unphysical Gamma!'}")
    print(f"  Cauchy-Schwarz: {'✓' if cs_ok else '✗ VIOLATION'}")

    passed = ok and cs_ok
    print(PASS if passed else FAIL)
    return passed, {"lambda_min": lam_min, "det_Gamma": det_Gamma,
                    "beta12": float(beta12), "eigenvalues": evals.tolist()}


# ─────────────────────────────────────────────────────────────────────────────
# TEST 4: Canonical GKSL Lindblad reconstruction
# ─────────────────────────────────────────────────────────────────────────────

def test_04_lindblad_reconstruction(md):
    header(4, "Canonical GKSL Lindblad reconstruction: Gamma = U Lambda U†")

    Gamma = md["Gamma"]

    # Diagonalize: Gamma = U diag(lambda_mu) U†
    evals, U = np.linalg.eigh(Gamma)
    evals = np.maximum(evals, 0.0)   # clip tiny negatives from numerics

    # Canonical jump operators: L_mu = sqrt(lambda_mu) * sum_i U_im sigma_i^-
    # In the 2-emitter, single-excitation basis:
    #   sigma_1^- acts on index 0 (|eg> -> |gg>)
    #   sigma_2^- acts on index 1 (|ge> -> |gg>)

    # Reconstruct Gamma from canonical decomposition: Gamma_recon_ij = sum_mu lambda_mu U_im U_jm*
    Gamma_recon = U @ np.diag(evals) @ np.conj(U).T
    recon_err   = np.max(np.abs(Gamma - Gamma_recon))
    recon_ok    = recon_err < 1e-10

    print(f"  Gamma eigenvalues (lambda_mu): {evals}")
    print(f"  Unitary U =")
    for row in U:
        print(f"    {row}")
    print(f"  ||Gamma - U*diag(lambda)*U†||_max = {recon_err:.2e}   {'✓' if recon_ok else '✗'}")
    print(f"  Canonical jump operators L_mu = sqrt(lambda_mu) * (U_1mu sigma_1^- + U_2mu sigma_2^-)")
    for mu in range(2):
        coeff1 = np.sqrt(evals[mu]) * U[0, mu]
        coeff2 = np.sqrt(evals[mu]) * U[1, mu]
        print(f"    L_{mu+1}: sqrt({evals[mu]:.4e}) * ({coeff1:.4e} sigma_1^- + {coeff2:.4e} sigma_2^-)")

    passed = recon_ok
    print(PASS if passed else FAIL)
    return passed, {"evals": evals.tolist(), "U": U.tolist(), "recon_err": recon_err}


# ─────────────────────────────────────────────────────────────────────────────
# TEST 5: J = J† (coherent exchange Hermiticity)
# ─────────────────────────────────────────────────────────────────────────────

def test_05_J_hermitian(md):
    header(5, "J = J† (coherent exchange matrix Hermiticity)")

    J = md["J_mat"]
    err = np.max(np.abs(J - np.conj(J).T))
    ok  = err < 1e-6 * max(np.max(np.abs(J)), 1e-40)

    print(f"  J_12 = {md['J12'].real:.4e}{md['J12'].imag:+.4e}j  [rad/s]")
    print(f"  J_21 = {md['J21'].real:.4e}{md['J21'].imag:+.4e}j  [rad/s]")
    print(f"  |J_12 - conj(J_21)| = {abs(md['J12'] - np.conj(md['J21'])):.2e}   {'✓' if ok else '✗'}")
    print(f"  J is Hermitian: {'✓' if ok else '✗'}")

    passed = ok
    print(PASS if passed else FAIL)
    return passed, {"J_herm_err": err}


# ─────────────────────────────────────────────────────────────────────────────
# TEST 6: Gauge transformation of gamma_12 and J_12
# ─────────────────────────────────────────────────────────────────────────────

def test_06_gauge_transformation(md):
    header(6, "Gauge transformation: gamma_12 and J_12 transform as e^{i(chi1-chi2)}")

    gamma12 = md["gamma12"]
    J12     = complex(md["J12"])

    chi1 = np.radians(37.0)   # arbitrary test phase
    chi2 = np.radians(13.0)

    # Apply gauge transformation manually
    gauge_factor = np.exp(1j * (chi1 - chi2))
    gamma12_gauged = gauge_factor * gamma12
    J12_gauged     = gauge_factor * J12

    # Check magnitudes are gauge-invariant
    mag_gamma_ok = abs(abs(gamma12_gauged) - abs(gamma12)) < 1e-12
    mag_J_ok     = abs(abs(J12_gauged)     - abs(J12))     < 1e-12

    # Check eta = arg(gamma_12 / J_12) is gauge invariant
    def eta(g12, j12):
        if abs(j12) < 1e-30:
            return float(np.degrees(np.angle(g12)))
        return float(np.degrees(np.angle(g12 / j12)))

    eta_orig   = eta(gamma12, J12)
    eta_gauged = eta(gamma12_gauged, J12_gauged)
    eta_ok     = abs((eta_orig - eta_gauged + 180.0) % 360.0 - 180.0) < 1e-8

    print(f"  gamma_12 (original)       = {gamma12:.4e}")
    print(f"  gamma_12 (gauged, chi=37-13 deg) = {gamma12_gauged:.4e}")
    print(f"  |gamma_12| gauge-invariant: {'✓' if mag_gamma_ok else '✗'}")
    print(f"  |J_12| gauge-invariant:     {'✓' if mag_J_ok else '✗'}")
    print(f"  eta (original)    = {eta_orig:.6f} deg")
    print(f"  eta (after gauge) = {eta_gauged:.6f} deg")
    print(f"  eta gauge-invariant: {'✓' if eta_ok else '✗'}")

    passed = mag_gamma_ok and mag_J_ok and eta_ok
    print(PASS if passed else FAIL)
    return passed, {"eta_original": eta_orig, "eta_gauged": eta_gauged}


# ─────────────────────────────────────────────────────────────────────────────
# TEST 7: eta = arg(gamma_12 / J_12) — report actual computed value
# ─────────────────────────────────────────────────────────────────────────────

def test_07_eta_value(md):
    header(7, "Report actual eta = arg(gamma_12 / J_12) — gauge-invariant relative phase")

    gamma12 = md["gamma12"]
    J12     = complex(md["J12"])

    phi_gamma12 = float(np.degrees(np.angle(gamma12)))
    phi_J12     = float(np.degrees(np.angle(J12)))

    if abs(J12) > 1e-30:
        eta = phi_gamma12 - phi_J12
    else:
        eta = phi_gamma12
        print(WARN + "  J12 ~ 0: eta = phi_gamma12 (J12 coupling negligible)")

    print(f"  arg(gamma_12) = {phi_gamma12:.4f} deg  (basis-dependent raw phase)")
    print(f"  arg(J_12)     = {phi_J12:.4f} deg  (basis-dependent raw phase)")
    print(f"  eta = arg(gamma_12/J_12) = {eta:.4f} deg  (gauge-invariant relative phase)")
    print(f"  |gamma_12| = {abs(gamma12):.4e} rad/s")
    print(f"  |J_12|     = {abs(J12):.4e} rad/s")
    print(f"  beta_12 = |gamma_12| / gamma_11 = {abs(gamma12) / md['gamma11'].real:.6f}")

    passed = True   # no assertion, just report
    print(PASS + "  (reporting — no assertion on eta value)")
    return passed, {"eta": eta, "phi_gamma12": phi_gamma12, "phi_J12": phi_J12,
                    "beta12": abs(gamma12)/md["gamma11"].real if md["gamma11"].real > 0 else float("nan")}


# ─────────────────────────────────────────────────────────────────────────────
# TEST 8: [J, Gamma] commutator — report actual value
# ─────────────────────────────────────────────────────────────────────────────

def test_08_commutator(md):
    header(8, "[J, Gamma] in single-excitation basis — report eta_[J,Gamma]")

    Gamma = md["Gamma"]
    J     = md["J_mat"]

    comm = J @ Gamma - Gamma @ J

    norm_J     = np.linalg.norm(J, "fro")
    norm_Gamma = np.linalg.norm(Gamma, "fro")
    norm_comm  = np.linalg.norm(comm, "fro")

    if norm_J * norm_Gamma > 0:
        eta_comm = float(norm_comm / (norm_J * norm_Gamma))
    else:
        eta_comm = float("nan")

    print(f"  Matrices in single-excitation basis {{|eg>, |ge>}}:")
    print(f"  J =")
    for row in J:
        print(f"    {row}")
    print(f"  Gamma =")
    for row in Gamma:
        print(f"    {row}")
    print(f"  [J, Gamma] =")
    for row in comm:
        print(f"    {row}")
    print(f"  ||[J, Gamma]||_F = {norm_comm:.4e}")
    print(f"  ||J||_F          = {norm_J:.4e}")
    print(f"  ||Gamma||_F      = {norm_Gamma:.4e}")
    print(f"  eta_[J,Gamma]    = {eta_comm:.6f}  (0 = compatible, 1 = fully incompatible)")
    print(f"  [J, Gamma] = 0?  {'Yes (compatible modes)' if eta_comm < 0.01 else 'No (coherent-dissipative hybridization)'}")

    print(PASS + "  (reporting — no assertion on eta_[J,Gamma] value)")
    return True, {"eta_J_Gamma": eta_comm, "norm_comm": norm_comm}


# ─────────────────────────────────────────────────────────────────────────────
# TEST 9: H_NH eigenvalues in full 4x4 Hilbert space & 2x2 single-excitation
# ─────────────────────────────────────────────────────────────────────────────

def test_09_HNH_eigenspectrum(md):
    header(9, "H_NH eigenspectrum: 2x2 single-excitation sector")

    gamma11 = md["gamma11"].real
    gamma22 = md["gamma22"].real
    gamma12 = md["gamma12"]
    J12     = complex(md["J12"])

    # System Hamiltonian in rotating frame (omega_e = 0, detuning delta = 0)
    # H_S = hbar * J12 * (sigma_1^+ sigma_2^- + sigma_1^- sigma_2^+)
    # In single-excitation basis {|eg>, |ge>}:
    H_S_1exc = HBAR * np.array([[0.0, J12],
                                 [np.conj(J12), 0.0]], dtype=complex)

    # Non-Hermitian contribution: - i hbar/2 * Gamma
    H_NH_1exc = H_S_1exc - 0.5j * HBAR * np.array(
        [[gamma11, gamma12],
         [np.conj(gamma12), gamma22]], dtype=complex)

    evals_NH = np.linalg.eigvals(H_NH_1exc) / HBAR   # in rad/s

    print(f"  H_NH (single-excitation, 2x2) in rotating frame:")
    print(f"  H_NH/hbar =")
    for row in H_NH_1exc / HBAR:
        print(f"    {row}")
    print(f"  Eigenvalues omega_tilde_n (rad/s):")
    for n, ev in enumerate(evals_NH):
        print(f"    n={n}: {ev.real:.4e} + i*{ev.imag:.4e}")
        print(f"           Re: decay rate {-2*ev.imag:.4e} rad/s, "
              f"Im: oscillation {ev.real:.4e} rad/s")
    print(f"  All Im(omega_tilde_n) <= 0: "
          f"{'✓ Physically valid (decaying)' if all(v.imag <= 1e-6 * abs(v.imag) + np.max(np.abs(evals_NH.imag)) for v in evals_NH) else '✗ UNPHYSICAL'}")

    passed = all(v.imag <= 0.0 + 1e-8 * np.max(np.abs(evals_NH)) for v in evals_NH)
    print(PASS if passed else FAIL)
    return passed, {"HNH_eigenvalues": evals_NH.tolist()}


# ─────────────────────────────────────────────────────────────────────────────
# TEST 10: Full 16x16 Liouvillian stability
# ─────────────────────────────────────────────────────────────────────────────

def test_10_liouvillian_stability(md, gamma_deph=0.005e12):
    header(10, "16x16 Liouvillian superoperator stability: all Re(lambda_n) <= 0")

    gamma11  = md["gamma11"].real
    gamma22  = md["gamma22"].real
    gamma12  = md["gamma12"]
    phi_c    = float(np.degrees(np.angle(md["gamma12"])))
    J12_val  = complex(md["J12"]).real   # coherent exchange (real dominant part)

    sys = ChiralTwoQubitSystem(
        omega_e1=0.0, omega_e2=0.0,
        gamma11=gamma11, gamma22=gamma22,
        gamma12_abs=abs(gamma12), chiral_phase_deg=phi_c,
        J12=J12_val, gamma_deph=gamma_deph
    )

    L = sys._liouvillian_matrix()
    evals_L = np.linalg.eigvals(L)

    # Sort by real part
    evals_L = sorted(evals_L, key=lambda x: x.real)

    re_max = max(v.real for v in evals_L)
    stability_ok = re_max <= 1e-6 * abs(evals_L[-1].real)

    # Report slowest relaxation timescale (most negative non-zero Re(lambda))
    nonzero = [v for v in evals_L if abs(v.real) > 1e-6 * abs(min(v.real for v in evals_L))]
    slowest = max(nonzero, key=lambda x: x.real)
    tau_L_ps = -1e12 / slowest.real if slowest.real < 0 else float("inf")

    print(f"  All 16 Liouvillian eigenvalues Re(lambda_n):")
    for n, ev in enumerate(evals_L):
        marker = " <-- zero mode (steady state)" if abs(ev) < 1e-3 * abs(evals_L[0].real) else ""
        print(f"    n={n:2d}: Re={ev.real:+.4e}  Im={ev.imag:+.4e}{marker}")
    print(f"  max Re(lambda_n) = {re_max:.4e}  {'✓ All <= 0 (stable)' if stability_ok else '✗ UNSTABLE!'}")
    print(f"  Slowest relaxation timescale: tau_L = {tau_L_ps:.3f} ps  (at gamma_deph={gamma_deph:.3e} rad/s)")

    passed = stability_ok
    print(PASS if passed else FAIL)
    return passed, {"evals_L_real": [v.real for v in evals_L],
                    "tau_L_ps": tau_L_ps, "re_max": re_max}


# ─────────────────────────────────────────────────────────────────────────────
# TEST 11: Full G -> Gamma,J -> L -> rho(t) -> C(t) pipeline closure
# ─────────────────────────────────────────────────────────────────────────────

def test_11_pipeline_closure(md, gamma_deph=0.005e12):
    header(11, "Full pipeline closure: G -> Gamma,J -> L -> rho(t) -> C(t)")

    gamma11 = md["gamma11"].real
    gamma22 = md["gamma22"].real
    gamma12 = md["gamma12"]
    phi_c   = float(np.degrees(np.angle(md["gamma12"])))
    J12_val = complex(md["J12"]).real

    sys = ChiralTwoQubitSystem(
        omega_e1=0.0, omega_e2=0.0,
        gamma11=gamma11, gamma22=gamma22,
        gamma12_abs=abs(gamma12), chiral_phase_deg=phi_c,
        J12=J12_val, gamma_deph=gamma_deph
    )

    t_ps  = np.linspace(0, T_PS_OBS, N_TIMES)
    t_sec = t_ps * 1e-12
    res   = sys.simulate(t_sec, "psi_minus")

    C_t   = res["concurrence"]
    _trapz = getattr(np, "trapezoid", None) or np.trapz
    C_bar = float(_trapz(C_t, t_ps) / T_PS_OBS)

    # Entanglement lifetime: first t where C < 0.5
    below = np.where(C_t < 0.5)[0]
    tau_C05_ps = float(t_ps[below[0]]) if len(below) > 0 else T_PS_OBS

    print(f"  From BEM Green tensor -> Gamma, J -> Liouvillian -> rho(t):")
    print(f"  C(t=0)              = {C_t[0]:.6f}  (should be 1.0 for |Psi^->)")
    print(f"  C(t=10 ps)          = {C_t[int(N_TIMES*0.2)]:.6f}")
    print(f"  C(t=25 ps)          = {C_t[int(N_TIMES*0.5)]:.6f}")
    print(f"  C(t=50 ps)          = {C_t[-1]:.6f}")
    print(f"  C_bar_{T_PS_OBS:.0f}ps         = {C_bar:.6f}  [ACTUAL: will replace manuscript value]")
    print(f"  tau_C(0.5)          = {tau_C05_ps:.3f} ps")

    passed = abs(C_t[0] - 1.0) < 0.01   # initial state correctly prepared
    print(PASS if passed else FAIL)
    return passed, {"C_t0": float(C_t[0]), "C_bar": C_bar,
                    "tau_C05_ps": tau_C05_ps, "C_t": C_t.tolist()}


# ─────────────────────────────────────────────────────────────────────────────
# TEST 12: Concurrence independently verified (Wootters 1998)
# ─────────────────────────────────────────────────────────────────────────────

def test_12_concurrence_verification():
    header(12, "Concurrence independently verified (analytical Bell states)")

    sy = np.array([[0, -1j], [1j, 0]], dtype=complex)
    sy_sy = np.kron(sy, sy)

    def wootters_concurrence(rho):
        rho_tilde = sy_sy @ np.conj(rho) @ sy_sy
        R = rho @ rho_tilde
        evals = np.sqrt(np.maximum(0, np.real(np.linalg.eigvals(R))))
        evals = np.sort(evals)[::-1]
        return float(max(0, evals[0] - evals[1] - evals[2] - evals[3]))

    # Known exact cases
    psi_minus = np.array([0, 1, -1, 0], dtype=complex) / np.sqrt(2)
    rho_psi_minus = np.outer(psi_minus, np.conj(psi_minus))
    C_bell = wootters_concurrence(rho_psi_minus)

    rho_mixed = np.eye(4, dtype=complex) / 4.0
    C_mixed = wootters_concurrence(rho_mixed)

    ok1 = abs(C_bell  - 1.0) < 1e-10
    ok2 = abs(C_mixed - 0.0) < 1e-10

    print(f"  C(|Psi^->) = {C_bell:.10f}  (expected 1.0)  {'✓' if ok1 else '✗'}")
    print(f"  C(I/4)     = {C_mixed:.10f}  (expected 0.0)  {'✓' if ok2 else '✗'}")
    print(f"  Cross-check against chiral_master_equation.concurrence:")
    from chiral_master_equation import concurrence as cme_concurrence
    C_cme = cme_concurrence(rho_psi_minus)
    ok3   = abs(C_cme - 1.0) < 1e-10
    print(f"  cme_concurrence(|Psi^->) = {C_cme:.10f}  {'✓ Consistent' if ok3 else '✗ Mismatch!'}")

    passed = ok1 and ok2 and ok3
    print(PASS if passed else FAIL)
    return passed, {"C_bell": C_bell, "C_mixed": C_mixed}


# ─────────────────────────────────────────────────────────────────────────────
# TEST 13: Factorial control design — isolate amplitude (beta) vs phase (eta)
# ─────────────────────────────────────────────────────────────────────────────

def test_13_factorial_control(md, gamma_deph=0.005e12):
    header(13, "Factorial control design: isolate Effect A (beta) vs Effect B (eta)")

    gamma11 = md["gamma11"].real
    gamma22 = md["gamma22"].real
    gamma12 = md["gamma12"]
    phi_c_actual = float(np.degrees(np.angle(md["gamma12"])))
    J12_val = complex(md["J12"]).real

    # Actual beta and phi from BEM
    beta12_actual = abs(gamma12) / gamma11

    _trapz = getattr(np, "trapezoid", None) or np.trapz

    def run_case(beta12, phi_deg, name):
        sys = ChiralTwoQubitSystem(
            omega_e1=0.0, omega_e2=0.0,
            gamma11=gamma11, gamma22=gamma22,
            gamma12_abs=beta12 * gamma11, chiral_phase_deg=phi_deg,
            J12=J12_val, gamma_deph=gamma_deph
        )
        t_ps  = np.linspace(0, T_PS_OBS, N_TIMES)
        res   = sys.simulate(t_ps * 1e-12, "psi_minus")
        C_t   = res["concurrence"]
        C_bar = float(_trapz(C_t, t_ps) / T_PS_OBS)
        below = np.where(C_t < 0.5)[0]
        tau05 = float(t_ps[below[0]]) if len(below) > 0 else T_PS_OBS
        tau_L = res["lifetime_ps"]
        return C_bar, tau05, tau_L

    # All 4 factorial cases with IDENTICAL parameters except beta12, phi_chiral
    cases = [
        ("C_0: Achiral reference",          0.0,          0.0),
        ("C_A: Amplitude only (phi=0)",     beta12_actual, 0.0),
        ("C_B: Phase only (beta=beta/2)",   beta12_actual / 2.0, phi_c_actual),
        ("C_AB: Full FDTD (beta, phi)",     beta12_actual, phi_c_actual),
    ]

    case_results = {}
    print(f"  Identical parameters across all cases: "
          f"gamma11={gamma11:.3e}, gamma22={gamma22:.3e}, "
          f"J12={J12_val:.3e}, gamma_deph={gamma_deph:.3e}")
    print(f"  beta_12 (actual from BEM): {beta12_actual:.4f}")
    print(f"  phi_chiral (actual from BEM): {phi_c_actual:.4f} deg")
    print(f"\n  {'Case':<40} {'beta12':>8} {'phi_deg':>10} {'tau_L':>10} {'tau_C0.5':>10} {'C_bar':>8}")
    print(f"  {'-'*90}")

    for name, beta12, phi_deg in cases:
        C_bar, tau05, tau_L = run_case(beta12, phi_deg, name)
        case_results[name] = {"C_bar": C_bar, "tau05": tau05, "tau_L": tau_L}
        print(f"  {name:<40} {beta12:>8.4f} {phi_deg:>10.2f} {tau_L:>10.3f} {tau05:>10.3f} {C_bar:>8.4f}")

    # Non-additive interaction metric (precise formula — not assumed)
    C_0  = case_results["C_0: Achiral reference"]["C_bar"]
    C_A  = case_results["C_A: Amplitude only (phi=0)"]["C_bar"]
    C_B  = case_results["C_B: Phase only (beta=beta/2)"]["C_bar"]
    C_AB = case_results["C_AB: Full FDTD (beta, phi)"]["C_bar"]

    Delta_int = C_AB - C_A - C_B + C_0
    print(f"\n  Non-additive interaction metric:")
    print(f"  Delta_int = C_AB - C_A - C_B + C_0")
    print(f"            = {C_AB:.4f} - {C_A:.4f} - {C_B:.4f} + {C_0:.4f}")
    print(f"            = {Delta_int:.4f}")
    print(f"  Physical interpretation: "
          f"{'destructive (modes interfere)' if Delta_int < -0.01 else 'approximately additive' if abs(Delta_int) < 0.01 else 'constructive'}")
    print(f"  [NOTE: Origin of Delta_int < 0 not yet determined — ablation analysis required]")

    print(PASS + "  (reporting — no assertion on control-case values)")
    return True, {"C_0": C_0, "C_A": C_A, "C_B": C_B, "C_AB": C_AB,
                  "Delta_int": Delta_int, "beta12_actual": beta12_actual,
                  "phi_c_actual": phi_c_actual}


# ─────────────────────────────────────────────────────────────────────────────
# TEST 14: FDTD/BEM convergence proxy (geometry sensitivity check)
# ─────────────────────────────────────────────────────────────────────────────

def test_14_geometry_sensitivity(md_base, lam_nm):
    header(14, "Geometry sensitivity: gamma_12(g), J_12(g), beta(g), eta(g)")

    gaps_nm = [4.0, 5.0, 5.7, 7.0, 10.0, 15.0]
    print(f"  {'gap_nm':>8} {'|gamma12| ps-1':>16} {'J12 ps-1':>14} {'beta12':>10} {'eta deg':>10}")
    print(f"  {'-'*65}")

    gap_data = []
    for g in gaps_nm:
        geom_g = dict(GEOM); geom_g["gap_nm"] = g
        dimer_g = ChiralNanorodDimer(**geom_g)
        r1 = np.array([0.0, 0.0, -g/4.0])
        r2 = np.array([0.0, 0.0, +g/4.0])
        try:
            md_g = extract_full_matrices(dimer_g, r1, r2, lam_nm, D0_Cm)
            g11  = md_g["gamma11"].real
            g12  = md_g["gamma12"]
            j12  = complex(md_g["J12"])
            beta = abs(g12) / g11 if g11 > 0 else float("nan")
            phi_c = np.degrees(np.angle(g12))
            phi_j = np.degrees(np.angle(j12)) if abs(j12) > 1e-30 else 0.0
            eta_v = phi_c - phi_j
            print(f"  {g:>8.1f} {abs(g12)*1e-12:>16.4f} {j12.real*1e-12:>14.4f} {beta:>10.4f} {eta_v:>10.2f}")
            gap_data.append({"g": g, "beta12": beta, "eta": eta_v, "gamma12_mag": abs(g12), "J12": j12.real})
        except Exception as e:
            print(f"  {g:>8.1f}  [ERROR: {e}]")

    print(PASS + "  (reporting — no assertion)")
    return True, {"gap_data": gap_data}


# ─────────────────────────────────────────────────────────────────────────────
# TEST 15: Dephasing sensitivity analysis
# ─────────────────────────────────────────────────────────────────────────────

def test_15_dephasing_sensitivity(md):
    header(15, "Dephasing sensitivity: C_bar_T vs gamma_phi")

    gamma11 = md["gamma11"].real
    gamma22 = md["gamma22"].real
    gamma12 = md["gamma12"]
    phi_c   = float(np.degrees(np.angle(md["gamma12"])))
    J12_val = complex(md["J12"]).real

    _trapz = getattr(np, "trapezoid", None) or np.trapz

    deph_rates = [0.0, 0.001e12, 0.005e12, 0.01e12, 0.05e12, 0.10e12,
                  0.15e12, 0.25e12]

    print(f"  {'gamma_phi [ps-1]':>20} {'gamma_phi/gamma11':>20} {'C_bar_T':>12}")
    print(f"  {'-'*55}")

    sensitivity_data = []
    C_bar_zero_deph = None
    for gd in deph_rates:
        sys = ChiralTwoQubitSystem(
            omega_e1=0.0, omega_e2=0.0,
            gamma11=gamma11, gamma22=gamma22,
            gamma12_abs=abs(gamma12), chiral_phase_deg=phi_c,
            J12=J12_val, gamma_deph=gd
        )
        t_ps  = np.linspace(0, T_PS_OBS, N_TIMES)
        res   = sys.simulate(t_ps * 1e-12, "psi_minus")
        C_t   = res["concurrence"]
        C_bar = float(_trapz(C_t, t_ps) / T_PS_OBS)
        ratio = gd / gamma11 if gamma11 > 0 else float("nan")
        label = f"{gd*1e-12:.3f}"
        print(f"  {label:>20} {ratio:>20.4f} {C_bar:>12.6f}")
        if gd == 0.0:
            C_bar_zero_deph = C_bar
        sensitivity_data.append({"gamma_deph": gd, "ratio": ratio, "C_bar": C_bar})

    print(f"\n  [NOTE] gamma_phi = 0.005 ps-1 is used in control cases.")
    print(f"  [NOTE] gamma_phi = 0.15  ps-1 is the commonly cited room-temperature value.")
    print(f"  [NOTE] The correct physical gamma_phi must be determined from emitter model.")
    print(f"  [NOTE] The table above shows the sensitivity range — this is a phenomenological sweep,")
    print(f"         NOT a room-temperature microscopic model.")

    print(PASS + "  (reporting — no assertion)")
    return True, {"sensitivity_data": sensitivity_data}


# ─────────────────────────────────────────────────────────────────────────────
# MAIN: Run all 15 tests
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("=" * 72)
    print("  PROJECT 1: Physics Validation Suite (Pre-Manuscript)")
    print("  All values are CALCULATED — not inherited from old manuscript.")
    print(f"  Geometry: L={GEOM['length_nm']}nm, gap={GEOM['gap_nm']}nm, theta={GEOM['twist_angle_deg']}deg")
    print(f"  Wavelength: lambda_0 = {LAM0_NM} nm")
    print(f"  Dipole:     d_0 = {D0_Cm:.3e} C.m  (~3 Debye)")
    print("=" * 72)

    # Build dimer and emitter positions (off-axis in the chiral near-field gap)
    dimer = ChiralNanorodDimer(**GEOM)
    r1_nm = np.array([+5.0, 0.0, -GEOM["gap_nm"] / 4.0])
    r2_nm = np.array([-5.0, 0.0, +GEOM["gap_nm"] / 4.0])

    # Extract full Gamma and J from BEM Green tensors
    md = extract_full_matrices(dimer, r1_nm, r2_nm, LAM0_NM, D0_Cm)

    # Run all 15 tests
    test_results = {}

    p, d = test_01_ImG_convention(md)
    test_results["T01_ImG_convention"] = {"pass": p, **d}

    p, d = test_02_gamma_hermitian(md)
    test_results["T02_Gamma_Hermitian"] = {"pass": p, **d}

    p, d = test_03_gamma_positive(md)
    test_results["T03_Gamma_PSD"] = {"pass": p, **d}

    p, d = test_04_lindblad_reconstruction(md)
    test_results["T04_Lindblad"] = {"pass": p, **d}

    p, d = test_05_J_hermitian(md)
    test_results["T05_J_Hermitian"] = {"pass": p, **d}

    p, d = test_06_gauge_transformation(md)
    test_results["T06_gauge_transform"] = {"pass": p, **d}

    p, d = test_07_eta_value(md)
    test_results["T07_eta"] = {"pass": p, **d}

    p, d = test_08_commutator(md)
    test_results["T08_commutator"] = {"pass": p, **d}

    p, d = test_09_HNH_eigenspectrum(md)
    test_results["T09_HNH"] = {"pass": p, **d}

    p, d = test_10_liouvillian_stability(md)
    test_results["T10_Liouvillian"] = {"pass": p, **d}

    p, d = test_11_pipeline_closure(md)
    test_results["T11_closure"] = {"pass": p, **d}

    p, d = test_12_concurrence_verification()
    test_results["T12_concurrence"] = {"pass": p, **d}

    p, d = test_13_factorial_control(md)
    test_results["T13_factorial"] = {"pass": p, **d}

    p, d = test_14_geometry_sensitivity(md, LAM0_NM)
    test_results["T14_sensitivity"] = {"pass": p, **d}

    p, d = test_15_dephasing_sensitivity(md)
    test_results["T15_dephasing"] = {"pass": p, **d}

    # ── Summary Report ────────────────────────────────────────────────────────
    print("\n" + "=" * 72)
    print("  VALIDATION SUMMARY — These values will determine manuscript claims")
    print("=" * 72)

    n_pass = sum(1 for v in test_results.values() if v["pass"])
    n_fail = len(test_results) - n_pass

    print(f"\n  {'Test':<30} {'Status':<10}")
    print(f"  {'-'*42}")
    for name, v in test_results.items():
        status = "PASS ✓" if v["pass"] else "FAIL ✗"
        print(f"  {name:<30} {status}")

    print(f"\n  Total: {n_pass}/{len(test_results)} passed, {n_fail} failed")

    if "T03_Gamma_PSD" in test_results:
        d3 = test_results["T03_Gamma_PSD"]
        print(f"\n  ── Parameter Provenance (actual calculated values) ──")
        print(f"  lambda_0       = {LAM0_NM} nm")
        print(f"  gamma_11       = {md['gamma11'].real:.4e} rad/s  = {md['gamma11'].real*1e-12:.4f} ps^-1")
        print(f"  gamma_22       = {md['gamma22'].real:.4e} rad/s  = {md['gamma22'].real*1e-12:.4f} ps^-1")
        print(f"  |gamma_12|     = {abs(md['gamma12']):.4e} rad/s  = {abs(md['gamma12'])*1e-12:.4f} ps^-1")
        print(f"  beta_12        = {d3.get('beta12', float('nan')):.6f}  [ACTUAL, not 0.891]")
        print(f"  arg(gamma_12)  = {np.degrees(np.angle(md['gamma12'])):.4f} deg  [basis-dependent]")
        print(f"  J_12 (real)    = {complex(md['J12']).real:.4e} rad/s  = {complex(md['J12']).real*1e-12:.4f} ps^-1")
        print(f"  arg(J_12)      = {np.degrees(np.angle(complex(md['J12']))):.4f} deg")
        print(f"  eta            = {test_results.get('T07_eta', {}).get('eta', float('nan')):.4f} deg  [gauge-invariant]")
        print(f"  eta_[J,Gamma]  = {test_results.get('T08_commutator', {}).get('eta_J_Gamma', float('nan')):.6f}  [RECALCULATED, not 0.906]")
        if "T13_factorial" in test_results:
            d13 = test_results["T13_factorial"]
            print(f"  C_0 (achiral)  = {d13.get('C_0', float('nan')):.6f}")
            print(f"  C_A (amp only) = {d13.get('C_A', float('nan')):.6f}")
            print(f"  C_B (phase)    = {d13.get('C_B', float('nan')):.6f}")
            print(f"  C_AB (full)    = {d13.get('C_AB', float('nan')):.6f}")
            print(f"  Delta_int      = {d13.get('Delta_int', float('nan')):.6f}  [ACTUAL: C_AB - C_A - C_B + C_0]")

    print("\n" + "=" * 72)
    if n_fail > 0:
        print("  [ACTION REQUIRED] Fix failing tests before generating manuscript.")
    else:
        print("  [GO] All tests passed. Values above replace legacy manuscript numbers.")
    print("=" * 72)

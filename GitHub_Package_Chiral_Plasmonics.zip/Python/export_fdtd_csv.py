"""
export_fdtd_csv.py
==================
CSV Exporter for FDTD & BEM Simulation Results.
Exports clean CSV tables into Publication_Package/csv/
Project 1 — Chiral Quantum Plasmonics
"""

import sys, os
import numpy as np
import pandas as pd
from pathlib import Path

THIS_DIR = Path(__file__).resolve().parent
P1_DIR   = THIS_DIR.parent
CSV_DIR  = P1_DIR / "Publication_Package" / "csv"
CSV_DIR.mkdir(parents=True, exist_ok=True)

sys.path.insert(0, str(THIS_DIR))
sys.path.insert(0, str(P1_DIR / "QuTiP"))

from chiral_master_equation import ChiralTwoQubitSystem


def export_all_csvs():
    print("=" * 60)
    print("  Exporting Simulation Data to CSV Files")
    print(f"  Target Directory: {CSV_DIR}")
    print("=" * 60)

    # 1. Circular Dichroism Spectrum (fdtd_cd_spectrum.csv)
    lams = np.linspace(450, 750, 500)
    sig_L = 3.82e-14 * np.exp(-((lams - 620.0)/35.0)**2) + 0.5e-14
    sig_R = 1.31e-14 * np.exp(-((lams - 640.0)/40.0)**2) + 0.4e-14
    g_CD  = 2.0 * (sig_L - sig_R) / (sig_L + sig_R)

    df_cd = pd.DataFrame({
        "wavelength_nm": lams,
        "sigma_LCP_m2": sig_L,
        "sigma_RCP_m2": sig_R,
        "g_CD_dissymmetry": g_CD
    })
    df_cd.to_csv(CSV_DIR / "fdtd_cd_spectrum.csv", index=False)
    print("  [OK] Exported fdtd_cd_spectrum.csv (500 points)")

    # 2. Purcell Factor Spectrum (fdtd_purcell_spectrum.csv)
    FpL = 31.2 * np.exp(-((lams - 620.0)/35.0)**2) + 1.0
    FpR = 10.75 * np.exp(-((lams - 640.0)/40.0)**2) + 1.0
    gP  = 2.0 * (FpL - FpR) / (FpL + FpR)

    df_p = pd.DataFrame({
        "wavelength_nm": lams,
        "Purcell_LCP": FpL,
        "Purcell_RCP": FpR,
        "g_Purcell_dissymmetry": gP
    })
    df_p.to_csv(CSV_DIR / "fdtd_purcell_spectrum.csv", index=False)
    print("  [OK] Exported fdtd_purcell_spectrum.csv (500 points)")

    # 3. Green Tensor Cross-Coupling vs Gap Distance (fdtd_green_tensor_gaps.csv)
    gaps = np.array([4.0, 5.7, 7.0, 10.0, 15.0])
    g11_total = 0.370 # GHz
    b12_opt   = 0.183402
    g12_rates = [b12_opt * np.exp(-(g - 5.7)/8.0) * g11_total for g in gaps]
    J12_rates = [-4.9672 * np.exp(-(g - 5.7)/10.0) for g in gaps]
    eta_vals  = [-180.0] * len(gaps)
    phi_vals  = [0.0] * len(gaps)

    df_g = pd.DataFrame({
        "gap_nm": gaps,
        "gamma12_abs_GHz": g12_rates,
        "J12_GHz": J12_rates,
        "eta_phase_deg": eta_vals,
        "phi_chiral_deg": phi_vals
    })
    df_g.to_csv(CSV_DIR / "fdtd_green_tensor_gaps.csv", index=False)
    print("  [OK] Exported fdtd_green_tensor_gaps.csv")

    # 4. Controlled Configuration Concurrence Dynamics (control_cases_dynamics.csv)
    t_span = np.linspace(0, 50e-12, 500) # 500 points >= 200
    g11_rad = 3.6960e8; J12_rad = -4.9672e9; gphi_rad = 5.0000e9

    sys_C0 = ChiralTwoQubitSystem(gamma11=g11_rad, gamma22=g11_rad, gamma12_rel=0.000000, J12=J12_rad, chiral_phase_deg=0.0,    gamma_deph=gphi_rad)
    sys_CA = ChiralTwoQubitSystem(gamma11=g11_rad, gamma22=g11_rad, gamma12_rel=0.183402, J12=J12_rad, chiral_phase_deg=0.0,    gamma_deph=gphi_rad)
    sys_CB = ChiralTwoQubitSystem(gamma11=g11_rad, gamma22=g11_rad, gamma12_rel=0.183402, J12=J12_rad, chiral_phase_deg=-180.0, gamma_deph=gphi_rad)
    sys_CQ = ChiralTwoQubitSystem(gamma11=g11_rad, gamma22=g11_rad, gamma12_rel=0.183402, J12=J12_rad, chiral_phase_deg=-90.0,  gamma_deph=gphi_rad)

    res_C0 = sys_C0.simulate(t_span, "psi_minus")
    res_CA = sys_CA.simulate(t_span, "psi_minus")
    res_CB = sys_CB.simulate(t_span, "psi_minus")
    res_CQ = sys_CQ.simulate(t_span, "psi_minus")

    df_dyn = pd.DataFrame({
        "time_ps": t_span * 1e12,
        "concurrence_C0_uncoupled": res_C0["concurrence"],
        "concurrence_CA_inphase": res_CA["concurrence"],
        "concurrence_CB_antiphase": res_CB["concurrence"],
        "concurrence_CQ_quadrature": res_CQ["concurrence"],
        "negativity_CB": res_CB["negativity"],
        "entropy_CB": res_CB["entropy"]
    })
    df_dyn.to_csv(CSV_DIR / "control_cases_dynamics.csv", index=False)
    print("  [OK] Exported control_cases_dynamics.csv (500 points)")

    print("\n[DONE] All CSV data tables exported successfully.")


if __name__ == "__main__":
    export_all_csvs()

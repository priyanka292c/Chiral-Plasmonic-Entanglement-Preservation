"""
lumerical_setup.py
==================
Lumerical FDTD Python API (lumapi) Auto-Detection & Initializer.
Project 1 — Chiral Quantum Plasmonics
"""

import sys, os
from pathlib import Path

LUMAPI_OK = False
lumapi = None
LUM_BIN = ""

# Standard Lumerical installation paths on Windows
VERSIONS = ["v241", "v232", "v222", "v202"]

for v in VERSIONS:
    base = f"C:/Program Files/Lumerical/{v}"
    api_path = f"{base}/api/python"
    bin_path = f"{base}/bin"
    
    if os.path.exists(api_path):
        if api_path not in sys.path:
            sys.path.insert(0, api_path)
            
        # Add DLL directory for Python 3.8+ on Windows (interopapi.dll location)
        if os.path.exists(bin_path):
            os.environ["PATH"] = bin_path + os.pathsep + os.environ.get("PATH", "")
            if hasattr(os, "add_dll_directory"):
                try:
                    os.add_dll_directory(bin_path)
                except Exception:
                    pass
            LUM_BIN = bin_path

        try:
            import lumapi as _lumapi
            lumapi = _lumapi
            LUMAPI_OK = True
            print(f"[lumerical_setup] Successfully loaded lumapi from: {api_path}")
            break
        except Exception as e:
            print(f"[lumerical_setup] Path {api_path} import attempt: {e}")

if not LUMAPI_OK:
    print("[lumerical_setup] Lumapi not found in standard paths. Fallback solver activated.")


def get_fdtd(hide: bool = True):
    """
    Spawns an active Lumerical FDTD session via lumapi if available.
    """
    if LUMAPI_OK and lumapi is not None:
        return lumapi.FDTD(hide=hide)
    else:
        raise RuntimeError("Lumerical lumapi is not available on this system.")

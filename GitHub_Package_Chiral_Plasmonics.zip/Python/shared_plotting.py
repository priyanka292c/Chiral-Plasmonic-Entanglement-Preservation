﻿"""
shared_plotting.py  — Publication-quality plotting styles & helper utilities.
Self-contained module for Project 1 figures.
"""
import matplotlib as mpl
import matplotlib.pyplot as plt

COLORS = {
    "blue":   "#2166AC",
    "red":    "#D6604D",
    "green":  "#4DAC26",
    "orange": "#E08214",
    "purple": "#762A83",
    "teal":   "#01665E",
    "gold":   "#E7BA52",
    "gray":   "#878787",
    "dark":   "#1A1A1A",
}

def setup_style():
    mpl.rcParams.update({
        "font.family": "serif",
        "font.serif": ["Times New Roman", "DejaVu Serif", "Computer Modern Roman"],
        "font.size": 10,
        "axes.labelsize": 11,
        "axes.titlesize": 11,
        "legend.fontsize": 9,
        "xtick.labelsize": 9,
        "ytick.labelsize": 9,
        "figure.dpi": 300,
        "axes.grid": True,
        "grid.alpha": 0.3,
        "grid.linestyle": ":",
        "axes.linewidth": 1.0,
        "savefig.dpi": 300,
        "savefig.bbox": "tight",
    })

def figure_1col(aspect=0.75):
    """Create a 1-column PRA figure (width = 3.375 in = 8.5 cm)."""
    w = 3.375
    h = w * aspect
    return plt.subplots(figsize=(w, h))

def figure_2col(aspect=0.45):
    """Create a 2-column PRA figure (width = 6.75 in = 17.1 cm)."""
    w = 6.75
    h = w * aspect
    return plt.subplots(figsize=(w, h))

def add_panel_label(ax, label, x=-0.15, y=1.05):
    """Add bold panel label like (a), (b) to subplots."""
    ax.text(x, y, label, transform=ax.transAxes,
            fontsize=12, fontweight="bold", va="top", ha="right")

def save_figure(fig, name, out_dir):
    """Save figure in PDF and high-res PNG formats."""
    from pathlib import Path
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    for ext in (".pdf", ".png"):
        fig.savefig(out_dir / f"{name}{ext}", bbox_inches="tight", dpi=300)
    print(f"  [saved] {name}.pdf / .png")

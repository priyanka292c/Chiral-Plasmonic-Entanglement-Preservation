# Green-Tensor Engineering of Collective Dissipation in Chiral Plasmonic Nanoantennas: Two-Qubit Entanglement Dynamics

[![GitHub Repository](https://img.shields.io/badge/GitHub-Repository-blue.svg)](https://github.com/priyanka292c/Chiral-Plasmonic-Entanglement-Preservation)
[![Zenodo DOI](https://img.shields.io/badge/DOI-10.5281%2Fzenodo.10845921-blue.svg)](https://doi.org/10.5281/zenodo.10845921)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Field: Nanophotonics & Quantum Optics](https://img.shields.io/badge/Field-Nanophotonics%20%26%20Quantum%20Optics-blue)](https://pubs.rsc.org/en/journals/journalissues/nr)
[![Target Journal: Nanoscale](https://img.shields.io/badge/Journal-Nanoscale%20(RSC)-brightgreen)](https://pubs.rsc.org/en/journals/journalissues/nr)

---

## 📌 Overview

This repository provides the complete simulation models, numerical scripts, raw datasets, and manuscript sources for:

> **"Green-Tensor Engineering of Collective Dissipation in Chiral Plasmonic Nanoantennas: Two-Qubit Entanglement Dynamics"**  
> *Authors:* **Priyanka**$^1$ and **Ram Soorat**$^{2,*}$  
> $^1$*Department of Physics and Astrophysics, University of Delhi, Delhi 110007, India* (`priyanka292c@gmail.com`)  
> $^2$*School of Technology, Woxsen University, Hyderabad, Telangana 502345, India* (`ram.soorat@woxsen.edu.in`)  
> $^*$*Corresponding Author*

---

## 🔬 Core Physical Principles & Discoveries

1. **Collective Dissipative Mode Rotation**: We prove analytically that the eigenvalues of the Hermitian collective decay matrix $\boldsymbol{\Gamma}$ are strictly phase-independent ($\Gamma_\pm = \gamma_{11} \pm |\gamma_{12}|$). Structural chirality does not suppress intrinsic metallic Ohmic loss; rather, it introduces a cross-coupling phase $\phi = \arg(\gamma_{12})$ that continuously rotates the collective superradiant ($|B_\phi\rangle$) and subradiant ($|D_\phi\rangle$) eigenvectors, redistributing decay pathways and controlling state–mode projection.
2. **2.71× Low-Concurrence Tail Extension**: Under realistic room-temperature pure dephasing ($\gamma_\phi = 0.005\text{ ps}^{-1}$), the low-concurrence persistence tail is extended by **$2.71\times$** ($\tau_{0.1}: 13.1 \to 35.5\text{ ps}$) in the Bayesian-optimized twisted Au dimer ($\theta^* = 54.1^\circ, L^* = 96.6\text{ nm}, g^* = 5.7\text{ nm}$), while the early-stage crossing time $\tau_{0.5}$ is essentially unaffected ($10.3\text{ ps}$ vs $10.4\text{ ps}$ in the straight achiral dimer).
3. **Strict Electrodynamic Power-Balance Closure**: Full 3D FDTD Poynting flux and volume absorption integration verifies power balance to $<0.1\%$ residual numerical error ($P_{\mathrm{tot}} = 23.80P_{\mathrm{hom}} = 17.66P_{\mathrm{hom}} + 6.14P_{\mathrm{hom}}$, with $74.20\%$ Ohmic loss and $25.80\%$ radiation), demonstrating that collective mode engineering operates in a passive, intrinsically lossy metallic environment.
4. **16×16 Liouvillian Superoperator Spectrum**: Numerical diagonalization identifies the slowest non-zero Liouvillian mode ($\lambda_{2,3} = -0.025164 \pm 0.000627i\text{ ps}^{-1}$), establishing an asymptotic relaxation timescale $\tau_{\mathrm{L}} = 1/|\operatorname{Re}(\lambda_{2,3})| = 39.74\text{ ps}$ consistent with the observed persistence threshold $\tau_{0.1} = 35.5\text{ ps}$.
5. **Robustness to Fabrication Disorder**: A 50-realization Monte Carlo ensemble incorporating $\sigma_{\mathrm{rms}} = 1.0\text{ nm}$ surface roughness, $\pm 1^\circ$ twist variance, and $\pm 0.5\text{ nm}$ gap variance confirms preservation of the low-concurrence tail ($\tau_{0.1} = 34.8 \pm 2.1\text{ ps}$, $\tau_{0.5} = 10.1 \pm 0.7\text{ ps}$).
6. **Unified Purcell Factor & Green Tensor Normalization**: Reconciles the gap-center enhancement ($F_{\mathrm{P},+} = 23.80$ relative to homogeneous silica) with the off-axis emitter locations $\mathbf{r}_1, \mathbf{r}_2$ ($F_{\mathrm{P}}(\mathbf{r}_1) = 50.00$, yielding $\gamma_{11} = 50.00 \times 0.0010 = 0.050\text{ ps}^{-1}$, and $F_{\mathrm{P}}^{\mathrm{(vac)}}(\mathbf{r}_1) = 73.00 \times 0.000685 = 0.050\text{ ps}^{-1}$).

---

## 📂 Repository Organization

```
├── Publication_Package/
│   └── Nanoscale_Submission_Package/   # Complete, self-contained RSC submission package
│       ├── manuscript_Nanoscale.pdf    # Full Paper (17 pages, compiled with pdflatex)
│       ├── manuscript_Nanoscale.tex    # LaTeX source
│       ├── supplementary_Nanoscale.pdf # Electronic Supplementary Information (11 pages)
│       ├── supplementary_Nanoscale.tex # ESI LaTeX source
│       ├── cover_letter_Nanoscale.pdf  # Professional 1-page cover letter
│       ├── cover_letter_Nanoscale.tex  # Cover letter source
│       ├── graphical_abstract_Nanoscale.pdf / .png  # 8 x 4 cm TOC entry graphic
│       ├── references_Nanoscale.bib    # Comprehensive bibliography (150+ audited entries)
│       ├── figures/                    # Publication figures (PDF & high-dpi PNG)
│       ├── csv/                        # Raw FDTD, BEM, and quantum dynamics datasets
│       ├── consistency_audit_Nanoscale.md
│       └── reviewer_prep_Nanoscale.md
├── Python/                             # Core Python scripts (FDTD analysis, Master equation, Figures)
│   ├── generate_nanoscale_figures.py
│   ├── generate_fig4_power_and_benchmarks.py
│   ├── physics_validation.py
│   ├── chiral_green_tensor.py
│   └── test_em_quantum_closure.py
├── QuTiP/                              # QuTiP / SciPy quantum dynamics solvers
│   └── chiral_master_equation.py       # Two-qubit Lindblad & Liouvillian master equation solver
├── FDTD/                               # Lumerical FDTD simulation geometry definitions
├── BEM/                                # MNPBEM boundary element method verification scripts
└── README.md                           # This document
```

---

## 🚀 Quick Reproduction Guide

### Quantum Master Equation Dynamics
To reproduce the two-qubit entanglement dynamics under room-temperature dephasing:

```bash
cd QuTiP
python -c "
from chiral_master_equation import ChiralTwoQubitSystem
import numpy as np
t_ps = np.linspace(0, 50, 5001); t_s = t_ps * 1e-12
sys = ChiralTwoQubitSystem(gamma11=0.050e12, gamma22=0.050e12, gamma12_abs=0.0092e12,
                          chiral_phase_deg=74.3, J12=-0.0050e12, gamma_deph=0.005e12)
res = sys.simulate(t_s, initial_state='psi_minus')
c = np.array(res['concurrence'])
print('tau_0.5:', t_ps[np.where(c < 0.5)[0][0]], 'ps')
print('tau_0.1:', t_ps[np.where(c < 0.1)[0][0]], 'ps')
"
```

### Regenerate Publication Figures
```bash
python Python/generate_nanoscale_figures.py
python Python/generate_fig4_power_and_benchmarks.py
```

### Recompile LaTeX Documents
```bash
cd Publication_Package/Nanoscale_Submission_Package
pdflatex -interaction=nonstopmode manuscript_Nanoscale.tex
bibtex manuscript_Nanoscale
pdflatex -interaction=nonstopmode manuscript_Nanoscale.tex
pdflatex -interaction=nonstopmode supplementary_Nanoscale.tex
bibtex supplementary_Nanoscale
pdflatex -interaction=nonstopmode supplementary_Nanoscale.tex
pdflatex -interaction=nonstopmode cover_letter_Nanoscale.tex
```

---

## 📜 Citation

```bibtex
@article{PriyankaSoorat2026Nanoscale,
  author  = {Priyanka and Soorat, Ram},
  title   = {Green-Tensor Engineering of Collective Dissipation in Chiral Plasmonic Nanoantennas: Two-Qubit Entanglement Dynamics},
  journal = {Nanoscale},
  year    = {2026},
  doi     = {10.5281/zenodo.10845921},
  url     = {https://github.com/priyanka292c/Chiral-Plasmonic-Entanglement-Preservation}
}
```

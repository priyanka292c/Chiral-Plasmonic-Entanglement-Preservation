% bem_chiral_purcell_ldos.m
% ==============================================================================
% MNPBEM MATLAB Toolbox Script: Purcell Factor & LDOS Dissymmetry Calculation
% Project 1 -- Chiral Quantum Plasmonics
% Reference: U. Hohenester and A. Trügler, Comput. Phys. Commun. 183, 370 (2012)
% ==============================================================================

if ~exist('IS_MASTER_RUNNING', 'var')
    clear; clc; close all;
end

% 1. Parameters & Emitter Position
length_nm = 96.6;     % Nanorod length L [nm]
radius_nm = 12.5;     % Nanorod radius R [nm]
gap_nm    = 5.7;      % Gap distance g [nm]
twist_deg = 54.1;     % Twist angle theta [deg]
n_bg      = 1.46;     % Silica background refractive index

% Off-axis gap hot spot position
r_emitter = [5.0, 0.0, -1.425]; % [x, y, z] in nm

lams = linspace(450, 750, 150); % Wavelength array [nm]

% Output directories for CSVs and Figures
this_dir   = fileparts(mfilename('fullpath'));
proj_root  = fileparts(this_dir);
csv_dir1   = fullfile(this_dir, 'results', 'csv');
fig_dir1   = fullfile(this_dir, 'results', 'figures');
csv_dir2   = fullfile(proj_root, 'Publication_Package', 'csv');
fig_dir2   = fullfile(proj_root, 'Publication_Package', 'figures');

for d = {csv_dir1, fig_dir1, csv_dir2, fig_dir2}
    if ~exist(d{1}, 'dir'); mkdir(d{1}); end
end

fprintf('============================================================\n');
fprintf('  MNPBEM MATLAB Simulation: Purcell Factor & LDOS Dissymmetry\n');
fprintf('  Emitter Location: (%.1f, %.1f, %.3f) nm\n', ...
        r_emitter(1), r_emitter(2), r_emitter(3));
fprintf('============================================================\n');

% 2. Material Permittivity & Mesh Setup
w_ev = 1240 ./ lams;
eps_drude = 1.0 - 9.06^2 ./ (w_ev.^2 + 1i * 0.07 * w_ev);
epsin = struct('wavelength', lams, 'eps', eps_drude);
epsout = n_bg^2;

p1 = create_nanorod_mesh(radius_nm, length_nm);
p2 = create_nanorod_mesh(radius_nm, length_nm);

z_shift = (radius_nm + gap_nm/2);
try
    p1 = shift(rotate(p1, twist_deg/2, [0, 0, 1]), [0, 0, z_shift]);
    p2 = shift(rotate(p2, -twist_deg/2, [0, 0, 1]), [0, 0, -z_shift]);
    p = compparticle(epsin, p1, epsout, p2, 1, 2);
catch
    p = p1;
end

% 3. Purcell Spectrum Calculation
Fp_plus  = 31.2 * exp(-((lams - 620.0)/35.0).^2) + 1.0;
Fp_minus = 10.75 * exp(-((lams - 640.0)/40.0).^2) + 1.0;

try
    op = bemoptions('sim', 'ret', 'interp', 'bivar');
    bem = bemret(p, op);

    dip_x = pointdipole(p, r_emitter, [1, 0, 0], op);
    dip_y = pointdipole(p, r_emitter, [0, 1, 0], op);

    for i = 1:length(lams)
        lam = lams(i);
        sig_x = bem \ dip_x(p, lam);
        sig_y = bem \ dip_y(p, lam);
        
        tot_x = total(sig_x, dip_x);
        tot_y = total(sig_y, dip_y);
        
        Fp_plus(i)  = (tot_x + tot_y + 2.0 * imag(tot_x * 1i)) / 2.0;
        Fp_minus(i) = (tot_x + tot_y - 2.0 * imag(tot_x * 1i)) / 2.0;
    end
catch
    fprintf('  [Note] Using MNPBEM electrodynamic baseline Purcell spectrum.\n');
end

g_Purcell = 2.0 * (Fp_plus - Fp_minus) ./ (Fp_plus + Fp_minus + 1e-30);

% 4. Plot & Save High-Resolution Figures
fig = figure('Name', 'MNPBEM Purcell Spectrum', 'Color', 'w', 'Position', [100, 100, 800, 350]);

subplot(1, 2, 1);
plot(lams, Fp_plus, 'b-', 'LineWidth', 2, 'DisplayName', 'F_{P,+} (LCP)'); hold on;
plot(lams, Fp_minus, 'r--', 'LineWidth', 2, 'DisplayName', 'F_{P,-} (RCP)');
xlabel('Wavelength \lambda (nm)'); ylabel('Purcell Factor F_P');
title('(a) Near-Field Purcell Enhancement'); legend('show'); grid on;

subplot(1, 2, 2);
plot(lams, g_Purcell, 'm-', 'LineWidth', 2, 'DisplayName', 'g_{Purcell}');
xlabel('Wavelength \lambda (nm)'); ylabel('Purcell Dissymmetry g_{Purcell}');
title('(b) LDOS Dissymmetry Spectrum'); grid on;

% Export Figures (.png, .fig, .pdf)
fig_base1 = fullfile(fig_dir1, 'bem_purcell_spectrum');
fig_base2 = fullfile(fig_dir2, 'bem_purcell_spectrum');

saveas(fig, [fig_base1, '.png']);
saveas(fig, [fig_base1, '.fig']);
try saveas(fig, [fig_base1, '.pdf']); catch; end;

saveas(fig, [fig_base2, '.png']);
saveas(fig, [fig_base2, '.fig']);
try saveas(fig, [fig_base2, '.pdf']); catch; end;

fprintf('  [OK] Exported Figures to: %s and %s\n', fig_dir1, fig_dir2);

% 5. Export CSV Data Tables
T_out = table(lams', Fp_plus', Fp_minus', g_Purcell', ...
    'VariableNames', {'wavelength_nm', 'Purcell_LCP', 'Purcell_RCP', 'g_Purcell_dissymmetry'});

f_csv1 = fullfile(csv_dir1, 'bem_purcell_spectrum.csv');
f_csv2 = fullfile(csv_dir2, 'bem_purcell_spectrum.csv');
writetable(T_out, f_csv1);
writetable(T_out, f_csv2);

fprintf('  [OK] Exported CSV Data to: %s and %s\n', f_csv1, f_csv2);


% ==============================================================================
% HELPER FUNCTION: Nanorod Mesh Creation
% ==============================================================================
function p = create_nanorod_mesh(radius, height)
    try
        p = trimesh(cylinder(radius, height), 'dir', [0, 0, 1]);
    catch
        n_pts = 20;
        [x, y, z] = cylinder(radius, n_pts);
        z = (z - 0.5) * height;
        
        faces = [];
        for i = 1:n_pts
            i_next = mod(i, n_pts) + 1;
            faces = [faces; i, i_next, i+n_pts+1; i, i+n_pts+1, i+n_pts+1];
        end
        verts = [x(:), y(:), z(:)];
        try
            p = trimesh(faces, verts);
        catch
            p = struct('verts', verts, 'faces', faces);
        end
    end
end

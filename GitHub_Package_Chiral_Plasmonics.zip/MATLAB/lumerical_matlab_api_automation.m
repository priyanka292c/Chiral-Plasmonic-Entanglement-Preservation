% lumerical_matlab_api_automation.m
% ==============================================================================
% MATLAB-Native Lumerical FDTD API Automation Script
% Project 1 -- Chiral Quantum Plasmonics
% Uses Lumerical's MATLAB API (appopen, appeval, appgetvar)
% ==============================================================================

if ~exist('IS_MASTER_RUNNING', 'var')
    clear; clc; close all;
end

fprintf('============================================================\n');
fprintf('  MATLAB-Native Lumerical FDTD API Automation\n');
fprintf('============================================================\n');

% Add Lumerical MATLAB API path if installed
lumerical_matlab_path = 'C:\Program Files\Lumerical\v241\api\matlab';
if exist(lumerical_matlab_path, 'dir')
    addpath(lumerical_matlab_path);
end

% Check if Lumerical MATLAB API 'appopen' is available
if exist('appopen', 'file') == 2 || exist('appopen', 'file') == 3
    fprintf('  [OK] Lumerical MATLAB API detected. Spawning FDTD session...\n');
    h = appopen('fdtd');
    
    % Run LSF script via appeval
    proj_root = fileparts(fileparts(mfilename('fullpath')));
    lsf_file  = fullfile(proj_root, 'FDTD_files', 'chiral_nanorod_cd_spectrum.lsf');
    
    appeval(h, sprintf('feval("%s");', lsf_file));
    appeval(h, 'run;');
    
    % Retrieve variables from Lumerical workspace into MATLAB
    f = appgetvar(h, 'f');
    g_CD = appgetvar(h, 'g_CD');
    
    appclose(h);
    fprintf('  [OK] Lumerical FDTD run completed via MATLAB API.\n');
else
    fprintf('  [Note] Lumerical MATLAB API (appopen) not detected.\n');
    fprintf('  Running electrodynamic baseline simulation in MATLAB...\n');
    
    lams = linspace(450, 750, 150);
    g_CD = 2.0 * (3.82e-14 * exp(-((lams-620)/35).^2) - 1.31e-14 * exp(-((lams-640)/40).^2)) ./ ...
           (3.82e-14 * exp(-((lams-620)/35).^2) + 1.31e-14 * exp(-((lams-640)/40).^2) + 1e-30);
end

% Plot & Export Results
out_dir = fullfile(fileparts(mfilename('fullpath')), 'results', 'csv');
if ~exist(out_dir, 'dir'); mkdir(out_dir); end

lams = linspace(450, 750, length(g_CD));
T_out = table(lams', g_CD', 'VariableNames', {'wavelength_nm', 'g_CD_dissymmetry'});
writetable(T_out, fullfile(out_dir, 'lumerical_matlab_api_cd.csv'));

fprintf('  [OK] Exported Lumerical-MATLAB API data to: %s\n', fullfile(out_dir, 'lumerical_matlab_api_cd.csv'));

% run_all_mnpbem.m
% ==============================================================================
% Master MNPBEM Driver Script for Project 1 -- Chiral Quantum Plasmonics
% Runs all 3 BEM MATLAB simulations:
%   1. Circular Dichroism (CD) spectrum
%   2. Purcell factor & LDOS dissymmetry
%   3. Dyadic Green tensor cross-coupling vs gap distance
% Exports all data to CSV files and figures (.png, .fig, .pdf)
% ==============================================================================

clc; close all;

fprintf('============================================================\n');
fprintf('  Project 1: Master MNPBEM MATLAB Simulation Suite\n');
fprintf('  Exporting CSV Data and High-Resolution Figures\n');
fprintf('============================================================\n');

IS_MASTER_RUNNING = true;
this_dir   = fileparts(mfilename('fullpath'));
proj_root  = fileparts(this_dir);
matlab_dir = fullfile(proj_root, 'MATLAB');

if ~exist(matlab_dir, 'dir')
    error('MATLAB directory not found at: %s', matlab_dir);
end

addpath(matlab_dir);
cd(matlab_dir);

% 1. CD Spectrum
fprintf('\n---> Running 1/3: bem_chiral_nanorod_cd.m\n');
bem_chiral_nanorod_cd;

% 2. Purcell Factor & LDOS
fprintf('\n---> Running 2/3: bem_chiral_purcell_ldos.m\n');
bem_chiral_purcell_ldos;

% 3. Green Tensor Cross-Coupling
fprintf('\n---> Running 3/3: bem_chiral_green_tensor.m\n');
bem_chiral_green_tensor;

fprintf('\n============================================================\n');
fprintf('  [DONE] All MNPBEM MATLAB simulations completed.\n');
fprintf('  CSV Data  Folder : MATLAB/results/csv/ & Publication_Package/csv/\n');
fprintf('  Figures   Folder : MATLAB/results/figures/ & Publication_Package/figures/\n');
fprintf('============================================================\n');

"""
chiral_master_equation.py
=========================
Two-Qubit Master Equation in Chiral Plasmonic Vacuum.
Project 1 — Quantum Plasmonic Entanglement Research Program.

Solves the Lindblad quantum master equation for two quantum emitters
(dipoles d1, d2) coupled to a chiral reservoir characterized by asymmetric
cross-decay rates (gamma12 != gamma21) and handedness-dependent Purcell factors.

Hamiltonian:
  H = (hbar * omega_e1 / 2) sigma_z1 + (hbar * omega_e2 / 2) sigma_z2
      + hbar * J12 (sigma_1^+ sigma_2^- + sigma_1^- sigma_2^+)

Master Equation:
  d rho / dt = -i/hbar [H, rho]
               + sum_{i,j=1}^2 gamma_{ij} ( sigma_j^- rho sigma_i^+
                                            - 0.5 {sigma_i^+ sigma_j^-, rho} )
               + sum_{i=1}^2 gamma_deph_i D[sigma_zi] rho

Where for a chiral bath:
  gamma_11 = gamma_0 * F_P(r1)
  gamma_22 = gamma_0 * F_P(r2)
  gamma_12 = gamma_0 * (Im[G12] + i * g_chiral * Re[G12])
  gamma_21 = conj(gamma_12)  => asymmetric cross-coupling if chiral!

Key Outputs:
  1. Concurrence C(rho(t)) (Wootters 1998)
  2. Negativity N(rho(t)) (Vidal & Werner 2002)
  3. Von Neumann entropy S_vN(rho(t))
  4. Entanglement preservation gain: eta_C = int C_chiral(t) dt / int C_achiral(t) dt

References:
  - Wootters, W. K. Phys. Rev. Lett. 80, 2245 (1998). DOI: 10.1103/PhysRevLett.80.2245
  - Gonzalez-Tudela, A. et al. Phys. Rev. Lett. 106, 020501 (2011).
    DOI: 10.1103/PhysRevLett.106.020501
  - Baranov, D. G. et al. ACS Photonics 7, 10, 2636 (2020).
    DOI: 10.1021/acsphotonics.0c00939
"""

from __future__ import annotations
import sys
import numpy as np
import scipy.linalg as la
from pathlib import Path
from typing import Dict, Tuple, Optional

try:
    import qutip as qt
    QUTIP_AVAILABLE = True
except ImportError:
    qt = None
    QUTIP_AVAILABLE = False

PROJ_ROOT = Path(__file__).parents[2]
SYS_MASTER = PROJ_ROOT / "_Master"
if str(SYS_MASTER) not in sys.path:
    sys.path.insert(0, str(SYS_MASTER))

from shared_constants import HBAR


# =============================================================================
# Entanglement Metrics (Exact Matrix Algebra)
# =============================================================================

def bell_state(state_type: str = "psi_plus") -> np.ndarray:
    """
    Two-qubit Bell states in computational basis {|00>, |01>, |10>, |11>}.
    """
    states = {
        "psi_plus" : np.array([0, 1, 1, 0], dtype=complex) / np.sqrt(2.0),
        "psi_minus": np.array([0, 1, -1, 0], dtype=complex) / np.sqrt(2.0),
        "phi_plus" : np.array([1, 0, 0, 1], dtype=complex) / np.sqrt(2.0),
        "phi_minus": np.array([1, 0, 0, -1], dtype=complex) / np.sqrt(2.0),
    }
    return states.get(state_type, states["psi_plus"])


def concurrence(rho: np.ndarray) -> float:
    """
    Wootters concurrence C(rho) for an arbitrary 4x4 two-qubit density matrix.
    C(rho) = max(0, lambda1 - lambda2 - lambda3 - lambda4)
    """
    rho = np.asarray(rho, dtype=complex)
    if rho.shape != (4, 4):
        raise ValueError(f"Density matrix must be 4x4, got {rho.shape}")

    # Spin-flip matrix sigma_y tensor sigma_y
    sy = np.array([[0, -1j], [1j, 0]], dtype=complex)
    sy_sy = np.kron(sy, sy)

    # Spin-flipped density matrix rho_tilde = (sy_sy) * rho^* * (sy_sy)
    rho_tilde = sy_sy @ np.conj(rho) @ sy_sy

    # R = sqrt(sqrt(rho) * rho_tilde * sqrt(rho))
    # Equivalent to eigenvalues of rho * rho_tilde
    R_mat = rho @ rho_tilde
    evals = np.linalg.eigvals(R_mat)
    # Numerical safety: take sqrt of real part of non-negative evals
    lambdas = np.sort(np.sqrt(np.maximum(0.0, np.real(evals))))[::-1]

    C_val = lambdas[0] - lambdas[1] - lambdas[2] - lambdas[3]
    return float(max(0.0, C_val))


def negativity(rho: np.ndarray) -> float:
    """
    Negativity N(rho) = (|Tr(rho^PT)| - 1) / 2 = sum_i max(0, -mu_i)
    where mu_i are the eigenvalues of the partial transpose rho^PT.
    """
    rho = np.asarray(rho, dtype=complex)
    # Partial transpose with respect to qubit B (subsystem 2)
    rho_pt = np.zeros((4, 4), dtype=complex)
    for i in range(2):
        for j in range(2):
            for k in range(2):
                for l in range(2):
                    # (i,j) for A, (k,l) for B -> index 2*i+k, 2*j+l
                    # PT B swaps k and l
                    rho_pt[2*i + l, 2*j + k] = rho[2*i + k, 2*j + l]

    evals = np.linalg.eigvalsh(rho_pt)
    neg = np.sum(np.maximum(0.0, -evals))
    return float(neg)


def von_neumann_entropy(rho: np.ndarray) -> float:
    """
    Von Neumann entropy S(rho) = -Tr(rho log2 rho).
    """
    rho = np.asarray(rho, dtype=complex)
    evals = np.linalg.eigvalsh(rho)
    evals = evals[evals > 1e-15]  # Avoid log(0)
    S = -np.sum(evals * np.log2(evals))
    return float(max(0.0, np.real(S)))


# =============================================================================
# Two-Qubit Chiral Master Equation Solver
# =============================================================================

class ChiralTwoQubitSystem:
    """
    Two-qubit quantum emitter system coupled to a chiral plasmonic bath.

    Parameters
    ----------
    omega_e1, omega_e2 : float
        Emitter transition frequencies [rad/s]
    gamma11, gamma22 : float
        Self-decay rates of emitters 1 and 2 [rad/s]
    gamma12_abs : float
        Magnitude of cross-decay rate |gamma12| [rad/s]
    chiral_phase_deg : float
        Chiral phase angle phi_c [deg]. Non-zero value creates asymmetric coupling!
    J12 : float
        Coherent dipole-dipole coupling strength [rad/s]
    gamma_deph : float
        Pure dephasing rate for each qubit [rad/s]
    """

    def __init__(self, omega_e1: float = 2.0 * np.pi * 5.0e14,
                 omega_e2: float = 2.0 * np.pi * 5.0e14,
                 gamma11: float = 1e11, gamma22: float = 1e11,
                 gamma12_abs: float = 0.9e11, chiral_phase_deg: float = 30.0,
                 J12: float = 0.5e11, gamma_deph: float = 1e10):
        self.omega_e1 = omega_e1
        self.omega_e2 = omega_e2
        self.gamma11  = gamma11
        self.gamma22  = gamma22
        self.gamma12_abs = gamma12_abs
        self.phi_c_rad   = np.radians(chiral_phase_deg)
        self.J12       = J12
        self.gamma_deph = gamma_deph

        # Complex cross-decay rate gamma12 = |gamma12| * exp(i * phi_c)
        # For chiral bath: gamma21 = gamma12* != gamma12
        self.gamma12 = gamma12_abs * np.exp(1j * self.phi_c_rad)
        self.gamma21 = np.conj(self.gamma12)

    def _liouvillian_matrix(self) -> np.ndarray:
        """
        Builds the 16x16 Liouvillian superoperator matrix L in vec(rho) basis.
        d/dt vec(rho) = L * vec(rho)
        """
        I2 = np.eye(2, dtype=complex)
        I4 = np.eye(4, dtype=complex)

        # Qubit operators in basis {|0>, |1>} (|0>=ground, |1>=excited)
        sm = np.array([[0, 1], [0, 0]], dtype=complex)  # lowering
        sp = np.array([[0, 0], [1, 0]], dtype=complex)  # raising
        sz = np.array([[1, 0], [0, -1]], dtype=complex) # Pauli Z

        # Tensor products: Qubit 1 x Qubit 2
        sm1 = np.kron(sm, I2); sp1 = np.kron(sp, I2); sz1 = np.kron(sz, I2)
        sm2 = np.kron(I2, sm); sp2 = np.kron(I2, sp); sz2 = np.kron(sz, I2)

        # Hamiltonian
        H = (self.omega_e1 / 2.0) * sz1 + (self.omega_e2 / 2.0) * sz2 \
            + self.J12 * (sp1 @ sm2 + sm1 @ sp2)

        # -i [H, rho] in vector format: -i (I x H - H^T x I)
        L_H = -1j * (np.kron(I4, H) - np.kron(H.T, I4))

        # Dissipators: D[A] = A x A^* - 0.5 (I x A^\dagger A + A^T A^* x I)
        def dissipator(A_op):
            A_dag = np.conj(A_op).T
            term1 = np.kron(A_op, np.conj(A_op))
            term2 = 0.5 * np.kron(I4, A_dag @ A_op)
            term3 = 0.5 * np.kron((A_dag @ A_op).T, I4)
            return term1 - term2 - term3

        def cross_dissipator(A_op, B_op):
            # A_op rho B_op^\dagger - 0.5 {B_op^\dagger A_op, rho}
            B_dag = np.conj(B_op).T
            term1 = np.kron(A_op, np.conj(B_op))
            term2 = 0.5 * np.kron(I4, B_dag @ A_op)
            term3 = 0.5 * np.kron((B_dag @ A_op).T, I4)
            return term1 - term2 - term3

        L_diss = (self.gamma11 * dissipator(sm1) +
                  self.gamma22 * dissipator(sm2) +
                  self.gamma12 * cross_dissipator(sm1, sm2) +
                  self.gamma21 * cross_dissipator(sm2, sm1) +
                  self.gamma_deph * dissipator(sz1) +
                  self.gamma_deph * dissipator(sz2))

        return L_H + L_diss

    def simulate(self, t_array: np.ndarray,
                 initial_state: str = "psi_plus") -> Dict[str, np.ndarray]:
        """
        Simulates density matrix evolution rho(t) and calculates entanglement dynamics.

        Parameters
        ----------
        t_array : 1D ndarray
            Time points [seconds]
        initial_state : 'psi_plus' | 'psi_minus' | 'phi_plus' | 'phi_minus'

        Returns
        -------
        dict containing:
            'times_ps': t_array in picoseconds
            'concurrence': C(t) array
            'negativity': N(t) array
            'entropy': S(t) array
            'rho_t': array of 4x4 density matrices over time
            'lifetime_ps': time until C < 0.1
        """
        psi0 = bell_state(initial_state)
        rho0 = np.outer(psi0, np.conj(psi0))

        L = self._liouvillian_matrix()
        vec_rho0 = rho0.flatten()

        N_t = len(t_array)
        C_t = np.zeros(N_t)
        N_t_arr = np.zeros(N_t)
        S_t = np.zeros(N_t)
        rho_t = np.zeros((N_t, 4, 4), dtype=complex)

        # Exponentiate Liouvillian for time evolution
        for i, t in enumerate(t_array):
            if t == 0:
                vec_rho_t = vec_rho0
            else:
                exp_Lt = la.expm(L * t)
                vec_rho_t = exp_Lt @ vec_rho0

            rho_curr = vec_rho_t.reshape((4, 4))
            # Enforce hermiticity and unit trace
            rho_curr = 0.5 * (rho_curr + np.conj(rho_curr).T)
            tr = np.trace(rho_curr)
            if abs(tr) > 1e-12:
                rho_curr /= tr

            rho_t[i] = rho_curr
            C_t[i]   = concurrence(rho_curr)
            N_t_arr[i] = negativity(rho_curr)
            S_t[i]   = von_neumann_entropy(rho_curr)

        # Calculate entanglement lifetime (time to C < 0.1)
        below_thresh = np.where(C_t < 0.1)[0]
        if len(below_thresh) > 0:
            lifetime_ps = float(t_array[below_thresh[0]] * 1e12)
        else:
            lifetime_ps = float(t_array[-1] * 1e12)

        return {
            "times_ps": t_array * 1e12,
            "concurrence": C_t,
            "negativity": N_t_arr,
            "entropy": S_t,
            "rho_t": rho_t,
            "lifetime_ps": lifetime_ps
        }


def compare_chiral_vs_achiral(t_array: np.ndarray,
                              chiral_phase_deg: float = 45.0) -> Dict[str, Union[dict, float]]:
    """
    Compares entanglement dynamics between Chiral and Achiral plasmonic baths.
    Calculates Entanglement Preservation Gain eta_C.
    """
    sys_chiral  = ChiralTwoQubitSystem(chiral_phase_deg=chiral_phase_deg)
    sys_achiral = ChiralTwoQubitSystem(chiral_phase_deg=0.0)

    res_chiral  = sys_chiral.simulate(t_array, "psi_plus")
    res_achiral = sys_achiral.simulate(t_array, "psi_plus")

    # Integrated concurrence (trapezoidal integration)
    from scipy.integrate import trapezoid
    int_C_chiral  = trapezoid(res_chiral["concurrence"], t_array)
    int_C_achiral = trapezoid(res_achiral["concurrence"], t_array)

    gain_eta = int_C_chiral / (int_C_achiral + 1e-15)

    return {
        "chiral": res_chiral,
        "achiral": res_achiral,
        "preservation_gain_eta": float(gain_eta),
        "lifetime_chiral_ps": res_chiral["lifetime_ps"],
        "lifetime_achiral_ps": res_achiral["lifetime_ps"]
    }


# =============================================================================
# Self-Test
# =============================================================================
if __name__ == "__main__":
    print("=" * 65)
    print("  Project 1: Chiral Two-Qubit Master Equation Self-Test")
    print("=" * 65)

    # 1. Test Bell state concurrence
    psi_plus = bell_state("psi_plus")
    rho_psi = np.outer(psi_plus, np.conj(psi_plus))
    C_bell = concurrence(rho_psi)
    N_bell = negativity(rho_psi)
    S_bell = von_neumann_entropy(rho_psi)

    print(f"\nBell State |Psi+> Entanglement Metrics:")
    print(f"  Concurrence C : {C_bell:.4f} (Expected: 1.0000)")
    print(f"  Negativity N  : {N_bell:.4f} (Expected: 0.5000)")
    print(f"  vN Entropy S  : {S_bell:.4f} (Expected: 0.0000)")
    assert abs(C_bell - 1.0) < 1e-6, "FAIL: Bell state concurrence must be 1.0!"

    # 2. Simulate time evolution: Chiral vs Achiral bath
    t_span = np.linspace(0, 50e-12, 100)  # 0 to 50 ps
    comp = compare_chiral_vs_achiral(t_span, chiral_phase_deg=45.0)

    print(f"\nChiral vs Achiral Entanglement Preservation (0 - 50 ps):")
    print(f"  Chiral Lifetime (C > 0.1)  : {comp['lifetime_chiral_ps']:.2f} ps")
    print(f"  Achiral Lifetime (C > 0.1) : {comp['lifetime_achiral_ps']:.2f} ps")
    print(f"  Preservation Gain (eta_C)  : {comp['preservation_gain_eta']:.2f}x")

    assert comp["preservation_gain_eta"] >= 0.99, \
        "FAIL: Chiral bath must preserve entanglement equal to or better than achiral bath!"

    print("\n  PASS: chiral_master_equation.py operational.")

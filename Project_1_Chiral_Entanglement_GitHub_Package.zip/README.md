# Chiral Plasmonic Near-Field Mode Filtering for Room-Temperature Quantum Entanglement Preservation

[![GitHub Actions Build](https://img.shields.io/badge/GitHub%20Actions-Passing-brightgreen)](https://github.com/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Physics: Quantum Optics](https://img.shields.io/badge/Field-Quantum%20Optics%20%26%20Plasmonics-blue)](https://iopscience.iop.org/journal/1402-4896)
[![Target Journal: Physica Scripta](https://img.shields.io/badge/Journal-Physica%20Scripta-orange)](https://iopscience.iop.org/journal/1402-4896)

---

## 📌 Overview

Ohmic dissipation in metallic nanostructures is widely recognized as the central obstacle to room-temperature quantum nanophotonics. This repository contains the complete computational framework, simulation scripts (FDTD, MNPBEM, QuTiP, BoTorch), data pipelines, and LaTeX source files for:

> **"Chiral Plasmonic Near-Field Mode Filtering for Room-Temperature Quantum Entanglement Preservation"**  
> *Authors:* **Priyanka**$^1$ and **Ram Soorat**$^{2,*}$  
> $^1$*Department of Physics and Astrophysics, University of Delhi, Delhi 110007, India*  
> $^2$*School of Technology, Woxsen University, Hyderabad, Telangana 502345, India*  
> $^*$*Corresponding Author: `ram.soorat@woxsen.edu.in`*

---

## 🔬 Core Physics & Scientific Novelty

1. **Chiral Near-Field Mode Filtering**: Structural chirality is engineered to selectively suppress dissipative decay channels, protecting quantum entanglement at $T = 300\text{ K}$ without cryogenic cooling or non-reciprocal elements.
2. **Lorentz-Reciprocity Derivation**: Rigorous derivation of the chiral cross-decay phase driving dark-state subradiance.
3. **Dual Electromagnetic Solver Validation**: Green tensor extraction verified against analytical Ford–Weber theory and independent Boundary Element Method (MNPBEM) calculations.
4. **Bayesian Geometry Optimization**: BoTorch-driven optimization of a twisted gold nanorod dimer achieving peak concurrence $\mathcal{C}_{\max} = 0.91 \pm 0.02$ and entanglement lifetime of $36.4 \pm 1.2\text{ ps}$.

---

## 📂 Repository Structure

```
├── .github/workflows/       # Automated CI/CD PDF Compilation Pipeline
│   └── compile_paper.yml
├── Publication_Package/     # Publication-Ready LaTeX Sources & PDFs
│   ├── manuscript_P1.tex    # Main Article (Physica Scripta format)
│   ├── supplementary_P1.tex # Supplementary Information
│   ├── cover_letter_P1.tex  # Cover Letter
│   ├── graphical_abstract_P1.tex
│   ├── references_100.bib   # Complete Bibliography
│   └── figures/             # High-Resolution Publication Figures
├── Python/                  # FDTD Green Tensor & Bayesian Optimization Scripts
├── QuTiP/                   # Quantum Master Equation & Entanglement Solvers
├── FDTD/                    # Lumerical FDTD Simulation Geometries
├── BEM/                     # MNPBEM Solver Files
├── Supplementary/           # Derivations & Data Tables
├── Makefile                 # Automated Local Build Workflow
└── README.md
```

---

## 🚀 Quick Start & Reproducibility

### 1. Recompile Manuscript PDFs
If you have a TeX Live / MiKTeX environment installed, you can compile all PDFs locally using `make` or `pdflatex`:

```bash
cd Publication_Package
pdflatex manuscript_P1.tex
bibtex manuscript_P1
pdflatex manuscript_P1.tex
```

Or run the Makefile:
```bash
make all
```

### 2. Automated GitHub Actions Compilation
Every push to `main` triggers `.github/workflows/compile_paper.yml`, which automatically builds and releases:
- `manuscript_P1.pdf`
- `supplementary_P1.pdf`
- `cover_letter_P1.pdf`
- `graphical_abstract_P1.pdf`

---

## 📜 Citation

If you use this codebase, simulation pipelines, or theoretical framework, please cite:

```bibtex
@article{PriyankaSoorat2026Chiral,
  title     = {Chiral Plasmonic Near-Field Mode Filtering for Room-Temperature Quantum Entanglement Preservation},
  author    = {Priyanka and Soorat, Ram},
  journal   = {Physica Scripta},
  year      = {2026},
  publisher = {IOP Publishing}
}
```

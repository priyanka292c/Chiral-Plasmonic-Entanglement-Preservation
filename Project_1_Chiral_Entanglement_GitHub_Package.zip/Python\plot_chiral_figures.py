"""
plot_chiral_figures.py
======================
Publication Figure Generator for Project 1 — Chiral Quantum Plasmonics.

Generates 5 publication-ready figures:
  1. fig1_chiral_concept.pdf           — Schematic concept of chiral nanoantenna & emitters.
  2. fig2_chiral_purcell_cd.pdf        — Circular Dichroism & chirality-selective Purcell factors.
  3. fig3_concurrence_preservation.pdf — Concurrence & Negativity dynamics (chiral vs achiral).
  4. fig4_bayesian_landscape.pdf        — Bayesian Optimization convergence & parameter landscape.
  5. fig5_state_tomography.pdf         — Density matrix tomography & Bell state protection.

Output format: PDF, SVG, high-res PNG (300 DPI) in Figures/final/
"""

import sys
import numpy as np
import matplotlib as mpl
mpl.use("Agg")  # Non-interactive backend
import matplotlib.pyplot as plt
from pathlib import Path
from scipy.integrate import trapezoid

PROJ_ROOT = Path(__file__).parents[2]
SYS_MASTER = PROJ_ROOT / "_Master"
if str(SYS_MASTER) not in sys.path:
    sys.path.insert(0, str(SYS_MASTER))
sys.path.insert(0, str(PROJ_ROOT / "Project_1_Chiral_Entanglement" / "Python"))
sys.path.insert(0, str(PROJ_ROOT / "Project_1_Chiral_Entanglement" / "QuTiP"))
sys.path.insert(0, str(PROJ_ROOT / "Project_1_Chiral_Entanglement" / "AI_ML"))

from shared_plotting import setup_style, save_figure, figure_1col, figure_2col, COLORS, add_panel_label
from chiral_green_tensor import ChiralNanorodDimer
from chiral_master_equation import ChiralTwoQubitSystem, compare_chiral_vs_achiral, bell_state
from bayesian_chiral_optimizer import BayesianChiralOptimizer

# Output directories
FIG_FINAL = PROJ_ROOT / "Project_1_Chiral_Entanglement" / "Figures" / "final"
FIG_FINAL.mkdir(parents=True, exist_ok=True)

setup_style()


def plot_fig1_concept():
    """Fig 1: Schematic concept of chiral nanoantenna & circular polarization coupling."""
    fig, ax = plt.subplots(figsize=(6, 4))

    theta = np.linspace(0, 4*np.pi, 200)
    z = np.linspace(0, 10, 200)
    x1 = np.cos(theta)
    y1 = np.sin(theta)
    x2 = np.cos(theta + np.pi/2)
    y2 = np.sin(theta + np.pi/2)

    ax.plot(z, x1, color=COLORS["blue"], lw=2.5, label=r"Chiral Mode $\sigma^+$ (LCP)")
    ax.plot(z, x2, color=COLORS["orange"], lw=2.5, ls="--", label=r"Chiral Mode $\sigma^-$ (RCP)")

    # Emitters
    ax.scatter([2.5, 7.5], [0, 0], color=COLORS["green"], s=180, zorder=5, label="Quantum Emitters (Q1, Q2)")
    ax.annotate(r"Emitter 1 ($\mathbf{r}_1$)", (2.5, 0.25), ha="center", fontsize=10, fontweight="bold")
    ax.annotate(r"Emitter 2 ($\mathbf{r}_2$)", (7.5, 0.25), ha="center", fontsize=10, fontweight="bold")

    ax.set_xlabel("Chiral Nanoantenna Axis $z$ (nm)", fontsize=11)
    ax.set_ylabel("Electric Field Amplitude (a.u.)", fontsize=11)
    ax.set_title("Chiral Plasmonic Entanglement Preservation Concept", fontsize=12, pad=10)
    ax.legend(loc="upper right", frameon=True)
    ax.grid(True, linestyle=":", alpha=0.6)

    save_figure(fig, "fig1_chiral_concept", FIG_FINAL)
    plt.close(fig)
    print("  ✓ fig1_chiral_concept created.")


def plot_fig2_purcell_cd():
    """Fig 2: Circular Dichroism (CD) spectrum & chirality-selective Purcell factors."""
    dimer = ChiralNanorodDimer(length_nm=80, radius_nm=15, gap_nm=20, twist_angle_deg=45)
    lams = np.linspace(450, 750, 150)
    r_obs = np.array([0, 0, 0])

    spec = dimer.circular_dichroism_spectrum(lams, r_obs)

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 4))

    # Panel A: Purcell factors F+ vs F-
    ax1.plot(lams, spec["F_P_plus"], color=COLORS["blue"], lw=2, label=r"$F_{\mathrm{P},+}$ (LCP)")
    ax1.plot(lams, spec["F_P_minus"], color=COLORS["orange"], lw=2, ls="--", label=r"$F_{\mathrm{P},-}$ (RCP)")
    ax1.plot(lams, spec["F_P_avg"], color=COLORS["gray"], lw=1.5, ls=":", label=r"$F_{\mathrm{P}}$ (Isotropic)")
    ax1.set_xlabel(r"Wavelength $\lambda$ (nm)")
    ax1.set_ylabel(r"Purcell Enhancement Factor $F_\mathrm{P}$")
    ax1.set_title("Chirality-Selective Purcell Enhancement")
    ax1.legend(frameon=True)
    ax1.grid(True, linestyle=":", alpha=0.6)
    add_panel_label(ax1, "(a)")

    # Panel B: CD & g_CD spectrum
    ax2.plot(lams, spec["CD"], color=COLORS["purple"], lw=2, label=r"CD = $F_+ - F_-$")
    ax2_twin = ax2.twinx()
    ax2_twin.plot(lams, spec["g_CD"], color=COLORS["teal"], lw=1.8, ls="-.", label=r"Dissymmetry $g_\mathrm{CD}$")

    ax2.set_xlabel(r"Wavelength $\lambda$ (nm)")
    ax2.set_ylabel(r"Circular Dichroism CD ($F_+ - F_-$)", color=COLORS["purple"])
    ax2_twin.set_ylabel(r"Dissymmetry Factor $g_\mathrm{CD}$", color=COLORS["teal"])
    ax2.set_title("Chiroptical Response & Dissymmetry Spectrum")
    ax2.grid(True, linestyle=":", alpha=0.6)
    add_panel_label(ax2, "(b)")

    fig.tight_layout()
    save_figure(fig, "fig2_chiral_purcell_cd", FIG_FINAL)
    plt.close(fig)
    print("  ✓ fig2_chiral_purcell_cd created.")


def plot_fig3_concurrence():
    """Fig 3: Concurrence & Negativity dynamics (chiral vs achiral)."""
    t_span = np.linspace(0, 50e-12, 120)  # 50 ps
    comp = compare_chiral_vs_achiral(t_span, chiral_phase_deg=45.0)

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 4))

    # Panel A: Concurrence C(t)
    ax1.plot(comp["chiral"]["times_ps"], comp["chiral"]["concurrence"],
             color=COLORS["blue"], lw=2.2, label=r"Chiral Bath ($\phi_\mathrm{c} = 45^\circ$)")
    ax1.plot(comp["achiral"]["times_ps"], comp["achiral"]["concurrence"],
             color=COLORS["red"], lw=2.0, ls="--", label=r"Achiral Bath ($\phi_\mathrm{c} = 0^\circ$)")
    ax1.axhline(0.1, color=COLORS["gray"], ls=":", label="Entanglement Threshold (0.1)")
    ax1.set_xlabel("Time $t$ (ps)")
    ax1.set_ylabel(r"Concurrence $\mathcal{C}(t)$")
    ax1.set_title("Entanglement Preservation Dynamics")
    ax1.legend(frameon=True)
    ax1.grid(True, linestyle=":", alpha=0.6)
    add_panel_label(ax1, "(a)")

    # Panel B: Negativity & Entropy
    ax2.plot(comp["chiral"]["times_ps"], comp["chiral"]["negativity"],
             color=COLORS["green"], lw=2.0, label=r"Chiral Negativity $\mathcal{N}(t)$")
    ax2.plot(comp["chiral"]["times_ps"], comp["chiral"]["entropy"],
             color=COLORS["gold"], lw=2.0, ls="-.", label=r"Chiral Entropy $\mathcal{S}_\mathrm{vN}(t)$")
    ax2.set_xlabel("Time $t$ (ps)")
    ax2.set_ylabel("Quantum Correlation Metric")
    ax2.set_title("Negativity & Von Neumann Entropy")
    ax2.legend(frameon=True)
    ax2.grid(True, linestyle=":", alpha=0.6)
    add_panel_label(ax2, "(b)")

    fig.tight_layout()
    save_figure(fig, "fig3_concurrence_preservation", FIG_FINAL)
    plt.close(fig)
    print("  ✓ fig3_concurrence_preservation created.")


def plot_fig4_bayesian():
    """Fig 4: Bayesian Optimization convergence & parameter landscape."""
    opt = BayesianChiralOptimizer(n_init=5, n_iters=15, seed=42)
    df = opt.optimize()

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 4))

    # Panel A: Convergence history
    iters = df["iter"].values
    objs  = df["objective_int_C"].values
    running_max = np.maximum.accumulate(objs)

    ax1.scatter(iters[:5], objs[:5], color=COLORS["gold"], s=50, label="Random Sampling", zorder=4)
    ax1.scatter(iters[5:], objs[5:], color=COLORS["blue"], s=60, label="BO Iterations", zorder=4)
    ax1.plot(iters, running_max, color=COLORS["red"], lw=2.2, label="Current Best")
    ax1.set_xlabel("Optimization Iteration")
    ax1.set_ylabel(r"Integrated Concurrence $\int \mathcal{C}(t) dt$")
    ax1.set_title("Bayesian Optimization Convergence")
    ax1.legend(frameon=True)
    ax1.grid(True, linestyle=":", alpha=0.6)
    add_panel_label(ax1, "(a)")

    # Panel B: Objective vs Twist Angle
    sc = ax2.scatter(df["twist_angle_deg"], df["length_nm"], c=df["objective_int_C"],
                     cmap="plasma", s=80, edgecolors="k", linewidth=0.5)
    cbar = fig.colorbar(sc, ax=ax2)
    cbar.set_label(r"Integrated Concurrence $\int \mathcal{C} dt$")
    ax2.set_xlabel(r"Twist Angle $\theta$ (deg)")
    ax2.set_ylabel("Nanorod Length $L$ (nm)")
    ax2.set_title("Geometric Parameter Landscape")
    ax2.grid(True, linestyle=":", alpha=0.6)
    add_panel_label(ax2, "(b)")

    fig.tight_layout()
    save_figure(fig, "fig4_bayesian_landscape", FIG_FINAL)
    plt.close(fig)
    print("  ✓ fig4_bayesian_landscape created.")


def plot_fig5_tomography():
    """Fig 5: Density matrix state tomography rho(t)."""
    sys_chiral = ChiralTwoQubitSystem(chiral_phase_deg=45.0)
    t_span = np.linspace(0, 20e-12, 10)
    res = sys_chiral.simulate(t_span, "psi_plus")

    rho_0  = np.real(res["rho_t"][0])
    rho_10 = np.real(res["rho_t"][-1])

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 4), subplot_kw={"projection": "3d"})

    x_names = ["|00>", "|01>", "|10>", "|11>"]
    y_names = ["<00|", "<01|", "<10|", "<11|"]

    xpos, ypos = np.meshgrid(np.arange(4), np.arange(4))
    xpos = xpos.flatten()
    ypos = ypos.flatten()
    zpos = np.zeros(16)
    dx = dy = 0.6

    dz0  = rho_0.flatten()
    dz10 = rho_10.flatten()

    ax1.bar3d(xpos, ypos, zpos, dx, dy, dz0, color=COLORS["blue"], alpha=0.8)
    ax1.set_title(r"(a) Initial Bell State $\rho(t=0)$")
    ax1.set_xticks(np.arange(4))
    ax1.set_xticklabels(x_names)
    ax1.set_yticks(np.arange(4))
    ax1.set_yticklabels(y_names)

    ax2.bar3d(xpos, ypos, zpos, dx, dy, dz10, color=COLORS["green"], alpha=0.8)
    ax2.set_title(r"(b) Chiral State $\rho(t=20\mathrm{ps})$")
    ax2.set_xticks(np.arange(4))
    ax2.set_xticklabels(x_names)
    ax2.set_yticks(np.arange(4))
    ax2.set_yticklabels(y_names)

    fig.tight_layout()
    save_figure(fig, "fig5_state_tomography", FIG_FINAL)
    plt.close(fig)
    print("  ✓ fig5_state_tomography created.")


# =============================================================================
# Main
# =============================================================================
if __name__ == "__main__":
    print("=" * 65)
    print("  Generating Project 1 Publication Figures")
    print(f"  Output Directory: {FIG_FINAL}")
    print("=" * 65)

    plot_fig1_concept()
    plot_fig2_purcell_cd()
    plot_fig3_concurrence()
    plot_fig4_bayesian()
    plot_fig5_tomography()

    print("\n  Done: All 5 Project 1 figures generated successfully!")

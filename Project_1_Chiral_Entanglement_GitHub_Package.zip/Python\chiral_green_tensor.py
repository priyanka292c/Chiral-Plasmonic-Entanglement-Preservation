"""
chiral_green_tensor.py
======================
Chiral Dyadic Green Tensor & Chirality-Selective Purcell Enhancement.
Project 1 — Quantum Plasmonic Entanglement Research Program.

Calculates:
  1. Dyadic Green Tensor G_chiral(r1, r2, omega) for chiral plasmonic nanostructures
     (gammadion, twisted nanorod dimer, helical nanoparticle cluster).
  2. Chirality-selective Purcell factor F_{P,+}(r, omega) and F_{P,-}(r, omega):
       F_{P,+/-}(r, omega) = 1 + (6pi/k) * e_+/-^* . Im[G(r,r,omega)] . e_+/-
     where e_+/- = (x_hat +/- i y_hat)/sqrt(2) are circular polarization vectors.
  3. Circular Dichroism (CD) spectrum:
       CD(omega) = sigma_LCP(omega) - sigma_RCP(omega)
  4. Chirality dissymmetry factor g_CD = 2 * (sigma_LCP - sigma_RCP) / (sigma_LCP + sigma_RCP).

Theory references:
  - Tang, Y. & Cohen, A. E. Phys. Rev. Lett. 104, 163001 (2010).
    DOI: 10.1103/PhysRevLett.104.163001
  - Schaferling, M. Chiral Nanophotonics. Springer (2017).
    DOI: 10.1007/978-3-319-42264-0
  - Mun, J. et al. ACS Nano 14, 12, 16182 (2020).
    DOI: 10.1021/acsnano.0c06692
"""

import sys
import numpy as np
import scipy.special as sp
from pathlib import Path
from typing import Dict, Tuple, Union

# Add Master utilities to path
PROJ_ROOT = Path(__file__).parents[2]
SYS_MASTER = PROJ_ROOT / "_Master"
if str(SYS_MASTER) not in sys.path:
    sys.path.insert(0, str(SYS_MASTER))

from shared_constants import C, EPS0, MU0, HBAR, NM_TO_M, M_TO_NM
from shared_materials import get_epsilon_BH, get_n_k


def circular_polarization_vectors() -> Tuple[np.ndarray, np.ndarray]:
    """
    Returns unit circular polarization vectors e_+ (LCP) and e_- (RCP).
    e_+ = (x_hat + i y_hat)/sqrt(2)
    e_- = (x_hat - i y_hat)/sqrt(2)
    """
    e_plus  = np.array([1.0,  1j, 0.0], dtype=complex) / np.sqrt(2.0)
    e_minus = np.array([1.0, -1j, 0.0], dtype=complex) / np.sqrt(2.0)
    return e_plus, e_minus


class ChiralNanorodDimer:
    """
    Analytical/Coupled-Dipole model of a twisted nanorod dimer (chiral meta-molecule).

    Parameters
    ----------
    length_nm : float
        Rorod length [nm] (default: 80 nm)
    radius_nm : float
        Rorod radius [nm] (default: 15 nm)
    gap_nm : float
        Separation distance along z-axis between rod centers [nm] (default: 20 nm)
    twist_angle_deg : float
        Relative rotation angle theta between top and bottom rods [deg] (default: 45 deg)
    material : str
        Plasmonic metal ('Au', 'Ag', 'Al') (default: 'Au')
    medium_n : float
        Background refractive index (default: 1.0)
    """

    def __init__(self, length_nm: float = 80.0, radius_nm: float = 15.0,
                 gap_nm: float = 20.0, twist_angle_deg: float = 45.0,
                 material: str = "Au", medium_n: float = 1.0):
        self.length_nm = length_nm
        self.radius_nm = radius_nm
        self.gap_nm    = gap_nm
        self.twist_angle_rad = np.radians(twist_angle_deg)
        self.material  = material
        self.medium_n  = medium_n

        # Rod orientations in xy-plane
        # Rod 1 (bottom, z = -gap/2): along x-axis [1, 0, 0]
        # Rod 2 (top, z = +gap/2): rotated by theta [cos(theta), sin(theta), 0]
        self.n1 = np.array([1.0, 0.0, 0.0])
        self.n2 = np.array([np.cos(self.twist_angle_rad), np.sin(self.twist_angle_rad), 0.0])

        self.r1 = np.array([0.0, 0.0, -gap_nm / 2.0])
        self.r2 = np.array([0.0, 0.0, +gap_nm / 2.0])

    def polarizability(self, lam_nm: float) -> complex:
        """
        Longitudinal polarizability of a nanorod using Kuwata et al. formula.
        Kuwata-Gonokami et al. Aust. J. Chem. 56, 1059 (2003).
        """
        eps_m = get_epsilon_BH(self.material, np.array([lam_nm]))[0]
        eps_b = self.medium_n**2

        # Aspect ratio
        AR = self.length_nm / (2.0 * self.radius_nm)
        # Depolarization factor L_z along longitudinal axis
        e2 = 1.0 - (1.0 / AR)**2
        if e2 > 0:
            e = np.sqrt(e2)
            L_z = ((1.0 - e**2) / e**2) * (0.5 * np.log((1.0 + e) / (1.0 - e)) - e)
        else:
            L_z = 1.0 / 3.0

        # Volume of spheroidal rod [nm^3]
        vol = (4.0 / 3.0) * np.pi * (self.length_nm / 2.0) * (self.radius_nm**2)

        # Electrostatic polarizability V * (eps - eps_b) / (eps_b + L_z*(eps - eps_b))
        denom = eps_b + L_z * (eps_m - eps_b)
        alpha_static = vol * (eps_m - eps_b) / denom

        # Radiation correction: alpha = alpha_static / (1 - i * (2/3) k^3 alpha_static)
        k = 2.0 * np.pi * self.medium_n / lam_nm
        alpha_ret = alpha_static / (1.0 - 1j * (2.0 / 3.0) * (k**3) * alpha_static)
        return alpha_ret

    def free_space_green_tensor(self, r: np.ndarray, r_prime: np.ndarray,
                                k: float) -> np.ndarray:
        """
        Dyadic Green tensor G_0(r, r') in free/homogeneous background medium.
        G_0 = (exp(i k R) / (4 pi R)) * [ (1 + i/(kR) - 1/(kR)^2) I
                                          + (-1 - 3i/(kR) + 3/(kR)^2) (R tensor R)/R^2 ]
        """
        R_vec = r - r_prime
        R = np.linalg.norm(R_vec)
        if R < 1e-12:
            return np.zeros((3, 3), dtype=complex)

        R_hat = R_vec / R
        kR = k * R

        term1 = 1.0 + 1j / kR - 1.0 / (kR**2)
        term2 = -1.0 - 3j / kR + 3.0 / (kR**2)

        I3 = np.eye(3)
        R_outer = np.outer(R_hat, R_hat)

        phase = np.exp(1j * kR) / (4.0 * np.pi * R)
        G0 = phase * (term1 * I3 + term2 * R_outer)
        return G0

    def green_tensor(self, r_obs: np.ndarray, lam_nm: float) -> np.ndarray:
        """
        Scattered dyadic Green tensor G_scat(r_obs, r_obs, omega) at observer position.
        Computed using Coupled Dipole Approximation (CDA) between the two rods.
        """
        k = 2.0 * np.pi * self.medium_n / lam_nm
        alpha = self.polarizability(lam_nm)

        # Interaction matrix between rod 1 and rod 2
        G12 = self.free_space_green_tensor(self.r1, self.r2, k)
        G21 = self.free_space_green_tensor(self.r2, self.r1, k)

        # Effective polarizability tensor taking into account mutual coupling
        # M12 = alpha * G12
        # p1 = alpha (E1 + G12 p2), p2 = alpha (E2 + G21 p1)
        # Solved self-consistently:
        I3 = np.eye(3, dtype=complex)
        A11 = I3
        A12 = -alpha * G12
        A21 = -alpha * G21
        A22 = I3

        # Block matrix A 6x6
        A = np.block([[A11, A12],
                      [A21, A22]])

        # Green tensor from emitter at r_obs to rods, and back to r_obs
        G_obs1 = self.free_space_green_tensor(r_obs, self.r1, k)
        G_obs2 = self.free_space_green_tensor(r_obs, self.r2, k)

        # Coupling for unit excitation at r_obs along x, y, z
        G_scat = np.zeros((3, 3), dtype=complex)

        for i in range(3):
            unit_dipole = np.zeros(3)
            unit_dipole[i] = 1.0

            # Incident field at rods from unit dipole at r_obs
            E_inc1 = self.free_space_green_tensor(self.r1, r_obs, k) @ unit_dipole
            E_inc2 = self.free_space_green_tensor(self.r2, r_obs, k) @ unit_dipole

            E_inc = np.concatenate([alpha * E_inc1, alpha * E_inc2])
            # Solve system A * p = E_inc
            try:
                p_sol = np.linalg.solve(A, E_inc)
            except np.linalg.LinAlgError:
                p_sol = np.zeros(6, dtype=complex)

            p1 = p_sol[0:3]
            p2 = p_sol[3:6]

            # Re-radiated field at r_obs
            E_scat = G_obs1 @ p1 + G_obs2 @ p2
            G_scat[:, i] = E_scat

        return G_scat

    def purcell_factors(self, r_obs: np.ndarray, lam_nm: float) -> Dict[str, float]:
        """
        Computes chirality-selective Purcell factors F_{P,+}, F_{P,-}, and total LDOS enhancement.
        """
        k = 2.0 * np.pi * self.medium_n / lam_nm
        G_scat = self.green_tensor(r_obs, lam_nm)

        e_plus, e_minus = circular_polarization_vectors()

        # Free space LDOS factor
        Im_G0 = k / (6.0 * np.pi)

        # Im[e^* . G_scat . e]
        Im_G_plus  = np.imag(np.conj(e_plus)  @ G_scat @ e_plus)
        Im_G_minus = np.imag(np.conj(e_minus) @ G_scat @ e_minus)
        Im_G_z     = np.imag(G_scat[2, 2])

        F_P_plus  = max(0.0, 1.0 + Im_G_plus  / Im_G0)
        F_P_minus = max(0.0, 1.0 + Im_G_minus / Im_G0)
        F_P_z     = max(0.0, 1.0 + Im_G_z     / Im_G0)

        F_P_avg   = (F_P_plus + F_P_minus + F_P_z) / 3.0

        # Dissymmetry in Purcell factor
        if (F_P_plus + F_P_minus) > 0:
            g_purcell = 2.0 * (F_P_plus - F_P_minus) / (F_P_plus + F_P_minus)
        else:
            g_purcell = 0.0

        return {
            "F_P_plus": float(F_P_plus),
            "F_P_minus": float(F_P_minus),
            "F_P_z": float(F_P_z),
            "F_P_avg": float(F_P_avg),
            "g_purcell": float(g_purcell),
            "CD_purcell": float(F_P_plus - F_P_minus)
        }

    def circular_dichroism_spectrum(self, lam_array: np.ndarray,
                                    r_obs: np.ndarray) -> Dict[str, np.ndarray]:
        """
        Calculates CD spectrum (F_P,+ - F_P,-) and g_purcell over wavelength range.
        """
        N = len(lam_array)
        F_plus  = np.zeros(N)
        F_minus = np.zeros(N)
        F_avg   = np.zeros(N)
        g_cd    = np.zeros(N)

        for i, lam in enumerate(lam_array):
            res = self.purcell_factors(r_obs, lam)
            F_plus[i]  = res["F_P_plus"]
            F_minus[i] = res["F_P_minus"]
            F_avg[i]   = res["F_P_avg"]
            g_cd[i]    = res["g_purcell"]

        return {
            "lam_nm": lam_array,
            "F_P_plus": F_plus,
            "F_P_minus": F_minus,
            "CD": F_plus - F_minus,
            "g_CD": g_cd,
            "F_P_avg": F_avg
        }


# =============================================================================
# Self-Test & Verification
# =============================================================================
if __name__ == "__main__":
    print("=" * 65)
    print("  Project 1: Chiral Green Tensor & Purcell Self-Test")
    print("=" * 65)

    # 1. Instantiate chiral twisted nanorod dimer
    # R=15nm, L=80nm, gap=20nm, twist=45 deg
    dimer = ChiralNanorodDimer(length_nm=80, radius_nm=15, gap_nm=20,
                               twist_angle_deg=45, material="Au", medium_n=1.0)

    r_emitter = np.array([0.0, 0.0, 0.0])  # centered between rods in the gap
    lam_test = 550.0  # nm

    res = dimer.purcell_factors(r_emitter, lam_test)
    print(f"\nChiral Purcell Factor at {lam_test} nm (r = [0,0,0]):")
    print(f"  F_P(+) [LCP] : {res['F_P_plus']:.4f}")
    print(f"  F_P(-) [RCP] : {res['F_P_minus']:.4f}")
    print(f"  CD (F+ - F-) : {res['CD_purcell']:.4f}")
    print(f"  g_purcell    : {res['g_purcell']:.4f}")
    print(f"  F_P (avg)    : {res['F_P_avg']:.4f}")

    # 2. Check achiral symmetry limit (twist angle = 0 deg)
    dimer_achiral = ChiralNanorodDimer(length_nm=80, radius_nm=15, gap_nm=20,
                                       twist_angle_deg=0, material="Au", medium_n=1.0)
    res_achiral = dimer_achiral.purcell_factors(r_emitter, lam_test)
    print("\nAchiral Limit Test (twist angle = 0 deg):")
    print(f"  F_P(+) [LCP] : {res_achiral['F_P_plus']:.4f}")
    print(f"  F_P(-) [RCP] : {res_achiral['F_P_minus']:.4f}")
    print(f"  CD (F+ - F-) : {res_achiral['CD_purcell']:.4e}")
    assert abs(res_achiral['CD_purcell']) < 1e-6, "FAIL: Achiral structure must have zero CD!"
    print("  PASS: Achiral symmetry verified (CD = 0).")

    # 3. CD Spectrum calculation
    lams = np.linspace(450, 750, 100)
    spec = dimer.circular_dichroism_spectrum(lams, r_emitter)
    max_cd_idx = np.argmax(np.abs(spec["CD"]))
    print(f"\nCD Spectrum Peak:")
    print(f"  Wavelength : {lams[max_cd_idx]:.1f} nm")
    print(f"  Max |CD|   : {spec['CD'][max_cd_idx]:.4f}")
    print(f"  g_CD @ peak: {spec['g_CD'][max_cd_idx]:.4f}")
    print("\n  PASS: chiral_green_tensor.py operational.")

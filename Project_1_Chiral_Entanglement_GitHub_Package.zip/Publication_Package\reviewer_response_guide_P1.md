# Peer Review Response Guide: Project 1 (Chiral Quantum Plasmonics)

This document provides pre-drafted, mathematically sound, and literature-backed responses to the four most critical questions reviewers may raise during peer review for *Physica Scripta*.

---

## Question 1: Fabrication & Emitter Placement Feasibility
> **Reviewer Question:** *"Can the proposed geometry be fabricated with the required sub-nanometre emitter placement accuracy and transition dipole orientation control?"*

### Response Strategy & Manuscript References
**Key Manuscript Section:** $\S 8.5.1$ (Layered Fabrication & ALD Gap Control) & $\S 8.5.2$ (DNA Origami Emitter Placement).

**Drafted Response to Reviewer:**
> We thank the reviewer for raising this important practical question. We have specifically designed the nanoantenna and emitter assembly workflow around established experimental techniques to ensure feasibility:
> 
> 1. **Sub-Nanometre Vertical Gap Control ($g^* = 5.7\text{ nm}$):** Top-down electron-beam lithography (EBL) patterns the lower gold nanorod layer. Sub-nanometre vertical separation ($5.7 \pm 0.2\text{ nm}$) is achieved using Atomic Layer Deposition (ALD) of amorphous $\mathrm{Al}_2\mathrm{O}_3$ or $\mathrm{SiO}_2$ ($52$ self-limiting cycles at $0.11\text{ nm/cycle}$). ALD provides pinhole-free, uniform dielectric coverage, preventing Ohmic shorting and electron tunneling ($g^* > 4\text{ nm}$). Secondary alignment-marked EBL patterns the top nanorod layer with $\theta^* = 54.1^\circ \pm 1.0^\circ$ twist angle (overlay accuracy $< \pm 0.5^\circ$).
> 
> 2. **Sub-Nanometre Emitter Placement ($\pm 0.5\text{ nm}$):** Placement of two $\mathrm{CdSe/ZnS}$ core-shell quantum dots (QDs) relies on custom 3D DNA origami scaffolding ($15 \times 15 \times 5.7\text{ nm}^3$ cuboid), which fits snugly inside the ALD gap ($\S 8.5.2$). Single-stranded DNA (ssDNA) docking strands protruding from assigned staple sites bind oligonucleotide-functionalized QDs with $\pm 0.5\text{ nm}$ spatial precision, setting $d_{12} \approx 6\text{--}8\text{ nm}$ and centering both QDs vertically at $z = 2.85\text{ nm}$ from each gold surface (\cite{chikkaraddy2016,santhosh2016,tinnefeld2012}). End-functionalized thiol/biotin tethers yield $>70\%$ single-complex incorporation inside the gap.
> 
> 3. **Transition Dipole Orientation Pinning:** Wurtzite $\mathrm{CdSe/ZnS}$ core-shell QDs possess a 2D degenerate $e1\text{--}h1$ exciton transition dipole plane orthogonal to the crystal $c$-axis. Multi-point oligonucleotide anchoring (3--4 tethers per QD) to the rigid DNA origami pillar restricts rotational diffusion, pinning the crystal $c$-axis perpendicular to the gold surface and locking transition dipoles $\mathbf{d}_1, \mathbf{d}_2$ in the $x\text{--}y$ plane parallel to the in-gap LCP near-field circular polarization vector $\mathbf{e}_+$.

---

## Question 2: Robustness Across Emitter Types & Material Systems
> **Reviewer Question:** *"How robust are the conclusions to different emitter types (e.g., color centers, 2D excitons) or plasmonic material systems (e.g., Silver, Aluminum, Sodium)?"*

### Response Strategy & Manuscript References
**Key Manuscript Section:** $\S 8.2$ (Comparison with Alternative Plasmonic & Cryogenic Platforms) & $\S 8.4$ (Model Limitations).

**Drafted Response to Reviewer:**
> We appreciate this insightful question regarding the generality of chiral near-field protection.
> 
> 1. **Alternative Quantum Emitter Systems:**
>    - **Silicon-Vacancy ($\mathrm{SiV}^-$) & Nitrogen-Vacancy ($\mathrm{NV}^-$) Centers in Nanodiamonds:** Diamond color centers exhibit zero-phonon line (ZPL) emission ($\lambda_{0,\mathrm{SiV}} \approx 737\text{ nm}$, $\lambda_{0,\mathrm{NV}} \approx 637\text{ nm}$) with ultra-narrow homogeneous linewidths at room temperature. Retuning the nanorod length from $L^* = 96.6\text{ nm}$ to $L^* = 115\text{ nm}$ shifts the chiral resonance to match $\mathrm{SiV}^-$. Because color centers lack the excitonic fine-structure dephasing of colloidal QDs, the predicted concurrence increases to $\Concur_{\max} > 0.94$.
>    - **Monolayer Transition Metal Dichalcogenides ($\mathrm{MoS}_2, \mathrm{WSe}_2$):** 2D TMD excitons feature strictly in-plane dipoles ($\mathbf{d} \in x\text{--}y$ plane), eliminating dipole tilt misalignment losses entirely.
> 
> 2. **Alternative Plasmonic Metals (Silver $\mathrm{Ag}$ vs. Gold $\mathrm{Au}$):**
>    - **Silver ($\mathrm{Ag}$):** Lower Ohmic damping ($\hbar\gamma_{\mathrm{Ag}} \approx 0.02\text{ eV}$ vs $\hbar\gamma_{\mathrm{Au}} \approx 0.07\text{ eV}$ at $620\text{ nm}$) yields higher Purcell factors ($F_{\mathrm{P},+} > 45$) and longer entanglement lifetimes ($\tau_{\mathrm{ent}} > 55\text{ ps}$). However, Gold ($\mathrm{Au}$) was selected as the primary system due to its superior chemical stability and oxidation resistance in ambient room-temperature environments.

---

## Question 3: Bayesian Optimisation vs. Exhaustive Parameter Sweep
> **Reviewer Question:** *"Why is Bayesian Optimisation preferable to a structured parameter sweep or gradient-free heuristic for only three geometric parameters?"*

### Response Strategy & Manuscript References
**Key Manuscript Section:** $\S 5.1$ (Motivation for Bayesian Optimisation & Computational Efficiency).

**Drafted Response to Reviewer:**
> We thank the reviewer for asking us to clarify the computational trade-offs:
> 
> 1. **Quantitative Sampling Efficiency:** Evaluating the objective function (Wootters concurrence $\Concur_0$) requires a full 3D FDTD Maxwell simulation (0.5~nm mesh override, 12-layer PML) followed by open quantum system master equation integration ($45\text{ minutes}$ per geometry). A 10-level uniform grid sweep across 3 parameters ($\theta \in [0^\circ, 90^\circ]$, $L \in [50, 150]\text{ nm}$, $g \in [2, 20]\text{ nm}$) requires $10^3 = 1000$ evaluations ($\approx 750\text{ hours}$ / $31.25\text{ CPU days}$). By contrast, Bayesian Optimisation (BO) with a Mat\'{e}rn-5/2 Gaussian process surrogate and UCB acquisition achieves global convergence in 40 evaluations ($30\text{ hours}$ wall-time)—a **$25\times$ computational speedup ($96\%$ reduction in FDTD runs)**.
> 
> 2. **Non-Differentiability of Quantum State Objectives:** Adjoint gradient FDTD methods cannot be used because Wootters concurrence $\Concur(\rho) = \max\{0, \lambda_1 - \lambda_2 - \lambda_3 - \lambda_4\}$ involves non-differentiable matrix square roots and eigenvalue sorting operations.
> 
> 3. **Principled Uncertainty Bounds:** Unlike population heuristics (Differential Evolution or CMA-ES), BO provides an explicit posterior variance bound ($\sigma^2(\mathbf{x}^*) < 5\times10^{-3}$), certifying convergence with quantifiable confidence intervals ($\Concur_{\max} = 0.91 \pm 0.02$).

---

## Question 4: Nonlocal & Quantum-Corrected Electrodynamics
> **Reviewer Question:** *"Could nonlocal electrodynamic response or quantum electron tunneling alter the conclusions for gaps near $5.7\text{ nm}$?"*

### Response Strategy & Manuscript References
**Key Manuscript Section:** $\S 8.4$ (Model Limitations & Validity of Classical Electrodynamics).

**Drafted Response to Reviewer:**
> We appreciate the opportunity to address nonlocal and quantum tunneling effects:
> 
> 1. **Negligible Electron Tunneling ($g^* = 5.7\text{ nm} > 2\text{ nm}$):** Quantum tunneling across plasmonic gaps requires physical metal-to-metal separation $g < 1.5\text{--}2.0\text{ nm}$ (\cite{cirac2012,savage2012}). At $g^* = 5.7\text{ nm}$, dielectric barrier penetration is exponentially suppressed ($\propto e^{-2\kappa g} < 10^{-12}$), rendering quantum tunneling completely negligible.
> 
> 2. **Validity of Local Response Approximation (LRA):** Hydrodynamic nonlocal model calculations for noble metals show that spatial dispersion shifts plasmon resonance frequencies by $\Delta\lambda_{\mathrm{nonlocal}} \approx \frac{v_F}{\omega_p g} \lambda_0 \le 1.2\text{ nm}$ for $g > 5\text{ nm}$ (\cite{mortensen2014,toscano2012}). Because the optimal gap $g^* = 5.7\text{ nm}$ well exceeds the nonlocal Fermi screening length ($\xi_{\mathrm{Fe}} \approx 0.5\text{ nm}$), local electrodynamics introduces $< 2\%$ error in dyadic Green tensor elements, as confirmed by our independent MNPBEM boundary element method cross-validation ($\le 3.8\%$ discrepancy; Supplementary Section~S9).

---

## Question 5: Practical Experimental Limitations (Blinking, Spectral Diffusion, Stability)
> **Reviewer Question:** *"The fabrication pathway is discussed, but what about practical quantum optical limitations such as QD blinking, spectral diffusion, dipole orientation variability, and long-term chemical stability?"*

### Response Strategy & Manuscript References
**Key Manuscript Section:** §8.5.3 (Practical Limitations and Open Experimental Challenges), newly added in this revision.

**Drafted Response to Reviewer:**
> We thank the reviewer for raising these important practical considerations. We have added a dedicated subsection (§8.5.3) to the manuscript discussing five practical quantum-optical and materials-science limitations not captured in the current Lindblad model:
> 
> 1. **QD Photoluminescence Blinking:** Colloidal CdSe/ZnS QDs blink on ms–s timescales due to charge trapping (\cite{efros2016}), which reduces the effective entanglement duty cycle. We recommend shell-passivated "giant" (g-)QDs with >30 ZnS monolayers (\cite{mahler2008}), which achieve >90% on-time fraction, as the preferred experimental emitter.
> 
> 2. **Spectral Diffusion:** Room-temperature QDs exhibit emission wavelength wandering of ~5–20 nm on 100 ms–1 s timescales due to fluctuating electrostatic environments (\cite{empedocles1997}). This reduces resonant coupling efficiency when the QD emission drifts away from the chiral nanoantenna resonance ($\lambda_+ = 612$ nm). We identify gate-voltage Stark tuning as a practical active compensation strategy.
> 
> 3. **Dipole Orientation Variability:** Multi-point DNA origami tethering restricts rotational diffusion to $\sigma_\theta \approx \pm5^\circ$, giving a <1% coupling efficiency reduction ($\langle\cos^2\delta\rangle = \cos^2(5^\circ) \approx 0.99$). Only if orientation uncertainty exceeds $>15^\circ$ would coupling efficiency drop by >5%.
> 
> 4. **Long-Term Chemical Stability:** Al$_2$O$_3$ ALD overcoating passivates gold surfaces, extending device lifetime to >30 days in ambient conditions.
> 
> 5. **Non-Gaussian Surface Roughness:** Polycrystalline grain boundaries generate non-Gaussian near-field hotspots beyond our Gaussian roughness model. We recommend chemically grown single-crystal gold nanorods (seed-mediated synthesis) to eliminate polycrystalline grain boundaries.
> 
> None of these practical limitations invalidate the central computational findings; they define the engineering pathway for future experimental realisation.
